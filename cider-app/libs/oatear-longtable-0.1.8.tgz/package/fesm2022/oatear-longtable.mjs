import * as i0 from '@angular/core';
import { input, output, inject, ElementRef, Renderer2, computed, effect, ChangeDetectionStrategy, Component, signal, viewChild, ChangeDetectorRef } from '@angular/core';
import { DOCUMENT, CommonModule } from '@angular/common';
import * as i1 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { select, max, scaleLinear, scaleBand, axisBottom, axisLeft, stack, scaleOrdinal, scaleSequential, interpolatePlasma, extent, schemeSet2, range, axisRight, format, scaleSqrt } from 'd3';

function ContextMenuComponent_Conditional_0_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵdomElementStart(0, "button", 2);
    i0.ɵɵdomListener("click", function ContextMenuComponent_Conditional_0_Conditional_1_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r2); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.emit("openStatsModal")); });
    i0.ɵɵdomElement(1, "i", 3);
    i0.ɵɵdomElementStart(2, "span", 4);
    i0.ɵɵtext(3, "Table Stats");
    i0.ɵɵdomElementEnd()();
    i0.ɵɵdomElement(4, "div", 5);
    i0.ɵɵdomElementStart(5, "button", 6);
    i0.ɵɵdomListener("click", function ContextMenuComponent_Conditional_0_Conditional_1_Template_button_click_5_listener() { i0.ɵɵrestoreView(_r2); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.emit("copyTableData")); });
    i0.ɵɵdomElement(6, "i", 7);
    i0.ɵɵdomElementStart(7, "span", 4);
    i0.ɵɵtext(8, "Copy Table Data");
    i0.ɵɵdomElementEnd()();
    i0.ɵɵdomElementStart(9, "button", 8);
    i0.ɵɵdomListener("click", function ContextMenuComponent_Conditional_0_Conditional_1_Template_button_click_9_listener() { i0.ɵɵrestoreView(_r2); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.emit("intelligentReplaceTableData")); });
    i0.ɵɵdomElement(10, "i", 9);
    i0.ɵɵdomElementStart(11, "span", 4);
    i0.ɵɵtext(12, "Intelligent Paste / Replace");
    i0.ɵɵdomElementEnd()();
    i0.ɵɵdomElementStart(13, "button", 10);
    i0.ɵɵdomListener("click", function ContextMenuComponent_Conditional_0_Conditional_1_Template_button_click_13_listener() { i0.ɵɵrestoreView(_r2); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.emit("openFindReplace")); });
    i0.ɵɵdomElement(14, "i", 11);
    i0.ɵɵdomElementStart(15, "span", 4);
    i0.ɵɵtext(16, "Find & Replace");
    i0.ɵɵdomElementEnd()();
    i0.ɵɵdomElement(17, "div", 5);
    i0.ɵɵdomElementStart(18, "button", 12);
    i0.ɵɵdomListener("click", function ContextMenuComponent_Conditional_0_Conditional_1_Template_button_click_18_listener() { i0.ɵɵrestoreView(_r2); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.emit("importCSV")); });
    i0.ɵɵdomElement(19, "i", 13);
    i0.ɵɵdomElementStart(20, "span", 4);
    i0.ɵɵtext(21, "Import from CSV");
    i0.ɵɵdomElementEnd()();
    i0.ɵɵdomElementStart(22, "button", 14);
    i0.ɵɵdomListener("click", function ContextMenuComponent_Conditional_0_Conditional_1_Template_button_click_22_listener() { i0.ɵɵrestoreView(_r2); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.emit("exportCSV")); });
    i0.ɵɵdomElement(23, "i", 15);
    i0.ɵɵdomElementStart(24, "span", 4);
    i0.ɵɵtext(25, "Export to CSV");
    i0.ɵɵdomElementEnd()();
} if (rf & 2) {
    i0.ɵɵstyleProp("font-size", "var(--lt-font-context-menu, 14px)");
    i0.ɵɵadvance(5);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-context-menu, 14px)");
    i0.ɵɵadvance(4);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-context-menu, 14px)");
    i0.ɵɵadvance(4);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-context-menu, 14px)");
    i0.ɵɵadvance(5);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-context-menu, 14px)");
    i0.ɵɵadvance(4);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-context-menu, 14px)");
} }
function ContextMenuComponent_Conditional_0_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵdomElementStart(0, "button", 16);
    i0.ɵɵdomListener("click", function ContextMenuComponent_Conditional_0_Conditional_2_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r4); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.emit("insertRowAbove")); });
    i0.ɵɵdomElement(1, "i", 17);
    i0.ɵɵdomElementStart(2, "span", 4);
    i0.ɵɵtext(3);
    i0.ɵɵdomElementEnd()();
    i0.ɵɵdomElementStart(4, "button", 16);
    i0.ɵɵdomListener("click", function ContextMenuComponent_Conditional_0_Conditional_2_Template_button_click_4_listener() { i0.ɵɵrestoreView(_r4); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.emit("insertRowBelow")); });
    i0.ɵɵdomElement(5, "i", 18);
    i0.ɵɵdomElementStart(6, "span", 4);
    i0.ɵɵtext(7);
    i0.ɵɵdomElementEnd()();
    i0.ɵɵdomElement(8, "div", 5);
    i0.ɵɵdomElementStart(9, "button", 19);
    i0.ɵɵdomListener("click", function ContextMenuComponent_Conditional_0_Conditional_2_Template_button_click_9_listener() { i0.ɵɵrestoreView(_r4); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.emit("deleteRows")); });
    i0.ɵɵdomElement(10, "i", 20);
    i0.ɵɵdomElementStart(11, "span", 4);
    i0.ɵɵtext(12);
    i0.ɵɵdomElementEnd()();
    i0.ɵɵdomElement(13, "div", 5);
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-context-menu, 14px)");
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(ctx_r2.data().insertRowsAboveText);
    i0.ɵɵadvance();
    i0.ɵɵstyleProp("font-size", "var(--lt-font-context-menu, 14px)");
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(ctx_r2.data().insertRowsBelowText);
    i0.ɵɵadvance(2);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-context-menu, 14px)");
    i0.ɵɵdomProperty("disabled", !ctx_r2.data().canDeleteRows);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(ctx_r2.data().deleteRowText);
} }
function ContextMenuComponent_Conditional_0_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵdomElementStart(0, "button", 16);
    i0.ɵɵdomListener("click", function ContextMenuComponent_Conditional_0_Conditional_3_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r5); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.emit("openColumnSettings")); });
    i0.ɵɵdomElement(1, "i", 21);
    i0.ɵɵdomElementStart(2, "span", 4);
    i0.ɵɵtext(3, "Column Settings");
    i0.ɵɵdomElementEnd()();
    i0.ɵɵdomElement(4, "div", 5);
    i0.ɵɵdomElementStart(5, "button", 19);
    i0.ɵɵdomListener("click", function ContextMenuComponent_Conditional_0_Conditional_3_Template_button_click_5_listener() { i0.ɵɵrestoreView(_r5); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.emit("insertColumnLeft")); });
    i0.ɵɵdomElement(6, "i", 22);
    i0.ɵɵdomElementStart(7, "span", 4);
    i0.ɵɵtext(8, "Insert column left");
    i0.ɵɵdomElementEnd()();
    i0.ɵɵdomElementStart(9, "button", 19);
    i0.ɵɵdomListener("click", function ContextMenuComponent_Conditional_0_Conditional_3_Template_button_click_9_listener() { i0.ɵɵrestoreView(_r5); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.emit("insertColumnRight")); });
    i0.ɵɵdomElement(10, "i", 23);
    i0.ɵɵdomElementStart(11, "span", 4);
    i0.ɵɵtext(12, "Insert column right");
    i0.ɵɵdomElementEnd()();
    i0.ɵɵdomElementStart(13, "button", 19);
    i0.ɵɵdomListener("click", function ContextMenuComponent_Conditional_0_Conditional_3_Template_button_click_13_listener() { i0.ɵɵrestoreView(_r5); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.emit("deleteColumn")); });
    i0.ɵɵdomElement(14, "i", 20);
    i0.ɵɵdomElementStart(15, "span", 4);
    i0.ɵɵtext(16);
    i0.ɵɵdomElementEnd()();
    i0.ɵɵdomElement(17, "div", 5);
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-context-menu, 14px)");
    i0.ɵɵadvance(5);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-context-menu, 14px)");
    i0.ɵɵdomProperty("disabled", ctx_r2.data().isInsertColumnActionReadOnly);
    i0.ɵɵadvance(4);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-context-menu, 14px)");
    i0.ɵɵdomProperty("disabled", ctx_r2.data().isInsertColumnActionReadOnly);
    i0.ɵɵadvance(4);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-context-menu, 14px)");
    i0.ɵɵdomProperty("disabled", ctx_r2.data().isDeleteColumnActionReadOnly || !ctx_r2.data().canDeleteCols);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(ctx_r2.data().deleteColText);
} }
function ContextMenuComponent_Conditional_0_Conditional_4_Template(rf, ctx) { if (rf & 1) {
    const _r6 = i0.ɵɵgetCurrentView();
    i0.ɵɵdomElementStart(0, "button", 16);
    i0.ɵɵdomListener("click", function ContextMenuComponent_Conditional_0_Conditional_4_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r6); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.emit("copy")); });
    i0.ɵɵdomElement(1, "i", 24);
    i0.ɵɵdomElementStart(2, "span", 4);
    i0.ɵɵtext(3, "Copy");
    i0.ɵɵdomElementEnd()();
    i0.ɵɵdomElementStart(4, "button", 16);
    i0.ɵɵdomListener("click", function ContextMenuComponent_Conditional_0_Conditional_4_Template_button_click_4_listener() { i0.ɵɵrestoreView(_r6); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.emit("paste")); });
    i0.ɵɵdomElement(5, "i", 25);
    i0.ɵɵdomElementStart(6, "span", 4);
    i0.ɵɵtext(7, "Paste");
    i0.ɵɵdomElementEnd()();
} if (rf & 2) {
    i0.ɵɵstyleProp("font-size", "var(--lt-font-context-menu, 14px)");
    i0.ɵɵadvance(4);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-context-menu, 14px)");
} }
function ContextMenuComponent_Conditional_0_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵdomElementStart(0, "div", 1);
    i0.ɵɵdomListener("mousedown", function ContextMenuComponent_Conditional_0_Template_div_mousedown_0_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵconditionalCreate(1, ContextMenuComponent_Conditional_0_Conditional_1_Template, 26, 12);
    i0.ɵɵconditionalCreate(2, ContextMenuComponent_Conditional_0_Conditional_2_Template, 14, 10);
    i0.ɵɵconditionalCreate(3, ContextMenuComponent_Conditional_0_Conditional_3_Template, 18, 12);
    i0.ɵɵconditionalCreate(4, ContextMenuComponent_Conditional_0_Conditional_4_Template, 8, 4);
    i0.ɵɵdomElementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    const pos_r7 = ctx_r2.position();
    i0.ɵɵstyleProp("left", pos_r7.x + "px")("top", pos_r7.y + "px")("background", "var(--lt-popup-bg)");
    i0.ɵɵclassProp("absolute", ctx_r2.appendTo() !== "body")("fixed", ctx_r2.appendTo() === "body");
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r2.type() === "headerCorner" ? 1 : -1);
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r2.type() === "row" || ctx_r2.type() === "cell" ? 2 : -1);
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r2.type() === "col" ? 3 : -1);
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r2.type() !== "headerCorner" ? 4 : -1);
} }
class ContextMenuComponent {
    constructor() {
        this.isVisible = input.required(...(ngDevMode ? [{ debugName: "isVisible" }] : []));
        this.position = input.required(...(ngDevMode ? [{ debugName: "position" }] : []));
        this.type = input.required(...(ngDevMode ? [{ debugName: "type" }] : []));
        this.data = input.required(...(ngDevMode ? [{ debugName: "data" }] : []));
        this.appendTo = input(null, ...(ngDevMode ? [{ debugName: "appendTo" }] : []));
        this.theme = input(null, ...(ngDevMode ? [{ debugName: "theme" }] : []));
        this.menuAction = output();
        this.elementRef = inject(ElementRef);
        this.renderer = inject(Renderer2);
        this.document = inject(DOCUMENT);
        this.appendedToBody = false;
        this.themeCssVariables = computed(() => {
            const theme = this.theme();
            if (!theme) {
                return {};
            }
            const styles = Object.entries(theme.colors).reduce((acc, [key, value]) => {
                const cssVar = `--lt-${key.replace(/[A-Z]/g, letter => `-${letter.toLowerCase()}`)}`;
                if (typeof value === 'string') {
                    acc[cssVar] = value;
                }
                return acc;
            }, {});
            if (theme.fontSizes) {
                Object.entries(theme.fontSizes).forEach(([key, value]) => {
                    const cssVar = `--lt-font-${key.replace(/[A-Z]/g, letter => `-${letter.toLowerCase()}`)}`;
                    if (typeof value === 'string') {
                        styles[cssVar] = value;
                    }
                });
            }
            if (theme.colorScheme) {
                styles['color-scheme'] = theme.colorScheme;
            }
            return styles;
        }, ...(ngDevMode ? [{ debugName: "themeCssVariables" }] : []));
        effect(() => {
            if (this.appendTo() === 'body') {
                if (this.isVisible() && !this.appendedToBody) {
                    this.renderer.appendChild(this.document.body, this.elementRef.nativeElement);
                    this.appendedToBody = true;
                }
                else if (!this.isVisible() && this.appendedToBody) {
                    // Check if elementRef.nativeElement still has a parent before removing
                    if (this.elementRef.nativeElement.parentNode) {
                        this.renderer.removeChild(this.document.body, this.elementRef.nativeElement);
                    }
                    this.appendedToBody = false;
                }
            }
        });
    }
    ngOnDestroy() {
        if (this.appendedToBody && this.elementRef.nativeElement.parentNode) {
            this.renderer.removeChild(this.document.body, this.elementRef.nativeElement);
            this.appendedToBody = false;
        }
    }
    emit(action) {
        this.menuAction.emit(action);
    }
    static { this.ɵfac = function ContextMenuComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ContextMenuComponent)(); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ContextMenuComponent, selectors: [["long-context-menu"]], hostVars: 2, hostBindings: function ContextMenuComponent_HostBindings(rf, ctx) { if (rf & 2) {
            i0.ɵɵstyleMap(ctx.themeCssVariables());
        } }, inputs: { isVisible: [1, "isVisible"], position: [1, "position"], type: [1, "type"], data: [1, "data"], appendTo: [1, "appendTo"], theme: [1, "theme"] }, outputs: { menuAction: "menuAction" }, decls: 1, vars: 1, consts: [[1, "w-56", "rounded-[10px]", "shadow-lg", "border", "border-[var(--lt-popup-border)]", "z-[120]", "py-1", 3, "absolute", "fixed", "left", "top", "background"], [1, "w-56", "rounded-[10px]", "shadow-lg", "border", "border-[var(--lt-popup-border)]", "z-[120]", "py-1", 3, "mousedown"], ["title", "Analyze column distributions and correlations.", 1, "w-full", "text-left", "px-4", "py-2", "text-[var(--lt-text-primary)]", "hover:bg-[var(--lt-icon-hover-bg)]", "flex", "items-center", 3, "click"], [1, "pi", "pi-chart-bar"], [1, "ml-2"], [1, "my-1", "h-px", "bg-[var(--lt-border-default)]"], ["title", "Copy the current view (including filters and sort order) as TSV.", 1, "w-full", "text-left", "px-4", "py-2", "text-[var(--lt-text-primary)]", "hover:bg-[var(--lt-icon-hover-bg)]", "flex", "items-center", 3, "click"], [1, "pi", "pi-table"], ["title", "Paste data and intelligently match columns by header name.", 1, "w-full", "text-left", "px-4", "py-2", "text-[var(--lt-text-primary)]", "hover:bg-[var(--lt-icon-hover-bg)]", "flex", "items-center", 3, "click"], [1, "pi", "pi-sparkles"], ["title", "Find and replace text within the spreadsheet.", 1, "w-full", "text-left", "px-4", "py-2", "text-[var(--lt-text-primary)]", "hover:bg-[var(--lt-icon-hover-bg)]", "flex", "items-center", 3, "click"], [1, "pi", "pi-search"], ["title", "Import a CSV file, intelligently matching columns.", 1, "w-full", "text-left", "px-4", "py-2", "text-[var(--lt-text-primary)]", "hover:bg-[var(--lt-icon-hover-bg)]", "flex", "items-center", 3, "click"], [1, "pi", "pi-upload"], ["title", "Export the current view (including filters and sort order) to a CSV file.", 1, "w-full", "text-left", "px-4", "py-2", "text-[var(--lt-text-primary)]", "hover:bg-[var(--lt-icon-hover-bg)]", "flex", "items-center", 3, "click"], [1, "pi", "pi-download"], [1, "w-full", "text-left", "px-4", "py-2", "text-[var(--lt-text-primary)]", "hover:bg-[var(--lt-icon-hover-bg)]", "flex", "items-center", 3, "click"], [1, "pi", "pi-arrow-up"], [1, "pi", "pi-arrow-down"], [1, "w-full", "text-left", "px-4", "py-2", "text-[var(--lt-text-primary)]", "hover:bg-[var(--lt-icon-hover-bg)]", "disabled:opacity-50", "disabled:cursor-not-allowed", "flex", "items-center", 3, "click", "disabled"], [1, "pi", "pi-trash"], [1, "pi", "pi-cog"], [1, "pi", "pi-arrow-left"], [1, "pi", "pi-arrow-right"], [1, "pi", "pi-copy"], [1, "pi", "pi-clipboard"]], template: function ContextMenuComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵconditionalCreate(0, ContextMenuComponent_Conditional_0_Template, 5, 14, "div", 0);
        } if (rf & 2) {
            i0.ɵɵconditional(ctx.isVisible() ? 0 : -1);
        } }, dependencies: [CommonModule], encapsulation: 2, changeDetection: 0 }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ContextMenuComponent, [{
        type: Component,
        args: [{ selector: 'long-context-menu', imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                    '[style]': 'themeCssVariables()',
                }, template: "@if (isVisible()) {\n    @let pos = position();\n    <div \n        (mousedown)=\"$event.stopPropagation()\"\n        class=\"w-56 rounded-[10px] shadow-lg border border-[var(--lt-popup-border)] z-[120] py-1\"\n        [class.absolute]=\"appendTo() !== 'body'\"\n        [class.fixed]=\"appendTo() === 'body'\"\n        [style.left]=\"pos.x + 'px'\"\n        [style.top]=\"pos.y + 'px'\"\n        [style.background]=\"'var(--lt-popup-bg)'\">\n      \n      @if (type() === 'headerCorner') {\n        <button (click)=\"emit('openStatsModal')\" title=\"Analyze column distributions and correlations.\" class=\"w-full text-left px-4 py-2 text-[var(--lt-text-primary)] hover:bg-[var(--lt-icon-hover-bg)] flex items-center\" [style.fontSize]=\"'var(--lt-font-context-menu, 14px)'\">\n          <i class=\"pi pi-chart-bar\"></i><span class=\"ml-2\">Table Stats</span>\n        </button>\n        <div class=\"my-1 h-px bg-[var(--lt-border-default)]\"></div>\n        <button (click)=\"emit('copyTableData')\" title=\"Copy the current view (including filters and sort order) as TSV.\" class=\"w-full text-left px-4 py-2 text-[var(--lt-text-primary)] hover:bg-[var(--lt-icon-hover-bg)] flex items-center\" [style.fontSize]=\"'var(--lt-font-context-menu, 14px)'\">\n          <i class=\"pi pi-table\"></i><span class=\"ml-2\">Copy Table Data</span>\n        </button>\n        <button (click)=\"emit('intelligentReplaceTableData')\" title=\"Paste data and intelligently match columns by header name.\" class=\"w-full text-left px-4 py-2 text-[var(--lt-text-primary)] hover:bg-[var(--lt-icon-hover-bg)] flex items-center\" [style.fontSize]=\"'var(--lt-font-context-menu, 14px)'\">\n          <i class=\"pi pi-sparkles\"></i><span class=\"ml-2\">Intelligent Paste / Replace</span>\n        </button>\n        <button (click)=\"emit('openFindReplace')\" title=\"Find and replace text within the spreadsheet.\" class=\"w-full text-left px-4 py-2 text-[var(--lt-text-primary)] hover:bg-[var(--lt-icon-hover-bg)] flex items-center\" [style.fontSize]=\"'var(--lt-font-context-menu, 14px)'\">\n            <i class=\"pi pi-search\"></i><span class=\"ml-2\">Find & Replace</span>\n        </button>\n        <div class=\"my-1 h-px bg-[var(--lt-border-default)]\"></div>\n        <button (click)=\"emit('importCSV')\" title=\"Import a CSV file, intelligently matching columns.\" class=\"w-full text-left px-4 py-2 text-[var(--lt-text-primary)] hover:bg-[var(--lt-icon-hover-bg)] flex items-center\" [style.fontSize]=\"'var(--lt-font-context-menu, 14px)'\">\n          <i class=\"pi pi-upload\"></i><span class=\"ml-2\">Import from CSV</span>\n        </button>\n        <button (click)=\"emit('exportCSV')\" title=\"Export the current view (including filters and sort order) to a CSV file.\" class=\"w-full text-left px-4 py-2 text-[var(--lt-text-primary)] hover:bg-[var(--lt-icon-hover-bg)] flex items-center\" [style.fontSize]=\"'var(--lt-font-context-menu, 14px)'\">\n          <i class=\"pi pi-download\"></i><span class=\"ml-2\">Export to CSV</span>\n        </button>\n      }\n\n      @if (type() === 'row' || type() === 'cell') {\n        <button (click)=\"emit('insertRowAbove')\" class=\"w-full text-left px-4 py-2 text-[var(--lt-text-primary)] hover:bg-[var(--lt-icon-hover-bg)] flex items-center\" [style.fontSize]=\"'var(--lt-font-context-menu, 14px)'\">\n          <i class=\"pi pi-arrow-up\"></i><span class=\"ml-2\">{{ data().insertRowsAboveText }}</span>\n        </button>\n        <button (click)=\"emit('insertRowBelow')\" class=\"w-full text-left px-4 py-2 text-[var(--lt-text-primary)] hover:bg-[var(--lt-icon-hover-bg)] flex items-center\" [style.fontSize]=\"'var(--lt-font-context-menu, 14px)'\">\n          <i class=\"pi pi-arrow-down\"></i><span class=\"ml-2\">{{ data().insertRowsBelowText }}</span>\n        </button>\n        <div class=\"my-1 h-px bg-[var(--lt-border-default)]\"></div>\n        <button (click)=\"emit('deleteRows')\" [disabled]=\"!data().canDeleteRows\" class=\"w-full text-left px-4 py-2 text-[var(--lt-text-primary)] hover:bg-[var(--lt-icon-hover-bg)] disabled:opacity-50 disabled:cursor-not-allowed flex items-center\" [style.fontSize]=\"'var(--lt-font-context-menu, 14px)'\">\n          <i class=\"pi pi-trash\"></i><span class=\"ml-2\">{{ data().deleteRowText }}</span>\n        </button>\n        <div class=\"my-1 h-px bg-[var(--lt-border-default)]\"></div>\n      }\n\n      @if (type() === 'col') {\n        <button (click)=\"emit('openColumnSettings')\" class=\"w-full text-left px-4 py-2 text-[var(--lt-text-primary)] hover:bg-[var(--lt-icon-hover-bg)] flex items-center\" [style.fontSize]=\"'var(--lt-font-context-menu, 14px)'\">\n          <i class=\"pi pi-cog\"></i><span class=\"ml-2\">Column Settings</span>\n        </button>\n        <div class=\"my-1 h-px bg-[var(--lt-border-default)]\"></div>\n        <button (click)=\"emit('insertColumnLeft')\" [disabled]=\"data().isInsertColumnActionReadOnly\" class=\"w-full text-left px-4 py-2 text-[var(--lt-text-primary)] hover:bg-[var(--lt-icon-hover-bg)] disabled:opacity-50 disabled:cursor-not-allowed flex items-center\" [style.fontSize]=\"'var(--lt-font-context-menu, 14px)'\">\n          <i class=\"pi pi-arrow-left\"></i><span class=\"ml-2\">Insert column left</span>\n        </button>\n        <button (click)=\"emit('insertColumnRight')\" [disabled]=\"data().isInsertColumnActionReadOnly\" class=\"w-full text-left px-4 py-2 text-[var(--lt-text-primary)] hover:bg-[var(--lt-icon-hover-bg)] disabled:opacity-50 disabled:cursor-not-allowed flex items-center\" [style.fontSize]=\"'var(--lt-font-context-menu, 14px)'\">\n          <i class=\"pi pi-arrow-right\"></i><span class=\"ml-2\">Insert column right</span>\n        </button>\n         <button (click)=\"emit('deleteColumn')\" [disabled]=\"data().isDeleteColumnActionReadOnly || !data().canDeleteCols\" class=\"w-full text-left px-4 py-2 text-[var(--lt-text-primary)] hover:bg-[var(--lt-icon-hover-bg)] disabled:opacity-50 disabled:cursor-not-allowed flex items-center\" [style.fontSize]=\"'var(--lt-font-context-menu, 14px)'\">\n          <i class=\"pi pi-trash\"></i><span class=\"ml-2\">{{ data().deleteColText }}</span>\n        </button>\n        <div class=\"my-1 h-px bg-[var(--lt-border-default)]\"></div>\n      }\n\n      @if (type() !== 'headerCorner') {\n        <button (click)=\"emit('copy')\" class=\"w-full text-left px-4 py-2 text-[var(--lt-text-primary)] hover:bg-[var(--lt-icon-hover-bg)] flex items-center\" [style.fontSize]=\"'var(--lt-font-context-menu, 14px)'\">\n          <i class=\"pi pi-copy\"></i><span class=\"ml-2\">Copy</span>\n        </button>\n\n        <button (click)=\"emit('paste')\" class=\"w-full text-left px-4 py-2 text-[var(--lt-text-primary)] hover:bg-[var(--lt-icon-hover-bg)] flex items-center\" [style.fontSize]=\"'var(--lt-font-context-menu, 14px)'\">\n          <i class=\"pi pi-clipboard\"></i><span class=\"ml-2\">Paste</span>\n        </button>\n      }\n    </div>\n}" }]
    }], () => [], { isVisible: [{ type: i0.Input, args: [{ isSignal: true, alias: "isVisible", required: true }] }], position: [{ type: i0.Input, args: [{ isSignal: true, alias: "position", required: true }] }], type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: true }] }], data: [{ type: i0.Input, args: [{ isSignal: true, alias: "data", required: true }] }], appendTo: [{ type: i0.Input, args: [{ isSignal: true, alias: "appendTo", required: false }] }], theme: [{ type: i0.Input, args: [{ isSignal: true, alias: "theme", required: false }] }], menuAction: [{ type: i0.Output, args: ["menuAction"] }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ContextMenuComponent, { className: "ContextMenuComponent", filePath: "lib/components/context-menu/context-menu.component.ts", lineNumber: 14 }); })();

function ColumnEditorComponent_Conditional_0_Conditional_28_Conditional_4_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 32);
    i0.ɵɵlistener("click", function ColumnEditorComponent_Conditional_0_Conditional_28_Conditional_4_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r4); const ctx_r1 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r1.inferOptions()); });
    i0.ɵɵelement(1, "i", 33);
    i0.ɵɵelementStart(2, "span");
    i0.ɵɵtext(3, "Infer from column");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
} }
function ColumnEditorComponent_Conditional_0_Conditional_28_For_7_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    const _r8 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 39);
    i0.ɵɵlistener("click", function ColumnEditorComponent_Conditional_0_Conditional_28_For_7_Conditional_6_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r8); const $index_r9 = i0.ɵɵnextContext().$index; const ctx_r1 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r1.removeOption($index_r9)); });
    i0.ɵɵelement(1, "i", 6);
    i0.ɵɵelementEnd();
} }
function ColumnEditorComponent_Conditional_0_Conditional_28_For_7_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 30)(1, "div", 34)(2, "input", 35, 0);
    i0.ɵɵtwoWayListener("ngModelChange", function ColumnEditorComponent_Conditional_0_Conditional_28_For_7_Template_input_ngModelChange_2_listener($event) { const option_r6 = i0.ɵɵrestoreView(_r5).$implicit; i0.ɵɵtwoWayBindingSet(option_r6.color, $event) || (option_r6.color = $event); return i0.ɵɵresetView($event); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "button", 36);
    i0.ɵɵlistener("click", function ColumnEditorComponent_Conditional_0_Conditional_28_For_7_Template_button_click_4_listener() { i0.ɵɵrestoreView(_r5); const colorInput_r7 = i0.ɵɵreference(3); return i0.ɵɵresetView(colorInput_r7.click()); });
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(5, "input", 37);
    i0.ɵɵtwoWayListener("ngModelChange", function ColumnEditorComponent_Conditional_0_Conditional_28_For_7_Template_input_ngModelChange_5_listener($event) { const option_r6 = i0.ɵɵrestoreView(_r5).$implicit; i0.ɵɵtwoWayBindingSet(option_r6.value, $event) || (option_r6.value = $event); return i0.ɵɵresetView($event); });
    i0.ɵɵlistener("keydown", function ColumnEditorComponent_Conditional_0_Conditional_28_For_7_Template_input_keydown_5_listener($event) { i0.ɵɵrestoreView(_r5); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵelementEnd();
    i0.ɵɵconditionalCreate(6, ColumnEditorComponent_Conditional_0_Conditional_28_For_7_Conditional_6_Template, 2, 0, "button", 38);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const option_r6 = ctx.$implicit;
    const ctx_r1 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("disabled", ctx_r1.isLocked());
    i0.ɵɵtwoWayProperty("ngModel", option_r6.color);
    i0.ɵɵadvance(2);
    i0.ɵɵstyleProp("background-color", option_r6.color);
    i0.ɵɵproperty("disabled", ctx_r1.isLocked());
    i0.ɵɵadvance();
    i0.ɵɵstyleProp("font-size", "var(--lt-font-input, 14px)");
    i0.ɵɵproperty("disabled", ctx_r1.isLocked());
    i0.ɵɵtwoWayProperty("ngModel", option_r6.value);
    i0.ɵɵadvance();
    i0.ɵɵconditional(!ctx_r1.isLocked() ? 6 : -1);
} }
function ColumnEditorComponent_Conditional_0_Conditional_28_Conditional_8_Template(rf, ctx) { if (rf & 1) {
    const _r10 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 40);
    i0.ɵɵlistener("click", function ColumnEditorComponent_Conditional_0_Conditional_28_Conditional_8_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r10); const ctx_r1 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r1.addOption()); });
    i0.ɵɵtext(1, "+ Add another option");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
} }
function ColumnEditorComponent_Conditional_0_Conditional_28_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div")(1, "div", 26)(2, "label", 27);
    i0.ɵɵtext(3, "Dropdown Options");
    i0.ɵɵelementEnd();
    i0.ɵɵconditionalCreate(4, ColumnEditorComponent_Conditional_0_Conditional_28_Conditional_4_Template, 4, 2, "button", 28);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "div", 29);
    i0.ɵɵrepeaterCreate(6, ColumnEditorComponent_Conditional_0_Conditional_28_For_7_Template, 7, 10, "div", 30, i0.ɵɵrepeaterTrackByIndex);
    i0.ɵɵelementEnd();
    i0.ɵɵconditionalCreate(8, ColumnEditorComponent_Conditional_0_Conditional_28_Conditional_8_Template, 2, 2, "button", 31);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const formState_r3 = i0.ɵɵnextContext();
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(!ctx_r1.isLocked() ? 4 : -1);
    i0.ɵɵadvance(2);
    i0.ɵɵrepeater(formState_r3.options);
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(!ctx_r1.isLocked() ? 8 : -1);
} }
function ColumnEditorComponent_Conditional_0_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 1)(1, "div", 2);
    i0.ɵɵlistener("click", function ColumnEditorComponent_Conditional_0_Template_div_click_1_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView($event.stopPropagation()); })("mousedown", function ColumnEditorComponent_Conditional_0_Template_div_mousedown_1_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵelementStart(2, "div", 3)(3, "h3", 4);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "button", 5);
    i0.ɵɵlistener("click", function ColumnEditorComponent_Conditional_0_Template_button_click_5_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.close.emit()); });
    i0.ɵɵelement(6, "i", 6);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(7, "div", 7)(8, "div")(9, "label", 8);
    i0.ɵɵtext(10, "Column Name");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(11, "input", 9);
    i0.ɵɵtwoWayListener("ngModelChange", function ColumnEditorComponent_Conditional_0_Template_input_ngModelChange_11_listener($event) { const formState_r3 = i0.ɵɵrestoreView(_r1); i0.ɵɵtwoWayBindingSet(formState_r3.name, $event) || (formState_r3.name = $event); return i0.ɵɵresetView($event); });
    i0.ɵɵlistener("keydown", function ColumnEditorComponent_Conditional_0_Template_input_keydown_11_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(12, "div")(13, "label", 10);
    i0.ɵɵtext(14, "Description");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(15, "textarea", 11);
    i0.ɵɵtwoWayListener("ngModelChange", function ColumnEditorComponent_Conditional_0_Template_textarea_ngModelChange_15_listener($event) { const formState_r3 = i0.ɵɵrestoreView(_r1); i0.ɵɵtwoWayBindingSet(formState_r3.description, $event) || (formState_r3.description = $event); return i0.ɵɵresetView($event); });
    i0.ɵɵlistener("keydown", function ColumnEditorComponent_Conditional_0_Template_textarea_keydown_15_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(16, "div")(17, "label", 12);
    i0.ɵɵtext(18, "Column Type");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(19, "select", 13);
    i0.ɵɵtwoWayListener("ngModelChange", function ColumnEditorComponent_Conditional_0_Template_select_ngModelChange_19_listener($event) { const formState_r3 = i0.ɵɵrestoreView(_r1); i0.ɵɵtwoWayBindingSet(formState_r3.type, $event) || (formState_r3.type = $event); return i0.ɵɵresetView($event); });
    i0.ɵɵelementStart(20, "option", 14);
    i0.ɵɵtext(21, "Text");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(22, "option", 15);
    i0.ɵɵtext(23, "Numeric");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(24, "option", 16);
    i0.ɵɵtext(25, "Checkbox");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(26, "option", 17);
    i0.ɵɵtext(27, "Dropdown");
    i0.ɵɵelementEnd()()();
    i0.ɵɵconditionalCreate(28, ColumnEditorComponent_Conditional_0_Conditional_28_Template, 9, 4, "div");
    i0.ɵɵelementStart(29, "div")(30, "label", 18);
    i0.ɵɵtext(31, "Column Width");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(32, "div", 19)(33, "input", 20);
    i0.ɵɵtwoWayListener("ngModelChange", function ColumnEditorComponent_Conditional_0_Template_input_ngModelChange_33_listener($event) { const formState_r3 = i0.ɵɵrestoreView(_r1); i0.ɵɵtwoWayBindingSet(formState_r3.widthValue, $event) || (formState_r3.widthValue = $event); return i0.ɵɵresetView($event); });
    i0.ɵɵlistener("keydown", function ColumnEditorComponent_Conditional_0_Template_input_keydown_33_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(34, "div", 21)(35, "span", 22);
    i0.ɵɵtext(36, "px");
    i0.ɵɵelementEnd()()()()();
    i0.ɵɵelementStart(37, "div", 23)(38, "button", 24);
    i0.ɵɵlistener("click", function ColumnEditorComponent_Conditional_0_Template_button_click_38_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.close.emit()); });
    i0.ɵɵtext(39, " Cancel ");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(40, "button", 25);
    i0.ɵɵlistener("click", function ColumnEditorComponent_Conditional_0_Template_button_click_40_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onSave()); });
    i0.ɵɵtext(41, " Save Changes ");
    i0.ɵɵelementEnd()()()();
} if (rf & 2) {
    const formState_r3 = ctx;
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵstyleProp("background", "var(--lt-popup-bg, white)");
    i0.ɵɵadvance(2);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-title, 18px)");
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" Column Settings for '", ctx_r1.columnConfig()()[ctx_r1.columnIndex()].name, "' ");
    i0.ɵɵadvance(5);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
    i0.ɵɵadvance(2);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-input, 14px)");
    i0.ɵɵproperty("disabled", ctx_r1.isLocked());
    i0.ɵɵtwoWayProperty("ngModel", formState_r3.name);
    i0.ɵɵadvance(2);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
    i0.ɵɵadvance(2);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-input, 14px)");
    i0.ɵɵproperty("disabled", ctx_r1.isLocked());
    i0.ɵɵtwoWayProperty("ngModel", formState_r3.description);
    i0.ɵɵadvance(2);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
    i0.ɵɵadvance(2);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-input, 14px)");
    i0.ɵɵproperty("disabled", ctx_r1.isLocked());
    i0.ɵɵtwoWayProperty("ngModel", formState_r3.type);
    i0.ɵɵadvance(9);
    i0.ɵɵconditional(formState_r3.type === "dropdown" ? 28 : -1);
    i0.ɵɵadvance(2);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
    i0.ɵɵadvance(3);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-input, 14px)");
    i0.ɵɵtwoWayProperty("ngModel", formState_r3.widthValue);
    i0.ɵɵadvance(2);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-input, 14px)");
    i0.ɵɵadvance(3);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
    i0.ɵɵadvance(2);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
} }
class ColumnEditorComponent {
    constructor() {
        this.isVisible = input.required(...(ngDevMode ? [{ debugName: "isVisible" }] : []));
        this.columnIndex = input.required(...(ngDevMode ? [{ debugName: "columnIndex" }] : []));
        this.allRows = input.required(...(ngDevMode ? [{ debugName: "allRows" }] : []));
        this.columnConfig = input.required(...(ngDevMode ? [{ debugName: "columnConfig" }] : []));
        this.close = output();
        this.save = output();
        this.form = signal(null, ...(ngDevMode ? [{ debugName: "form" }] : []));
        this.colorPalette = [
            '#fca5a5', '#fdba74', '#fcd34d', '#bef264', '#86efac', '#5eead4',
            '#67e8f9', '#7dd3fc', '#93c5fd', '#a5b4fc', '#c4b5fd', '#f9a8d4', '#fda4af',
        ];
        this.isLocked = computed(() => {
            const idx = this.columnIndex();
            if (idx === null)
                return false;
            return this.columnConfig()()[idx]?.lockSettings ?? false;
        }, ...(ngDevMode ? [{ debugName: "isLocked" }] : []));
        effect(() => {
            if (this.isVisible()) {
                this.initializeForm();
            }
        });
    }
    initializeForm() {
        const idx = this.columnIndex();
        if (idx === null) {
            this.form.set(null);
            return;
        }
        const config = this.columnConfig()()[idx];
        const header = config.name;
        const currentType = config?.editor ?? 'text';
        const currentOptionsRaw = config?.options ?? [];
        const currentWidth = config?.width;
        const currentDescription = config?.description;
        const currentOptions = currentOptionsRaw.map(opt => typeof opt === 'string'
            ? { value: opt, color: '#e5e7eb' }
            : { value: opt.value, color: opt.color || '#e5e7eb' });
        this.form.set({
            name: String(header),
            description: currentDescription ?? '',
            type: currentType,
            options: currentOptions,
            widthValue: typeof currentWidth === 'number' ? currentWidth : null,
        });
    }
    addOption() {
        this.form.update(form => form ? { ...form, options: [...form.options, { value: '', color: '#e5e7eb' }] } : null);
    }
    removeOption(index) {
        this.form.update(form => {
            if (!form)
                return null;
            const newOptions = [...form.options];
            newOptions.splice(index, 1);
            return { ...form, options: newOptions };
        });
    }
    inferOptions() {
        const colIndex = this.columnIndex();
        if (colIndex === null)
            return;
        const uniqueValues = new Set();
        for (let r = 0; r < this.allRows().length; r++) {
            const value = this.allRows()[r][colIndex]?.value;
            if (value != null && String(value).trim() !== '') {
                uniqueValues.add(String(value));
            }
        }
        this.form.update(currentForm => {
            if (!currentForm)
                return null;
            const newForm = { ...currentForm, options: [...currentForm.options] };
            const existingValues = new Set(newForm.options.map(opt => opt.value));
            uniqueValues.forEach(value => {
                if (!existingValues.has(value)) {
                    newForm.options.push({ value, color: this.getUniqueColor(newForm.options) });
                }
            });
            return newForm;
        });
    }
    onSave() {
        const colIndex = this.columnIndex();
        const formState = this.form();
        if (colIndex === null || !formState)
            return;
        const config = this.columnConfig()()[colIndex] ?? { name: '', field: '' };
        const newConfig = { ...config };
        newConfig.width = (formState.widthValue != null && String(formState.widthValue).trim() !== '')
            ? Math.max(60, Number(formState.widthValue))
            : 135;
        if (!this.isLocked()) {
            newConfig.name = formState.name;
            newConfig.editor = formState.type;
            newConfig.options = formState.options;
            if (formState.description) {
                newConfig.description = formState.description;
            }
            else {
                delete newConfig.description;
            }
        }
        this.save.emit({ colIndex, config: newConfig, formState });
    }
    getUniqueColor(existingOptions) {
        const usedColors = new Set(existingOptions.map(opt => opt.color));
        const availableColor = this.colorPalette.find(color => !usedColors.has(color));
        return availableColor || this.colorPalette[existingOptions.length % this.colorPalette.length];
    }
    static { this.ɵfac = function ColumnEditorComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ColumnEditorComponent)(); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ColumnEditorComponent, selectors: [["long-column-editor"]], inputs: { isVisible: [1, "isVisible"], columnIndex: [1, "columnIndex"], allRows: [1, "allRows"], columnConfig: [1, "columnConfig"] }, outputs: { close: "close", save: "save" }, decls: 1, vars: 1, consts: [["colorInput", ""], [1, "fixed", "inset-0", "bg-black/20", "backdrop-blur-[10px]", "z-[110]", "flex", "items-center", "justify-center", "p-4"], [1, "rounded-[10px]", "shadow-xl", "w-full", "max-w-md", "border", "border-[var(--lt-popup-border,theme(colors.slate.200))]", "flex", "flex-col", "max-h-full", 3, "click", "mousedown"], [1, "p-6", "pb-4", "flex", "items-center", "justify-between", "flex-shrink-0"], [1, "font-medium", "leading-6", "text-[var(--lt-text-primary,theme(colors.gray.900))]"], ["type", "button", 1, "p-2", "-m-2", "rounded-full", "text-[var(--lt-icon-default,theme(colors.gray.500))]", "hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.200))]", 3, "click"], [1, "pi", "pi-times"], [1, "px-6", "pb-6", "space-y-4", "overflow-y-auto", "modal-scroll-content", "flex-grow"], ["for", "colName", 1, "block", "font-medium", "text-[var(--lt-text-primary,theme(colors.gray.700))]"], ["type", "text", "id", "colName", 1, "mt-1", "block", "w-full", "px-3", "py-2", "bg-[var(--lt-input-bg,white)]", "border", "border-transparent", "hover:border-[var(--lt-border-default,theme(colors.slate.300))]", "rounded-[10px]", "shadow-sm", "placeholder-slate-400", "focus:outline-none", "focus:border-[var(--lt-border-editing,theme(colors.blue.500))]", "focus:ring-1", "focus:ring-[var(--lt-border-editing,theme(colors.blue.500))]", "text-[var(--lt-text-primary,inherit)]", "disabled:opacity-50", "disabled:cursor-not-allowed", 3, "ngModelChange", "keydown", "disabled", "ngModel"], ["for", "colDescription", 1, "block", "font-medium", "text-[var(--lt-text-primary,theme(colors.gray.700))]"], ["id", "colDescription", "rows", "2", "placeholder", "Optional: Describe the column's purpose", 1, "mt-1", "block", "w-full", "px-3", "py-2", "bg-[var(--lt-input-bg,white)]", "border", "border-transparent", "hover:border-[var(--lt-border-default,theme(colors.slate.300))]", "rounded-[10px]", "shadow-sm", "placeholder-slate-400", "focus:outline-none", "focus:border-[var(--lt-border-editing,theme(colors.blue.500))]", "focus:ring-1", "focus:ring-[var(--lt-border-editing,theme(colors.blue.500))]", "text-[var(--lt-text-primary,inherit)]", "resize-none", "disabled:opacity-50", "disabled:cursor-not-allowed", 3, "ngModelChange", "keydown", "disabled", "ngModel"], ["for", "colType", 1, "block", "font-medium", "text-[var(--lt-text-primary,theme(colors.gray.700))]"], ["id", "colType", 1, "mt-1", "block", "w-full", "pl-3", "pr-10", "py-2", "border", "border-transparent", "hover:border-[var(--lt-border-default,theme(colors.slate.300))]", "focus:outline-none", "focus:ring-[var(--lt-border-editing,theme(colors.blue.500))]", "focus:border-[var(--lt-border-editing,theme(colors.blue.500))]", "rounded-[10px]", "bg-[var(--lt-input-bg,white)]", "text-[var(--lt-text-primary,inherit)]", "disabled:opacity-50", "disabled:cursor-not-allowed", 3, "ngModelChange", "disabled", "ngModel"], ["value", "text"], ["value", "numeric"], ["value", "checkbox"], ["value", "dropdown"], ["for", "colWidth", 1, "block", "font-medium", "text-[var(--lt-text-primary,theme(colors.gray.700))]"], [1, "relative", "mt-1"], ["type", "number", "id", "colWidth", "min", "60", "placeholder", "Default (135)", 1, "block", "w-full", "px-3", "py-2", "bg-[var(--lt-input-bg,white)]", "border", "border-transparent", "hover:border-[var(--lt-border-default,theme(colors.slate.300))]", "rounded-[10px]", "shadow-sm", "placeholder-slate-400", "focus:outline-none", "focus:border-[var(--lt-border-editing,theme(colors.blue.500))]", "focus:ring-1", "focus:ring-[var(--lt-border-editing,theme(colors.blue.500))]", "text-[var(--lt-text-primary,inherit)]", "pr-12", 3, "ngModelChange", "keydown", "ngModel"], [1, "absolute", "inset-y-0", "right-0", "pr-3", "flex", "items-center", "pointer-events-none"], [1, "text-gray-500", "dark:text-slate-400"], [1, "p-6", "pt-4", "flex", "justify-end", "gap-3", "flex-shrink-0"], ["type", "button", 1, "px-4", "py-2", "font-medium", "text-[var(--lt-text-primary,theme(colors.gray.700))]", "bg-[var(--lt-popup-bg,white)]", "border", "border-[var(--lt-border-default,theme(colors.slate.300))]", "rounded-[10px]", "shadow-sm", "hover:bg-[var(--lt-icon-hover-bg,theme(colors.gray.50))]", "focus:outline-none", "focus:ring-2", "focus:ring-offset-2", "focus:ring-[var(--lt-border-editing,theme(colors.blue.500))]", 3, "click"], ["type", "button", 1, "px-4", "py-2", "font-medium", "text-[var(--lt-button-primary-text,white)]", "bg-[var(--lt-button-primary-bg,theme(colors.blue.600))]", "hover:bg-[var(--lt-button-primary-bg-hover,theme(colors.blue.700))]", "border", "border-transparent", "rounded-[10px]", "shadow-sm", "focus:outline-none", "focus:ring-2", "focus:ring-offset-2", "focus:ring-[var(--lt-button-primary-bg,theme(colors.blue.500))]", "focus:ring-offset-[var(--lt-popup-bg,white)]", 3, "click"], [1, "flex", "justify-between", "items-center"], [1, "block", "font-medium", "text-[var(--lt-text-primary,theme(colors.gray.700))]"], ["type", "button", 1, "text-[var(--lt-icon-active,theme(colors.blue.600))]", "hover:underline", "flex", "items-center", "gap-1.5", "px-2", "py-1", "rounded-[10px]", "hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.100))]", 3, "fontSize"], [1, "mt-1", "space-y-2", "max-h-40", "overflow-y-auto", "pr-2", "modal-scroll-content"], [1, "flex", "items-center", "gap-2"], [1, "mt-2", "text-[var(--lt-icon-active,theme(colors.blue.600))]", "hover:underline", 3, "fontSize"], ["type", "button", 1, "text-[var(--lt-icon-active,theme(colors.blue.600))]", "hover:underline", "flex", "items-center", "gap-1.5", "px-2", "py-1", "rounded-[10px]", "hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.100))]", 3, "click"], [1, "pi", "pi-magic-wand"], [1, "relative", "h-8", "w-8", "flex-shrink-0"], ["type", "color", 1, "absolute", "invisible", "w-0", "h-0", "opacity-0", 3, "ngModelChange", "disabled", "ngModel"], ["type", "button", 1, "w-full", "h-full", "rounded-[10px]", "border", "border-[var(--lt-border-default,theme(colors.slate.300))]", "cursor-pointer", "focus:outline-none", "focus:ring-2", "focus:ring-[var(--lt-border-editing,theme(colors.blue.500))]", "disabled:cursor-not-allowed", "disabled:opacity-50", 3, "click", "disabled"], ["type", "text", "placeholder", "Option value", 1, "block", "w-full", "px-3", "py-2", "bg-[var(--lt-input-bg,white)]", "border", "border-transparent", "hover:border-[var(--lt-border-default,theme(colors.slate.300))]", "rounded-[10px]", "shadow-sm", "focus:outline-none", "focus:border-[var(--lt-border-editing,theme(colors.blue.500))]", "focus:ring-1", "focus:ring-[var(--lt-border-editing,theme(colors.blue.500))]", "text-[var(--lt-text-primary,inherit)]", "disabled:opacity-50", "disabled:cursor-not-allowed", 3, "ngModelChange", "keydown", "disabled", "ngModel"], [1, "p-2", "rounded-full", "text-[var(--lt-icon-default,theme(colors.gray.500))]", "hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.200))]"], [1, "p-2", "rounded-full", "text-[var(--lt-icon-default,theme(colors.gray.500))]", "hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.200))]", 3, "click"], [1, "mt-2", "text-[var(--lt-icon-active,theme(colors.blue.600))]", "hover:underline", 3, "click"]], template: function ColumnEditorComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵconditionalCreate(0, ColumnEditorComponent_Conditional_0_Template, 42, 35, "div", 1);
        } if (rf & 2) {
            let tmp_0_0;
            i0.ɵɵconditional((tmp_0_0 = ctx.isVisible() && ctx.form()) ? 0 : -1, tmp_0_0);
        } }, dependencies: [CommonModule, FormsModule, i1.NgSelectOption, i1.ɵNgSelectMultipleOption, i1.DefaultValueAccessor, i1.NumberValueAccessor, i1.SelectControlValueAccessor, i1.NgControlStatus, i1.MinValidator, i1.NgModel], encapsulation: 2, changeDetection: 0 }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ColumnEditorComponent, [{
        type: Component,
        args: [{ selector: 'long-column-editor', imports: [CommonModule, FormsModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (isVisible() && form(); as formState) {\n<div class=\"fixed inset-0 bg-black/20 backdrop-blur-[10px] z-[110] flex items-center justify-center p-4\">\n    <div class=\"rounded-[10px] shadow-xl w-full max-w-md border border-[var(--lt-popup-border,theme(colors.slate.200))] flex flex-col max-h-full\"\n        (click)=\"$event.stopPropagation()\" (mousedown)=\"$event.stopPropagation()\"\n        [style.background]=\"'var(--lt-popup-bg, white)'\">\n\n        <div class=\"p-6 pb-4 flex items-center justify-between flex-shrink-0\">\n            <h3 class=\"font-medium leading-6 text-[var(--lt-text-primary,theme(colors.gray.900))]\"\n                [style.fontSize]=\"'var(--lt-font-modal-title, 18px)'\">\n                Column Settings for '{{ columnConfig()()[columnIndex()!].name }}'\n            </h3>\n            <button (click)=\"close.emit()\" type=\"button\"\n                class=\"p-2 -m-2 rounded-full text-[var(--lt-icon-default,theme(colors.gray.500))] hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.200))]\">\n                <i class=\"pi pi-times\"></i>\n            </button>\n        </div>\n\n        <div class=\"px-6 pb-6 space-y-4 overflow-y-auto modal-scroll-content flex-grow\">\n            <div>\n                <label for=\"colName\" class=\"block font-medium text-[var(--lt-text-primary,theme(colors.gray.700))]\"\n                    [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">Column Name</label>\n                <input type=\"text\" id=\"colName\" [disabled]=\"isLocked()\" [(ngModel)]=\"formState.name\"\n                    (keydown)=\"$event.stopPropagation()\"\n                    class=\"mt-1 block w-full px-3 py-2 bg-[var(--lt-input-bg,white)] border border-transparent hover:border-[var(--lt-border-default,theme(colors.slate.300))] rounded-[10px] shadow-sm placeholder-slate-400 focus:outline-none focus:border-[var(--lt-border-editing,theme(colors.blue.500))] focus:ring-1 focus:ring-[var(--lt-border-editing,theme(colors.blue.500))] text-[var(--lt-text-primary,inherit)] disabled:opacity-50 disabled:cursor-not-allowed\"\n                    [style.fontSize]=\"'var(--lt-font-input, 14px)'\">\n            </div>\n\n            <div>\n                <label for=\"colDescription\"\n                    class=\"block font-medium text-[var(--lt-text-primary,theme(colors.gray.700))]\"\n                    [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">Description</label>\n                <textarea id=\"colDescription\" [disabled]=\"isLocked()\" [(ngModel)]=\"formState.description\"\n                    (keydown)=\"$event.stopPropagation()\" rows=\"2\"\n                    class=\"mt-1 block w-full px-3 py-2 bg-[var(--lt-input-bg,white)] border border-transparent hover:border-[var(--lt-border-default,theme(colors.slate.300))] rounded-[10px] shadow-sm placeholder-slate-400 focus:outline-none focus:border-[var(--lt-border-editing,theme(colors.blue.500))] focus:ring-1 focus:ring-[var(--lt-border-editing,theme(colors.blue.500))] text-[var(--lt-text-primary,inherit)] resize-none disabled:opacity-50 disabled:cursor-not-allowed\"\n                    placeholder=\"Optional: Describe the column's purpose\"\n                    [style.fontSize]=\"'var(--lt-font-input, 14px)'\"></textarea>\n            </div>\n\n            <div>\n                <label for=\"colType\" class=\"block font-medium text-[var(--lt-text-primary,theme(colors.gray.700))]\"\n                    [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">Column Type</label>\n                <select id=\"colType\" [disabled]=\"isLocked()\" [(ngModel)]=\"formState.type\"\n                    class=\"mt-1 block w-full pl-3 pr-10 py-2 border border-transparent hover:border-[var(--lt-border-default,theme(colors.slate.300))] focus:outline-none focus:ring-[var(--lt-border-editing,theme(colors.blue.500))] focus:border-[var(--lt-border-editing,theme(colors.blue.500))] rounded-[10px] bg-[var(--lt-input-bg,white)] text-[var(--lt-text-primary,inherit)] disabled:opacity-50 disabled:cursor-not-allowed\"\n                    [style.fontSize]=\"'var(--lt-font-input, 14px)'\">\n                    <option value=\"text\">Text</option>\n                    <option value=\"numeric\">Numeric</option>\n                    <option value=\"checkbox\">Checkbox</option>\n                    <option value=\"dropdown\">Dropdown</option>\n                </select>\n            </div>\n\n            @if (formState.type === 'dropdown') {\n            <div>\n                <div class=\"flex justify-between items-center\">\n                    <label class=\"block font-medium text-[var(--lt-text-primary,theme(colors.gray.700))]\"\n                        [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">Dropdown Options</label>\n                    @if (!isLocked()) {\n                    <button (click)=\"inferOptions()\" type=\"button\"\n                        class=\"text-[var(--lt-icon-active,theme(colors.blue.600))] hover:underline flex items-center gap-1.5 px-2 py-1 rounded-[10px] hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.100))]\"\n                        [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">\n                        <i class=\"pi pi-magic-wand\"></i>\n                        <span>Infer from column</span>\n                    </button>\n                    }\n                </div>\n                <div class=\"mt-1 space-y-2 max-h-40 overflow-y-auto pr-2 modal-scroll-content\">\n                    @for (option of formState.options; track $index) {\n                    <div class=\"flex items-center gap-2\">\n                        <div class=\"relative h-8 w-8 flex-shrink-0\">\n                            <input #colorInput type=\"color\" [disabled]=\"isLocked()\" [(ngModel)]=\"option.color\"\n                                class=\"absolute invisible w-0 h-0 opacity-0\">\n                            <button type=\"button\" [style.backgroundColor]=\"option.color\" [disabled]=\"isLocked()\"\n                                (click)=\"colorInput.click()\"\n                                class=\"w-full h-full rounded-[10px] border border-[var(--lt-border-default,theme(colors.slate.300))] cursor-pointer focus:outline-none focus:ring-2 focus:ring-[var(--lt-border-editing,theme(colors.blue.500))] disabled:cursor-not-allowed disabled:opacity-50\">\n                            </button>\n                        </div>\n                        <input type=\"text\" [disabled]=\"isLocked()\" [(ngModel)]=\"option.value\"\n                            (keydown)=\"$event.stopPropagation()\"\n                            class=\"block w-full px-3 py-2 bg-[var(--lt-input-bg,white)] border border-transparent hover:border-[var(--lt-border-default,theme(colors.slate.300))] rounded-[10px] shadow-sm focus:outline-none focus:border-[var(--lt-border-editing,theme(colors.blue.500))] focus:ring-1 focus:ring-[var(--lt-border-editing,theme(colors.blue.500))] text-[var(--lt-text-primary,inherit)] disabled:opacity-50 disabled:cursor-not-allowed\"\n                            placeholder=\"Option value\" [style.fontSize]=\"'var(--lt-font-input, 14px)'\">\n                        @if (!isLocked()) {\n                        <button (click)=\"removeOption($index)\"\n                            class=\"p-2 rounded-full text-[var(--lt-icon-default,theme(colors.gray.500))] hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.200))]\">\n                            <i class=\"pi pi-times\"></i>\n                        </button>\n                        }\n                    </div>\n                    }\n                </div>\n                @if (!isLocked()) {\n                <button (click)=\"addOption()\"\n                    class=\"mt-2 text-[var(--lt-icon-active,theme(colors.blue.600))] hover:underline\"\n                    [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">+ Add another option</button>\n                }\n            </div>\n            }\n\n            <div>\n                <label for=\"colWidth\" class=\"block font-medium text-[var(--lt-text-primary,theme(colors.gray.700))]\"\n                    [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">Column Width</label>\n                <div class=\"relative mt-1\">\n                    <input type=\"number\" id=\"colWidth\" [(ngModel)]=\"formState.widthValue\"\n                        (keydown)=\"$event.stopPropagation()\" min=\"60\"\n                        class=\"block w-full px-3 py-2 bg-[var(--lt-input-bg,white)] border border-transparent hover:border-[var(--lt-border-default,theme(colors.slate.300))] rounded-[10px] shadow-sm placeholder-slate-400 focus:outline-none focus:border-[var(--lt-border-editing,theme(colors.blue.500))] focus:ring-1 focus:ring-[var(--lt-border-editing,theme(colors.blue.500))] text-[var(--lt-text-primary,inherit)] pr-12\"\n                        placeholder=\"Default (135)\" [style.fontSize]=\"'var(--lt-font-input, 14px)'\">\n                    <div class=\"absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none\">\n                        <span class=\"text-gray-500 dark:text-slate-400\"\n                            [style.fontSize]=\"'var(--lt-font-input, 14px)'\">px</span>\n                    </div>\n                </div>\n            </div>\n        </div>\n\n        <div class=\"p-6 pt-4 flex justify-end gap-3 flex-shrink-0\">\n            <button (click)=\"close.emit()\" type=\"button\"\n                class=\"px-4 py-2 font-medium text-[var(--lt-text-primary,theme(colors.gray.700))] bg-[var(--lt-popup-bg,white)] border border-[var(--lt-border-default,theme(colors.slate.300))] rounded-[10px] shadow-sm hover:bg-[var(--lt-icon-hover-bg,theme(colors.gray.50))] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[var(--lt-border-editing,theme(colors.blue.500))]\"\n                [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">\n                Cancel\n            </button>\n            <button (click)=\"onSave()\" type=\"button\"\n                class=\"px-4 py-2 font-medium text-[var(--lt-button-primary-text,white)] bg-[var(--lt-button-primary-bg,theme(colors.blue.600))] hover:bg-[var(--lt-button-primary-bg-hover,theme(colors.blue.700))] border border-transparent rounded-[10px] shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[var(--lt-button-primary-bg,theme(colors.blue.500))] focus:ring-offset-[var(--lt-popup-bg,white)]\"\n                [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">\n                Save Changes\n            </button>\n        </div>\n    </div>\n</div>\n}" }]
    }], () => [], { isVisible: [{ type: i0.Input, args: [{ isSignal: true, alias: "isVisible", required: true }] }], columnIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "columnIndex", required: true }] }], allRows: [{ type: i0.Input, args: [{ isSignal: true, alias: "allRows", required: true }] }], columnConfig: [{ type: i0.Input, args: [{ isSignal: true, alias: "columnConfig", required: true }] }], close: [{ type: i0.Output, args: ["close"] }], save: [{ type: i0.Output, args: ["save"] }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ColumnEditorComponent, { className: "ColumnEditorComponent", filePath: "lib/components/column-editor/column-editor.component.ts", lineNumber: 12 }); })();

function FilterPopupComponent_Conditional_0_For_14_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵdomElementStart(0, "label", 14)(1, "input", 15);
    i0.ɵɵdomListener("change", function FilterPopupComponent_Conditional_0_For_14_Template_input_change_1_listener() { const value_r4 = i0.ɵɵrestoreView(_r3).$implicit; const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.toggleValueSelection(value_r4)); });
    i0.ɵɵdomElementEnd();
    i0.ɵɵdomElementStart(2, "span", 16);
    i0.ɵɵtext(3);
    i0.ɵɵdomElementEnd()();
} if (rf & 2) {
    const value_r4 = ctx.$implicit;
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵclassMap(ctx_r1.tempSelection().has(value_r4) ? "bg-[var(--lt-bg-selection,theme(colors.blue.100))]" : "hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.100))]");
    i0.ɵɵadvance();
    i0.ɵɵdomProperty("checked", ctx_r1.tempSelection().has(value_r4));
    i0.ɵɵadvance();
    i0.ɵɵclassMap(ctx_r1.tempSelection().has(value_r4) ? "font-semibold text-[var(--lt-text-selection,theme(colors.blue.800))]" : "text-[var(--lt-text-primary,theme(colors.gray.700))]");
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(value_r4 || "(Blanks)");
} }
function FilterPopupComponent_Conditional_0_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵdomElementStart(0, "div", 1);
    i0.ɵɵdomListener("click", function FilterPopupComponent_Conditional_0_Template_div_click_0_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView($event.stopPropagation()); })("mousedown", function FilterPopupComponent_Conditional_0_Template_div_mousedown_0_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵdomElementStart(1, "div", 2)(2, "h4", 3);
    i0.ɵɵtext(3, "Filter by value");
    i0.ɵɵdomElementEnd();
    i0.ɵɵdomElementStart(4, "button", 4);
    i0.ɵɵdomListener("click", function FilterPopupComponent_Conditional_0_Template_button_click_4_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.close.emit()); });
    i0.ɵɵdomElement(5, "i", 5);
    i0.ɵɵdomElementEnd()();
    i0.ɵɵdomElementStart(6, "input", 6);
    i0.ɵɵdomListener("input", function FilterPopupComponent_Conditional_0_Template_input_input_6_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.searchText.set($event.target.value)); })("keydown", function FilterPopupComponent_Conditional_0_Template_input_keydown_6_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵdomElementEnd();
    i0.ɵɵdomElementStart(7, "div", 7)(8, "button", 8);
    i0.ɵɵdomListener("click", function FilterPopupComponent_Conditional_0_Template_button_click_8_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.selectAll()); });
    i0.ɵɵtext(9, "Select All");
    i0.ɵɵdomElementEnd();
    i0.ɵɵdomElementStart(10, "button", 8);
    i0.ɵɵdomListener("click", function FilterPopupComponent_Conditional_0_Template_button_click_10_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.clearAll()); });
    i0.ɵɵtext(11, "Clear");
    i0.ɵɵdomElementEnd()();
    i0.ɵɵdomElementStart(12, "div", 9);
    i0.ɵɵrepeaterCreate(13, FilterPopupComponent_Conditional_0_For_14_Template, 4, 8, "label", 10, i0.ɵɵrepeaterTrackByIdentity);
    i0.ɵɵdomElementEnd();
    i0.ɵɵdomElementStart(15, "div", 11)(16, "button", 12);
    i0.ɵɵdomListener("click", function FilterPopupComponent_Conditional_0_Template_button_click_16_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.clear.emit()); });
    i0.ɵɵtext(17, " Clear Filter ");
    i0.ɵɵdomElementEnd();
    i0.ɵɵdomElementStart(18, "button", 13);
    i0.ɵɵdomListener("click", function FilterPopupComponent_Conditional_0_Template_button_click_18_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onApply()); });
    i0.ɵɵtext(19, " Apply ");
    i0.ɵɵdomElementEnd()()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    const pos_r5 = ctx_r1.position();
    i0.ɵɵstyleProp("left", pos_r5.left)("top", pos_r5.top)("display", pos_r5.display)("background", "var(--lt-popup-bg, white)");
    i0.ɵɵadvance(2);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
    i0.ɵɵadvance(4);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-input, 14px)");
    i0.ɵɵdomProperty("value", ctx_r1.searchText());
    i0.ɵɵadvance(2);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
    i0.ɵɵadvance(2);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
    i0.ɵɵadvance(3);
    i0.ɵɵrepeater(ctx_r1.displayedValues());
    i0.ɵɵadvance(3);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
    i0.ɵɵadvance(2);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
} }
class FilterPopupComponent {
    constructor() {
        this.isVisible = input.required(...(ngDevMode ? [{ debugName: "isVisible" }] : []));
        this.position = input.required(...(ngDevMode ? [{ debugName: "position" }] : []));
        this.uniqueValues = input.required(...(ngDevMode ? [{ debugName: "uniqueValues" }] : []));
        this.initialSelection = input.required(...(ngDevMode ? [{ debugName: "initialSelection" }] : []));
        this.apply = output();
        this.clear = output();
        this.close = output();
        this.searchText = signal('', ...(ngDevMode ? [{ debugName: "searchText" }] : []));
        this.tempSelection = signal(new Set(), ...(ngDevMode ? [{ debugName: "tempSelection" }] : []));
        this.displayedValues = computed(() => {
            const search = this.searchText().toLowerCase();
            const values = this.uniqueValues();
            if (!search)
                return values;
            return values.filter(val => String(val).toLowerCase().includes(search));
        }, ...(ngDevMode ? [{ debugName: "displayedValues" }] : []));
        effect(() => {
            // Initialize tempSelection when initialSelection changes
            this.tempSelection.set(new Set(this.initialSelection()));
        }, { allowSignalWrites: true });
    }
    toggleValueSelection(value) {
        this.tempSelection.update(selection => {
            const newSelection = new Set(selection);
            newSelection.has(value) ? newSelection.delete(value) : newSelection.add(value);
            return newSelection;
        });
    }
    selectAll() {
        this.tempSelection.set(new Set(this.uniqueValues()));
    }
    clearAll() {
        this.tempSelection.set(new Set());
    }
    onApply() {
        this.apply.emit(this.tempSelection());
    }
    static { this.ɵfac = function FilterPopupComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || FilterPopupComponent)(); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: FilterPopupComponent, selectors: [["long-filter-popup"]], inputs: { isVisible: [1, "isVisible"], position: [1, "position"], uniqueValues: [1, "uniqueValues"], initialSelection: [1, "initialSelection"] }, outputs: { apply: "apply", clear: "clear", close: "close" }, decls: 1, vars: 1, consts: [[1, "absolute", "z-[100]", "w-64", "rounded-[10px]", "shadow-lg", "border", "border-[var(--lt-popup-border,theme(colors.slate.200))]", "p-3", "flex", "flex-col", 3, "left", "top", "display", "background"], [1, "absolute", "z-[100]", "w-64", "rounded-[10px]", "shadow-lg", "border", "border-[var(--lt-popup-border,theme(colors.slate.200))]", "p-3", "flex", "flex-col", 3, "click", "mousedown"], [1, "flex", "items-center", "justify-between", "pb-2", "mb-2", "border-b", "border-[var(--lt-border-default,theme(colors.slate.200))]"], [1, "font-semibold", "text-[var(--lt-text-primary,theme(colors.gray.800))]"], [1, "p-1", "-m-1", "rounded-full", "text-[var(--lt-icon-default,theme(colors.gray.500))]", "hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.200))]", 3, "click"], [1, "pi", "pi-times", "text-[14px]"], ["type", "text", "placeholder", "Search values...", 1, "w-full", "px-2", "py-1", "border", "border-transparent", "hover:border-[var(--lt-border-default,theme(colors.slate.300))]", "rounded-[10px]", "shadow-sm", "focus:outline-none", "focus:ring-[var(--lt-border-editing,theme(colors.blue.500))]", "focus:border-[var(--lt-border-editing,theme(colors.blue.500))]", "bg-[var(--lt-input-bg,white)]", "text-[var(--lt-text-primary,inherit)]", 3, "input", "keydown", "value"], [1, "flex", "justify-between", "items-center", "my-2"], [1, "text-[var(--lt-icon-active,theme(colors.blue.600))]", "hover:underline", 3, "click"], [1, "flex-grow", "overflow-y-auto", "max-h-48", "border-t", "border-b", "border-[var(--lt-border-default,theme(colors.slate.200))]", "py-1", "-mx-3", "px-3", "modal-scroll-content"], [1, "flex", "items-center", "p-1.5", "rounded-[10px]", "cursor-pointer", 3, "class"], [1, "flex", "justify-end", "gap-2", "mt-3"], [1, "px-3", "py-1", "text-[var(--lt-text-primary,theme(colors.gray.700))]", "hover:bg-[var(--lt-icon-hover-bg,theme(colors.gray.100))]", "rounded-[10px]", "border", "border-[var(--lt-border-default,theme(colors.slate.300))]", 3, "click"], [1, "px-3", "py-1", "text-[var(--lt-button-primary-text,white)]", "bg-[var(--lt-button-primary-bg,theme(colors.blue.600))]", "hover:bg-[var(--lt-button-primary-bg-hover,theme(colors.blue.700))]", "rounded-[10px]", "border", "border-transparent", 3, "click"], [1, "flex", "items-center", "p-1.5", "rounded-[10px]", "cursor-pointer"], ["type", "checkbox", 1, "h-4", "w-4", "rounded", "border", "border-[var(--lt-checkbox-border,theme(colors.slate.300))]", "focus:ring-[var(--lt-icon-active,theme(colors.blue.600))]", "bg-[var(--lt-checkbox-bg,white)]", "accent-[var(--lt-icon-active,theme(colors.blue.600))]", 3, "change", "checked"], [1, "ml-2", "truncate"]], template: function FilterPopupComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵconditionalCreate(0, FilterPopupComponent_Conditional_0_Template, 20, 21, "div", 0);
        } if (rf & 2) {
            i0.ɵɵconditional(ctx.isVisible() ? 0 : -1);
        } }, dependencies: [CommonModule, FormsModule], encapsulation: 2, changeDetection: 0 }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FilterPopupComponent, [{
        type: Component,
        args: [{ selector: 'long-filter-popup', imports: [CommonModule, FormsModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (isVisible()) {\n  @let pos = position();\n  <div \n      (click)=\"$event.stopPropagation()\"\n      (mousedown)=\"$event.stopPropagation()\"\n      class=\"absolute z-[100] w-64 rounded-[10px] shadow-lg border border-[var(--lt-popup-border,theme(colors.slate.200))] p-3 flex flex-col\"\n      [style.left]=\"pos.left\"\n      [style.top]=\"pos.top\"\n      [style.display]=\"pos.display\"\n      [style.background]=\"'var(--lt-popup-bg, white)'\">\n\n      <div class=\"flex items-center justify-between pb-2 mb-2 border-b border-[var(--lt-border-default,theme(colors.slate.200))]\">\n        <h4 class=\"font-semibold text-[var(--lt-text-primary,theme(colors.gray.800))]\" [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">Filter by value</h4>\n        <button (click)=\"close.emit()\" class=\"p-1 -m-1 rounded-full text-[var(--lt-icon-default,theme(colors.gray.500))] hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.200))]\">\n          <i class=\"pi pi-times text-[14px]\"></i>\n        </button>\n      </div>\n\n      <input \n        type=\"text\" \n        [value]=\"searchText()\"\n        (input)=\"searchText.set($any($event.target).value)\"\n        (keydown)=\"$event.stopPropagation()\"\n        class=\"w-full px-2 py-1 border border-transparent hover:border-[var(--lt-border-default,theme(colors.slate.300))] rounded-[10px] shadow-sm focus:outline-none focus:ring-[var(--lt-border-editing,theme(colors.blue.500))] focus:border-[var(--lt-border-editing,theme(colors.blue.500))] bg-[var(--lt-input-bg,white)] text-[var(--lt-text-primary,inherit)]\"\n        placeholder=\"Search values...\"\n        [style.fontSize]=\"'var(--lt-font-input, 14px)'\">\n      \n      <div class=\"flex justify-between items-center my-2\">\n          <button (click)=\"selectAll()\" class=\"text-[var(--lt-icon-active,theme(colors.blue.600))] hover:underline\" [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">Select All</button>\n          <button (click)=\"clearAll()\" class=\"text-[var(--lt-icon-active,theme(colors.blue.600))] hover:underline\" [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">Clear</button>\n      </div>\n\n      <div class=\"flex-grow overflow-y-auto max-h-48 border-t border-b border-[var(--lt-border-default,theme(colors.slate.200))] py-1 -mx-3 px-3 modal-scroll-content\">\n          @for (value of displayedValues(); track value) {\n              <label \n                  class=\"flex items-center p-1.5 rounded-[10px] cursor-pointer\"\n                  [class]=\"tempSelection().has(value) ? 'bg-[var(--lt-bg-selection,theme(colors.blue.100))]' : 'hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.100))]'\">\n                  <input \n                      type=\"checkbox\"\n                      class=\"h-4 w-4 rounded border border-[var(--lt-checkbox-border,theme(colors.slate.300))] focus:ring-[var(--lt-icon-active,theme(colors.blue.600))] bg-[var(--lt-checkbox-bg,white)] accent-[var(--lt-icon-active,theme(colors.blue.600))]\"\n                      [checked]=\"tempSelection().has(value)\"\n                      (change)=\"toggleValueSelection(value)\">\n                  <span \n                      class=\"ml-2 truncate\"\n                      [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\"\n                      [class]=\"tempSelection().has(value) ? 'font-semibold text-[var(--lt-text-selection,theme(colors.blue.800))]' : 'text-[var(--lt-text-primary,theme(colors.gray.700))]'\"\n                  >{{ value || '(Blanks)' }}</span>\n              </label>\n          }\n      </div>\n      \n      <div class=\"flex justify-end gap-2 mt-3\">\n          <button (click)=\"clear.emit()\" class=\"px-3 py-1 text-[var(--lt-text-primary,theme(colors.gray.700))] hover:bg-[var(--lt-icon-hover-bg,theme(colors.gray.100))] rounded-[10px] border border-[var(--lt-border-default,theme(colors.slate.300))]\" [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">\n              Clear Filter\n          </button>\n          <button (click)=\"onApply()\" class=\"px-3 py-1 text-[var(--lt-button-primary-text,white)] bg-[var(--lt-button-primary-bg,theme(colors.blue.600))] hover:bg-[var(--lt-button-primary-bg-hover,theme(colors.blue.700))] rounded-[10px] border border-transparent\" [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">\n              Apply\n          </button>\n      </div>\n  </div>\n}" }]
    }], () => [], { isVisible: [{ type: i0.Input, args: [{ isSignal: true, alias: "isVisible", required: true }] }], position: [{ type: i0.Input, args: [{ isSignal: true, alias: "position", required: true }] }], uniqueValues: [{ type: i0.Input, args: [{ isSignal: true, alias: "uniqueValues", required: true }] }], initialSelection: [{ type: i0.Input, args: [{ isSignal: true, alias: "initialSelection", required: true }] }], apply: [{ type: i0.Output, args: ["apply"] }], clear: [{ type: i0.Output, args: ["clear"] }], close: [{ type: i0.Output, args: ["close"] }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(FilterPopupComponent, { className: "FilterPopupComponent", filePath: "lib/components/filter-popup/filter-popup.component.ts", lineNumber: 11 }); })();

const _c0$3 = ["panel"];
const _c1$3 = ["findInput"];
function FindReplaceComponent_Conditional_0_Conditional_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "span", 23);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate2(" ", ctx_r1.resultsCount() > 0 ? ctx_r1.currentIndex() + 1 : 0, " of ", ctx_r1.resultsCount(), " ");
} }
function FindReplaceComponent_Conditional_0_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 3, 0);
    i0.ɵɵlistener("mousedown", function FindReplaceComponent_Conditional_0_Template_div_mousedown_0_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵelementStart(2, "div", 4);
    i0.ɵɵlistener("mousedown", function FindReplaceComponent_Conditional_0_Template_div_mousedown_2_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onDragStart($event)); });
    i0.ɵɵelementStart(3, "h3", 5);
    i0.ɵɵtext(4, "Find and Replace");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(5, "button", 6);
    i0.ɵɵlistener("click", function FindReplaceComponent_Conditional_0_Template_button_click_5_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.close.emit()); });
    i0.ɵɵelement(6, "i", 7);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(7, "div", 8)(8, "div", 9)(9, "input", 10, 1);
    i0.ɵɵtwoWayListener("ngModelChange", function FindReplaceComponent_Conditional_0_Template_input_ngModelChange_9_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); i0.ɵɵtwoWayBindingSet(ctx_r1.findQuery, $event) || (ctx_r1.findQuery = $event); return i0.ɵɵresetView($event); });
    i0.ɵɵlistener("keydown", function FindReplaceComponent_Conditional_0_Template_input_keydown_9_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onFindKeyDown($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵconditionalCreate(11, FindReplaceComponent_Conditional_0_Conditional_11_Template, 2, 4, "span", 11);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(12, "input", 12);
    i0.ɵɵtwoWayListener("ngModelChange", function FindReplaceComponent_Conditional_0_Template_input_ngModelChange_12_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); i0.ɵɵtwoWayBindingSet(ctx_r1.replaceQuery, $event) || (ctx_r1.replaceQuery = $event); return i0.ɵɵresetView($event); });
    i0.ɵɵlistener("keydown", function FindReplaceComponent_Conditional_0_Template_input_keydown_12_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(13, "div", 13)(14, "div", 14)(15, "button", 15);
    i0.ɵɵlistener("click", function FindReplaceComponent_Conditional_0_Template_button_click_15_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.navigatePrev.emit()); });
    i0.ɵɵelement(16, "i", 16);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(17, "button", 15);
    i0.ɵɵlistener("click", function FindReplaceComponent_Conditional_0_Template_button_click_17_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.navigateNext.emit()); });
    i0.ɵɵelement(18, "i", 17);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(19, "div", 18)(20, "button", 19);
    i0.ɵɵlistener("click", function FindReplaceComponent_Conditional_0_Template_button_click_20_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onReplace()); });
    i0.ɵɵtext(21, " Replace ");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(22, "button", 19);
    i0.ɵɵlistener("click", function FindReplaceComponent_Conditional_0_Template_button_click_22_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onReplaceAll()); });
    i0.ɵɵtext(23, " Replace All ");
    i0.ɵɵelementEnd()()();
    i0.ɵɵelementStart(24, "div", 20)(25, "label", 21)(26, "input", 22);
    i0.ɵɵlistener("ngModelChange", function FindReplaceComponent_Conditional_0_Template_input_ngModelChange_26_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onMatchCaseChange($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵtext(27, " Match case ");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(28, "label", 21)(29, "input", 22);
    i0.ɵɵlistener("ngModelChange", function FindReplaceComponent_Conditional_0_Template_input_ngModelChange_29_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onMatchEntireCellChange($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵtext(30, " Match entire cell contents ");
    i0.ɵɵelementEnd()()()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵstyleProp("left", ctx_r1.position().x + "px")("top", ctx_r1.position().y + "px")("background", "var(--lt-popup-bg, white)");
    i0.ɵɵadvance(3);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
    i0.ɵɵadvance(6);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-input, 14px)");
    i0.ɵɵtwoWayProperty("ngModel", ctx_r1.findQuery);
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(ctx_r1.findQuery() ? 11 : -1);
    i0.ɵɵadvance();
    i0.ɵɵstyleProp("font-size", "var(--lt-font-input, 14px)");
    i0.ɵɵtwoWayProperty("ngModel", ctx_r1.replaceQuery);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("disabled", ctx_r1.resultsCount() === 0);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("disabled", ctx_r1.resultsCount() === 0);
    i0.ɵɵadvance(3);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
    i0.ɵɵproperty("disabled", ctx_r1.currentIndex() < 0);
    i0.ɵɵadvance(2);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
    i0.ɵɵproperty("disabled", ctx_r1.resultsCount() === 0);
    i0.ɵɵadvance(3);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngModel", ctx_r1.matchCase());
    i0.ɵɵadvance(2);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngModel", ctx_r1.matchEntireCell());
} }
class FindReplaceComponent {
    constructor() {
        this.isVisible = input.required(...(ngDevMode ? [{ debugName: "isVisible" }] : []));
        this.container = input(null, ...(ngDevMode ? [{ debugName: "container" }] : []));
        this.theme = input(null, ...(ngDevMode ? [{ debugName: "theme" }] : []));
        // Inputs from parent spreadsheet
        this.resultsCount = input(0, ...(ngDevMode ? [{ debugName: "resultsCount" }] : []));
        this.currentIndex = input(-1, ...(ngDevMode ? [{ debugName: "currentIndex" }] : []));
        // Outputs to parent spreadsheet
        this.close = output();
        this.findQueryChange = output();
        this.findOptionsChange = output();
        this.navigateNext = output();
        this.navigatePrev = output();
        this.replaceOne = output();
        this.replaceAll = output();
        this.elementRef = inject(ElementRef);
        this.renderer = inject(Renderer2);
        this.document = inject(DOCUMENT);
        this.appendedToBody = false;
        this.panel = viewChild('panel', ...(ngDevMode ? [{ debugName: "panel" }] : []));
        this.findInput = viewChild('findInput', ...(ngDevMode ? [{ debugName: "findInput" }] : []));
        this.findQuery = signal('', ...(ngDevMode ? [{ debugName: "findQuery" }] : []));
        this.replaceQuery = signal('', ...(ngDevMode ? [{ debugName: "replaceQuery" }] : []));
        this.matchCase = signal(false, ...(ngDevMode ? [{ debugName: "matchCase" }] : []));
        this.matchEntireCell = signal(false, ...(ngDevMode ? [{ debugName: "matchEntireCell" }] : []));
        // Position is now in viewport coordinates for fixed positioning
        this.position = signal({ x: 0, y: 0 }, ...(ngDevMode ? [{ debugName: "position" }] : []));
        this.hasInitializedPosition = false;
        // Dragging state
        this.isDragging = signal(false, ...(ngDevMode ? [{ debugName: "isDragging" }] : []));
        this.dragStart = signal(null, ...(ngDevMode ? [{ debugName: "dragStart" }] : []));
        this.themeCssVariables = computed(() => {
            const theme = this.theme();
            if (!theme) {
                return {};
            }
            const styles = Object.entries(theme.colors).reduce((acc, [key, value]) => {
                const cssVar = `--lt-${key.replace(/[A-Z]/g, letter => `-${letter.toLowerCase()}`)}`;
                if (typeof value === 'string') {
                    acc[cssVar] = value;
                }
                return acc;
            }, {});
            if (theme.fontSizes) {
                Object.entries(theme.fontSizes).forEach(([key, value]) => {
                    const cssVar = `--lt-font-${key.replace(/[A-Z]/g, letter => `-${letter.toLowerCase()}`)}`;
                    if (typeof value === 'string') {
                        styles[cssVar] = value;
                    }
                });
            }
            if (theme.colorScheme) {
                styles['color-scheme'] = theme.colorScheme;
            }
            return styles;
        }, ...(ngDevMode ? [{ debugName: "themeCssVariables" }] : []));
        // Append to body when visible
        effect(() => {
            if (this.isVisible() && !this.appendedToBody) {
                this.renderer.appendChild(this.document.body, this.elementRef.nativeElement);
                this.appendedToBody = true;
                // Initialize position near top-right of container
                if (!this.hasInitializedPosition) {
                    const containerEl = this.container();
                    if (containerEl) {
                        const rect = containerEl.getBoundingClientRect();
                        this.position.set({
                            x: rect.right - 340, // 320px panel width + 20px margin
                            y: rect.top + 20
                        });
                    }
                    this.hasInitializedPosition = true;
                }
            }
            else if (!this.isVisible() && this.appendedToBody) {
                if (this.elementRef.nativeElement.parentNode) {
                    this.renderer.removeChild(this.document.body, this.elementRef.nativeElement);
                }
                this.appendedToBody = false;
            }
        });
        // Emit find query changes
        effect(() => {
            const query = this.findQuery();
            this.findQueryChange.emit(query);
        });
        // Focus find input when panel becomes visible
        effect(() => {
            if (this.isVisible()) {
                setTimeout(() => this.findInput()?.nativeElement.focus(), 0);
            }
        });
    }
    ngOnDestroy() {
        if (this.appendedToBody && this.elementRef.nativeElement.parentNode) {
            this.renderer.removeChild(this.document.body, this.elementRef.nativeElement);
            this.appendedToBody = false;
        }
    }
    onMatchCaseChange(checked) {
        this.matchCase.set(checked);
        this.findOptionsChange.emit({ matchCase: this.matchCase(), matchEntireCell: this.matchEntireCell() });
    }
    onMatchEntireCellChange(checked) {
        this.matchEntireCell.set(checked);
        this.findOptionsChange.emit({ matchCase: this.matchCase(), matchEntireCell: this.matchEntireCell() });
    }
    onReplace() {
        this.replaceOne.emit(this.replaceQuery());
    }
    onReplaceAll() {
        this.replaceAll.emit(this.replaceQuery());
    }
    onFindKeyDown(event) {
        event.stopPropagation();
        if (event.key === 'Enter') {
            event.shiftKey ? this.navigatePrev.emit() : this.navigateNext.emit();
        }
    }
    onDragStart(event) {
        event.preventDefault();
        this.isDragging.set(true);
        const currentPos = this.position();
        this.dragStart.set({
            panelX: currentPos.x,
            panelY: currentPos.y,
            mouseX: event.clientX,
            mouseY: event.clientY,
        });
        const onMouseMove = (moveEvent) => {
            const start = this.dragStart();
            if (!start)
                return;
            const deltaX = moveEvent.clientX - start.mouseX;
            const deltaY = moveEvent.clientY - start.mouseY;
            // Calculate new position
            let newX = start.panelX + deltaX;
            let newY = start.panelY + deltaY;
            // Clamp to viewport bounds
            const panelEl = this.panel()?.nativeElement;
            if (panelEl) {
                const panelRect = panelEl.getBoundingClientRect();
                const margin = 10;
                newX = Math.max(margin, Math.min(newX, window.innerWidth - panelRect.width - margin));
                newY = Math.max(margin, Math.min(newY, window.innerHeight - panelRect.height - margin));
            }
            this.position.set({ x: newX, y: newY });
        };
        const onMouseUp = () => {
            this.isDragging.set(false);
            this.dragStart.set(null);
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
        };
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    }
    static { this.ɵfac = function FindReplaceComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || FindReplaceComponent)(); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: FindReplaceComponent, selectors: [["long-find-replace"]], viewQuery: function FindReplaceComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuerySignal(ctx.panel, _c0$3, 5)(ctx.findInput, _c1$3, 5);
        } if (rf & 2) {
            i0.ɵɵqueryAdvance(2);
        } }, hostVars: 2, hostBindings: function FindReplaceComponent_HostBindings(rf, ctx) { if (rf & 2) {
            i0.ɵɵstyleMap(ctx.themeCssVariables());
        } }, inputs: { isVisible: [1, "isVisible"], container: [1, "container"], theme: [1, "theme"], resultsCount: [1, "resultsCount"], currentIndex: [1, "currentIndex"] }, outputs: { close: "close", findQueryChange: "findQueryChange", findOptionsChange: "findOptionsChange", navigateNext: "navigateNext", navigatePrev: "navigatePrev", replaceOne: "replaceOne", replaceAll: "replaceAll" }, decls: 1, vars: 1, consts: [["panel", ""], ["findInput", ""], [1, "fixed", "w-80", "rounded-[10px]", "shadow-2xl", "border", "border-[var(--lt-popup-border,theme(colors.slate.200))]", "flex", "flex-col", "z-[1000]", 3, "left", "top", "background"], [1, "fixed", "w-80", "rounded-[10px]", "shadow-2xl", "border", "border-[var(--lt-popup-border,theme(colors.slate.200))]", "flex", "flex-col", "z-[1000]", 3, "mousedown"], [1, "flex", "items-center", "justify-between", "p-2", "border-b", "border-[var(--lt-border-default,theme(colors.slate.200))]", "cursor-move", 3, "mousedown"], [1, "font-semibold", "text-[var(--lt-text-primary,theme(colors.gray.800))]"], [1, "p-1", "rounded-full", "text-[var(--lt-icon-default,theme(colors.gray.500))]", "hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.200))]", 3, "click"], [1, "pi", "pi-times", "text-[14px]"], [1, "p-3", "space-y-3"], [1, "relative"], ["type", "text", "placeholder", "Find", 1, "w-full", "px-2", "py-1.5", "pr-16", "bg-[var(--lt-input-bg,white)]", "border", "border-transparent", "hover:border-[var(--lt-border-default,theme(colors.slate.300))]", "rounded-[10px]", "shadow-sm", "focus:outline-none", "focus:border-[var(--lt-border-editing,theme(colors.blue.500))]", "focus:ring-1", "focus:ring-[var(--lt-border-editing,theme(colors.blue.500))]", "text-[var(--lt-text-primary,inherit)]", 3, "ngModelChange", "keydown", "ngModel"], [1, "absolute", "right-2", "top-1/2", "-translate-y-1/2", "text-[var(--lt-icon-default,theme(colors.gray.500))]", 3, "fontSize"], ["type", "text", "placeholder", "Replace with", 1, "w-full", "px-2", "py-1.5", "bg-[var(--lt-input-bg,white)]", "border", "border-transparent", "hover:border-[var(--lt-border-default,theme(colors.slate.300))]", "rounded-[10px]", "shadow-sm", "focus:outline-none", "focus:border-[var(--lt-border-editing,theme(colors.blue.500))]", "focus:ring-1", "focus:ring-[var(--lt-border-editing,theme(colors.blue.500))]", "text-[var(--lt-text-primary,inherit)]", 3, "ngModelChange", "keydown", "ngModel"], [1, "flex", "items-center", "justify-between"], [1, "flex", "gap-4"], [1, "p-1.5", "rounded", "text-[var(--lt-text-primary,theme(colors.gray.600))]", "hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.200))]", "disabled:opacity-50", "disabled:cursor-not-allowed", 3, "click", "disabled"], [1, "pi", "pi-chevron-left"], [1, "pi", "pi-chevron-right"], [1, "flex", "gap-2"], [1, "px-3", "py-1", "text-[var(--lt-text-primary,theme(colors.gray.700))]", "hover:bg-[var(--lt-icon-hover-bg,theme(colors.gray.100))]", "rounded-[10px]", "border", "border-[var(--lt-border-default,theme(colors.slate.300))]", "disabled:opacity-50", "disabled:cursor-not-allowed", 3, "click", "disabled"], [1, "border-t", "border-[var(--lt-border-default,theme(colors.slate.200))]", "pt-3", "space-y-2"], [1, "flex", "items-center", "gap-2", "text-[var(--lt-text-primary,theme(colors.gray.700))]"], ["type", "checkbox", 1, "h-4", "w-4", "rounded", "border", "border-[var(--lt-checkbox-border,theme(colors.slate.300))]", "focus:ring-[var(--lt-icon-active,theme(colors.blue.600))]", "bg-[var(--lt-checkbox-bg,white)]", "accent-[var(--lt-icon-active,theme(colors.blue.600))]", 3, "ngModelChange", "ngModel"], [1, "absolute", "right-2", "top-1/2", "-translate-y-1/2", "text-[var(--lt-icon-default,theme(colors.gray.500))]"]], template: function FindReplaceComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵconditionalCreate(0, FindReplaceComponent_Conditional_0_Template, 31, 29, "div", 2);
        } if (rf & 2) {
            i0.ɵɵconditional(ctx.isVisible() ? 0 : -1);
        } }, dependencies: [CommonModule, FormsModule, i1.DefaultValueAccessor, i1.CheckboxControlValueAccessor, i1.NgControlStatus, i1.NgModel], encapsulation: 2, changeDetection: 0 }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(FindReplaceComponent, [{
        type: Component,
        args: [{ selector: 'long-find-replace', imports: [CommonModule, FormsModule], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                    '[style]': 'themeCssVariables()',
                }, template: "@if (isVisible()) {\n<div #panel (mousedown)=\"$event.stopPropagation()\"\n  class=\"fixed w-80 rounded-[10px] shadow-2xl border border-[var(--lt-popup-border,theme(colors.slate.200))] flex flex-col z-[1000]\"\n  [style.left]=\"position().x + 'px'\" [style.top]=\"position().y + 'px'\" [style.background]=\"'var(--lt-popup-bg, white)'\">\n  <div (mousedown)=\"onDragStart($event)\"\n    class=\"flex items-center justify-between p-2 border-b border-[var(--lt-border-default,theme(colors.slate.200))] cursor-move\">\n    <h3 class=\"font-semibold text-[var(--lt-text-primary,theme(colors.gray.800))]\"\n      [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">Find and Replace</h3>\n    <button (click)=\"close.emit()\"\n      class=\"p-1 rounded-full text-[var(--lt-icon-default,theme(colors.gray.500))] hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.200))]\">\n      <i class=\"pi pi-times text-[14px]\"></i>\n    </button>\n  </div>\n  <div class=\"p-3 space-y-3\">\n    <div class=\"relative\">\n      <input #findInput type=\"text\" [(ngModel)]=\"findQuery\" (keydown)=\"onFindKeyDown($event)\" placeholder=\"Find\"\n        class=\"w-full px-2 py-1.5 pr-16 bg-[var(--lt-input-bg,white)] border border-transparent hover:border-[var(--lt-border-default,theme(colors.slate.300))] rounded-[10px] shadow-sm focus:outline-none focus:border-[var(--lt-border-editing,theme(colors.blue.500))] focus:ring-1 focus:ring-[var(--lt-border-editing,theme(colors.blue.500))] text-[var(--lt-text-primary,inherit)]\"\n        [style.fontSize]=\"'var(--lt-font-input, 14px)'\">\n      @if (findQuery()) {\n      <span class=\"absolute right-2 top-1/2 -translate-y-1/2 text-[var(--lt-icon-default,theme(colors.gray.500))]\"\n        [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">\n        {{ resultsCount() > 0 ? (currentIndex() + 1) : 0 }} of {{ resultsCount() }}\n      </span>\n      }\n    </div>\n    <input type=\"text\" [(ngModel)]=\"replaceQuery\" (keydown)=\"$event.stopPropagation()\" placeholder=\"Replace with\"\n      class=\"w-full px-2 py-1.5 bg-[var(--lt-input-bg,white)] border border-transparent hover:border-[var(--lt-border-default,theme(colors.slate.300))] rounded-[10px] shadow-sm focus:outline-none focus:border-[var(--lt-border-editing,theme(colors.blue.500))] focus:ring-1 focus:ring-[var(--lt-border-editing,theme(colors.blue.500))] text-[var(--lt-text-primary,inherit)]\"\n      [style.fontSize]=\"'var(--lt-font-input, 14px)'\">\n\n    <div class=\"flex items-center justify-between\">\n      <div class=\"flex gap-4\">\n        <button (click)=\"navigatePrev.emit()\" [disabled]=\"resultsCount() === 0\"\n          class=\"p-1.5 rounded text-[var(--lt-text-primary,theme(colors.gray.600))] hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.200))] disabled:opacity-50 disabled:cursor-not-allowed\">\n          <i class=\"pi pi-chevron-left\"></i>\n        </button>\n        <button (click)=\"navigateNext.emit()\" [disabled]=\"resultsCount() === 0\"\n          class=\"p-1.5 rounded text-[var(--lt-text-primary,theme(colors.gray.600))] hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.200))] disabled:opacity-50 disabled:cursor-not-allowed\">\n          <i class=\"pi pi-chevron-right\"></i>\n        </button>\n      </div>\n      <div class=\"flex gap-2\">\n        <button (click)=\"onReplace()\" [disabled]=\"currentIndex() < 0\"\n          class=\"px-3 py-1 text-[var(--lt-text-primary,theme(colors.gray.700))] hover:bg-[var(--lt-icon-hover-bg,theme(colors.gray.100))] rounded-[10px] border border-[var(--lt-border-default,theme(colors.slate.300))] disabled:opacity-50 disabled:cursor-not-allowed\"\n          [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">\n          Replace\n        </button>\n        <button (click)=\"onReplaceAll()\" [disabled]=\"resultsCount() === 0\"\n          class=\"px-3 py-1 text-[var(--lt-text-primary,theme(colors.gray.700))] hover:bg-[var(--lt-icon-hover-bg,theme(colors.gray.100))] rounded-[10px] border border-[var(--lt-border-default,theme(colors.slate.300))] disabled:opacity-50 disabled:cursor-not-allowed\"\n          [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">\n          Replace All\n        </button>\n      </div>\n    </div>\n\n    <div class=\"border-t border-[var(--lt-border-default,theme(colors.slate.200))] pt-3 space-y-2\">\n      <label class=\"flex items-center gap-2 text-[var(--lt-text-primary,theme(colors.gray.700))]\"\n        [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">\n        <input type=\"checkbox\" [ngModel]=\"matchCase()\" (ngModelChange)=\"onMatchCaseChange($event)\"\n          class=\"h-4 w-4 rounded border border-[var(--lt-checkbox-border,theme(colors.slate.300))] focus:ring-[var(--lt-icon-active,theme(colors.blue.600))] bg-[var(--lt-checkbox-bg,white)] accent-[var(--lt-icon-active,theme(colors.blue.600))]\">\n        Match case\n      </label>\n      <label class=\"flex items-center gap-2 text-[var(--lt-text-primary,theme(colors.gray.700))]\"\n        [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">\n        <input type=\"checkbox\" [ngModel]=\"matchEntireCell()\" (ngModelChange)=\"onMatchEntireCellChange($event)\"\n          class=\"h-4 w-4 rounded border border-[var(--lt-checkbox-border,theme(colors.slate.300))] focus:ring-[var(--lt-icon-active,theme(colors.blue.600))] bg-[var(--lt-checkbox-bg,white)] accent-[var(--lt-icon-active,theme(colors.blue.600))]\">\n        Match entire cell contents\n      </label>\n    </div>\n  </div>\n</div>\n}" }]
    }], () => [], { isVisible: [{ type: i0.Input, args: [{ isSignal: true, alias: "isVisible", required: true }] }], container: [{ type: i0.Input, args: [{ isSignal: true, alias: "container", required: false }] }], theme: [{ type: i0.Input, args: [{ isSignal: true, alias: "theme", required: false }] }], resultsCount: [{ type: i0.Input, args: [{ isSignal: true, alias: "resultsCount", required: false }] }], currentIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "currentIndex", required: false }] }], close: [{ type: i0.Output, args: ["close"] }], findQueryChange: [{ type: i0.Output, args: ["findQueryChange"] }], findOptionsChange: [{ type: i0.Output, args: ["findOptionsChange"] }], navigateNext: [{ type: i0.Output, args: ["navigateNext"] }], navigatePrev: [{ type: i0.Output, args: ["navigatePrev"] }], replaceOne: [{ type: i0.Output, args: ["replaceOne"] }], replaceAll: [{ type: i0.Output, args: ["replaceAll"] }], panel: [{ type: i0.ViewChild, args: ['panel', { isSignal: true }] }], findInput: [{ type: i0.ViewChild, args: ['findInput', { isSignal: true }] }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(FindReplaceComponent, { className: "FindReplaceComponent", filePath: "lib/components/find-replace/find-replace.component.ts", lineNumber: 15 }); })();

const _c0$2 = ["distributionChartContainer"];
const _c1$2 = ["statsTooltip"];
const _forTrack0$2 = ($index, $item) => $item.value;
const _forTrack1 = ($index, $item) => $item.primaryValue;
function DistributionAnalysisComponent_Conditional_6_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "i", 18);
} }
function DistributionAnalysisComponent_Conditional_6_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "i", 19);
} }
function DistributionAnalysisComponent_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 17);
    i0.ɵɵlistener("click", function DistributionAnalysisComponent_Conditional_6_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r2); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.copyTableDataToClipboard()); });
    i0.ɵɵconditionalCreate(1, DistributionAnalysisComponent_Conditional_6_Conditional_1_Template, 1, 0, "i", 18)(2, DistributionAnalysisComponent_Conditional_6_Conditional_2_Template, 1, 0, "i", 19);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵattribute("title", ctx_r2.copyState() === "idle" ? "Copy table data" : "Copied!");
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r2.copyState() === "copied" ? 1 : 2);
} }
function DistributionAnalysisComponent_For_20_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "option", 14);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const col_r4 = ctx.$implicit;
    i0.ɵɵproperty("value", col_r4.value);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(col_r4.label);
} }
function DistributionAnalysisComponent_For_28_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "option", 14);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const col_r5 = ctx.$implicit;
    i0.ɵɵproperty("value", col_r5.value);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(col_r5.label);
} }
function DistributionAnalysisComponent_Conditional_29_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "h4", 20);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
    i0.ɵɵelement(2, "div", 21, 1);
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(ctx_r2.chartTitle());
} }
function DistributionAnalysisComponent_Conditional_30_Conditional_0_For_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "th", 26);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const header_r6 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(header_r6);
} }
function DistributionAnalysisComponent_Conditional_30_Conditional_0_Conditional_7_For_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "tr", 27)(1, "td", 28);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(3, "td", 28);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const row_r7 = ctx.$implicit;
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(row_r7.value);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(row_r7.count);
} }
function DistributionAnalysisComponent_Conditional_30_Conditional_0_Conditional_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵrepeaterCreate(0, DistributionAnalysisComponent_Conditional_30_Conditional_0_Conditional_7_For_1_Template, 5, 2, "tr", 27, _forTrack0$2);
} if (rf & 2) {
    const tableData_r8 = i0.ɵɵnextContext();
    i0.ɵɵrepeater(tableData_r8.rows);
} }
function DistributionAnalysisComponent_Conditional_30_Conditional_0_Conditional_8_For_1_For_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "td", 28);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const key_r9 = ctx.$implicit;
    const row_r10 = i0.ɵɵnextContext().$implicit;
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(row_r10[key_r9]);
} }
function DistributionAnalysisComponent_Conditional_30_Conditional_0_Conditional_8_For_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "tr", 27)(1, "td", 28);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵrepeaterCreate(3, DistributionAnalysisComponent_Conditional_30_Conditional_0_Conditional_8_For_1_For_4_Template, 2, 1, "td", 28, i0.ɵɵrepeaterTrackByIdentity);
    i0.ɵɵelementStart(5, "td", 29);
    i0.ɵɵtext(6);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const row_r10 = ctx.$implicit;
    const tableData_r8 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(row_r10.primaryValue);
    i0.ɵɵadvance();
    i0.ɵɵrepeater(tableData_r8.stackKeys);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(row_r10.total);
} }
function DistributionAnalysisComponent_Conditional_30_Conditional_0_Conditional_8_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵrepeaterCreate(0, DistributionAnalysisComponent_Conditional_30_Conditional_0_Conditional_8_For_1_Template, 7, 2, "tr", 27, _forTrack1);
} if (rf & 2) {
    const tableData_r8 = i0.ɵɵnextContext();
    i0.ɵɵrepeater(tableData_r8.rows);
} }
function DistributionAnalysisComponent_Conditional_30_Conditional_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 22)(1, "table", 24)(2, "thead", 25)(3, "tr");
    i0.ɵɵrepeaterCreate(4, DistributionAnalysisComponent_Conditional_30_Conditional_0_For_5_Template, 2, 1, "th", 26, i0.ɵɵrepeaterTrackByIdentity);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(6, "tbody");
    i0.ɵɵconditionalCreate(7, DistributionAnalysisComponent_Conditional_30_Conditional_0_Conditional_7_Template, 2, 0)(8, DistributionAnalysisComponent_Conditional_30_Conditional_0_Conditional_8_Template, 2, 0);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const tableData_r8 = ctx;
    i0.ɵɵadvance();
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
    i0.ɵɵadvance(3);
    i0.ɵɵrepeater(tableData_r8.headers);
    i0.ɵɵadvance(3);
    i0.ɵɵconditional(!tableData_r8.isStacked ? 7 : 8);
} }
function DistributionAnalysisComponent_Conditional_30_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 23)(1, "p", 30);
    i0.ɵɵtext(2, "Select a field to analyze.");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    i0.ɵɵadvance();
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
} }
function DistributionAnalysisComponent_Conditional_30_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵconditionalCreate(0, DistributionAnalysisComponent_Conditional_30_Conditional_0_Template, 9, 3, "div", 22)(1, DistributionAnalysisComponent_Conditional_30_Conditional_1_Template, 3, 2, "div", 23);
} if (rf & 2) {
    let tmp_2_0;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵconditional((tmp_2_0 = ctx_r2.tableData()) ? 0 : 1, tmp_2_0);
} }
class DistributionAnalysisComponent {
    constructor() {
        this.rows = input.required(...(ngDevMode ? [{ debugName: "rows" }] : []));
        this.useCountColumn = input.required(...(ngDevMode ? [{ debugName: "useCountColumn" }] : []));
        this.initialAnalysisField = input(null, ...(ngDevMode ? [{ debugName: "initialAnalysisField" }] : []));
        this.state = input.required(...(ngDevMode ? [{ debugName: "state" }] : []));
        this.columnConfig = input.required(...(ngDevMode ? [{ debugName: "columnConfig" }] : []));
        this.theme = input.required(...(ngDevMode ? [{ debugName: "theme" }] : []));
        this.chartContainer = viewChild('distributionChartContainer', ...(ngDevMode ? [{ debugName: "chartContainer" }] : []));
        this.tooltip = viewChild('statsTooltip', ...(ngDevMode ? [{ debugName: "tooltip" }] : []));
        this.copyState = signal('idle', ...(ngDevMode ? [{ debugName: "copyState" }] : []));
        this.cdr = inject(ChangeDetectorRef);
        this.hasInitialized = false;
        this.stopWords = new Set(['a', 'an', 'and', 'the', 'is', 'in', 'of', 'for', 'on', 'with', 'to', 'it', 'that', 'this', 'was', 'were', 'be', 'are', 'as', 'at', 'by', 'but', 'or', 'from', 'has', 'have', 'he', 'she', 'they', 'i', 'we', 'you', 'not']);
        this.countColumnIndex = computed(() => this.columnConfig().findIndex(c => c.name.toLowerCase() === 'count'), ...(ngDevMode ? [{ debugName: "countColumnIndex" }] : []));
        this.analysisOptions = computed(() => {
            return this.columnConfig()
                .map((col, index) => {
                const editor = col?.editor;
                let type = 'token';
                if (editor === 'dropdown' || editor === 'checkbox')
                    type = 'categorical';
                else if (editor === 'numeric')
                    type = 'numeric';
                if (this.countColumnIndex() === index && this.useCountColumn())
                    return null;
                return { label: col.name, value: index, type };
            })
                .filter((c) => c !== null);
        }, ...(ngDevMode ? [{ debugName: "analysisOptions" }] : []));
        this.stackByOptions = computed(() => this.analysisOptions().filter(opt => opt.value !== this.state()().analysisField), ...(ngDevMode ? [{ debugName: "stackByOptions" }] : []));
        this.chartTitle = computed(() => {
            const field = this.state()().analysisField;
            if (field === null)
                return '';
            const options = this.analysisOptions();
            const analysisLabel = options.find(o => o.value === field)?.label;
            if (!analysisLabel)
                return '';
            let title = `Distribution of ${analysisLabel}`;
            const stackField = this.state()().stackByField;
            if (stackField !== null) {
                const stackLabel = options.find(o => o.value === stackField)?.label;
                if (stackLabel)
                    title += ` by ${stackLabel}`;
            }
            return title;
        }, ...(ngDevMode ? [{ debugName: "chartTitle" }] : []));
        this.distributionData = computed(() => {
            const dataRows = this.rows();
            const countIdx = this.countColumnIndex();
            const useCount = this.useCountColumn() && countIdx > -1;
            const { analysisField, stackByField } = this.state()();
            const fieldInfo = this.analysisOptions().find(opt => opt.value === analysisField);
            if (analysisField === null || !fieldInfo)
                return null;
            const dataMap = new Map();
            const title = this.columnConfig()[analysisField].name;
            dataRows.forEach(row => {
                const value = row.cells[analysisField]?.value;
                const count = useCount ? Number(row.cells[countIdx]?.value ?? 1) : 1;
                const stackValue = stackByField !== null ? String(row.cells[stackByField]?.value ?? 'N/A') : null;
                const processValue = (val) => {
                    if (stackByField !== null) {
                        if (!dataMap.has(val)) {
                            dataMap.set(val, new Map());
                        }
                        const innerMap = dataMap.get(val);
                        innerMap.set(stackValue, (innerMap.get(stackValue) || 0) + count);
                    }
                    else {
                        dataMap.set(val, (dataMap.get(val) || 0) + count);
                    }
                };
                if (fieldInfo.type === 'token') {
                    String(value).toLowerCase().split(/[\s,.;:()]+/).forEach(token => {
                        if (token && !this.stopWords.has(token))
                            processValue(token);
                    });
                }
                else {
                    processValue(String(value ?? 'N/A'));
                }
            });
            return { title, data: dataMap };
        }, ...(ngDevMode ? [{ debugName: "distributionData" }] : []));
        this.tableData = computed(() => {
            const data = this.distributionData();
            if (!data)
                return null;
            const isStacked = this.state()().stackByField !== null;
            if (!isStacked) {
                const rows = Array.from(data.data.entries())
                    .map(([value, count]) => ({ value, count }))
                    .sort((a, b) => b.count - a.count);
                return { isStacked: false, headers: [data.title, 'Count'], rows: rows };
            }
            else {
                const dataMap = data.data;
                const stackKeys = Array.from(new Set(Array.from(dataMap.values()).flatMap(innerMap => Array.from(innerMap.keys())))).sort();
                const rows = Array.from(dataMap.entries()).map(([key, innerMap]) => {
                    const row = { primaryValue: key, total: 0 };
                    stackKeys.forEach(stackKey => {
                        const value = innerMap.get(stackKey) || 0;
                        row[stackKey] = value;
                        row.total += value;
                    });
                    return row;
                }).sort((a, b) => b.total - a.total);
                return { isStacked: true, headers: [data.title, ...stackKeys, 'Total'], stackKeys: stackKeys, rows: rows };
            }
        }, ...(ngDevMode ? [{ debugName: "tableData" }] : []));
        effect(() => {
            // This effect runs when inputs change.
            this.rows();
            this.columnConfig();
            this.initializeFields();
            this.cdr.markForCheck();
        });
        effect(() => {
            // This effect runs when view-affecting state changes.
            if (this.chartContainer()) {
                this.renderChart();
            }
        });
    }
    initializeFields() {
        const state = this.state();
        const options = this.analysisOptions();
        if (state().analysisField !== null && !options.some(o => o.value === state().analysisField)) {
            state.update(s => ({ ...s, analysisField: null, stackByField: null }));
        }
        const stackOptions = this.stackByOptions();
        if (state().stackByField !== null && !stackOptions.some(o => o.value === state().stackByField)) {
            state.update(s => ({ ...s, stackByField: null }));
        }
        if (this.hasInitialized) {
            return;
        }
        if (state().analysisField === null) {
            const initialField = this.initialAnalysisField();
            if (initialField !== null && options.some(o => o.value === initialField)) {
                state.update(s => ({ ...s, analysisField: initialField }));
            }
            else if (options.length > 0) {
                const categoricalOption = options.find(opt => opt.type === 'categorical');
                state.update(s => ({ ...s, analysisField: categoricalOption ? categoricalOption.value : options[0].value }));
            }
        }
        this.hasInitialized = true;
    }
    renderChart() {
        const data = this.distributionData();
        setTimeout(() => {
            if (this.state()().view === 'chart') {
                if (data && this.chartContainer()) {
                    const analysisFieldInfo = this.analysisOptions().find(opt => opt.value === this.state()().analysisField);
                    const stackByFieldInfo = this.analysisOptions().find(opt => opt.value === this.state()().stackByField);
                    let dropdownOptions;
                    if (stackByFieldInfo && this.rows().length > 0) {
                        const colConfig = this.columnConfig()[stackByFieldInfo.value];
                        if (colConfig?.editor === 'dropdown' && colConfig.options) {
                            dropdownOptions = colConfig.options.map(opt => typeof opt === 'string' ? { value: opt, color: '#e5e7eb' } : opt);
                        }
                    }
                    this.renderAnalysisChart(this.chartContainer().nativeElement, data, analysisFieldInfo?.type, stackByFieldInfo?.type, dropdownOptions);
                }
                else if (this.chartContainer()) {
                    select(this.chartContainer().nativeElement).html('<p class="text-sm text-center text-gray-500 dark:text-slate-400 p-4">Select a field to analyze.</p>');
                }
            }
        });
    }
    copyTableDataToClipboard() {
        const table = this.tableData();
        if (!table)
            return;
        const headers = table.headers;
        const rows = table.rows;
        let dataGrid = [];
        dataGrid.push(headers);
        if (!table.isStacked) {
            rows.forEach(row => {
                dataGrid.push([row.value, row.count]);
            });
        }
        else {
            rows.forEach(row => {
                const rowData = [row.primaryValue];
                table.stackKeys.forEach(key => {
                    rowData.push(row[key] || 0);
                });
                rowData.push(row.total);
                dataGrid.push(rowData);
            });
        }
        const tsv = dataGrid.map(row => row.map(cell => {
            const v = String(cell ?? '');
            return v.match(/["\n\t]/) ? `"${v.replace(/"/g, '""')}"` : v;
        }).join('\t')).join('\n');
        navigator.clipboard.writeText(tsv).then(() => {
            this.copyState.set('copied');
            clearTimeout(this.copyTimeout);
            this.copyTimeout = setTimeout(() => this.copyState.set('idle'), 2000);
        }).catch(err => {
            console.error('Failed to copy table data: ', err);
        });
    }
    onAnalysisFieldChange(v) {
        const newValue = v === 'null' ? null : Number(v);
        this.state().update(s => {
            const newStackBy = s.stackByField === newValue ? null : s.stackByField;
            return { ...s, analysisField: newValue, stackByField: newStackBy };
        });
    }
    onStackByChange(v) {
        const newValue = v === 'null' ? null : Number(v);
        this.state().update(s => ({ ...s, stackByField: newValue }));
    }
    setView(view) {
        this.state().update(s => ({ ...s, view }));
    }
    renderAnalysisChart(container, config, analysisFieldType, stackByFieldType, dropdownOptions) {
        if (this.state()().stackByField !== null) {
            this._renderStackedBarChart(container, config.title, config.data, analysisFieldType, stackByFieldType === 'numeric' ? 'numeric' : 'categorical', dropdownOptions);
        }
        else {
            this._renderSimpleBarChart(container, config.title, config.data, analysisFieldType);
        }
    }
    _renderSimpleBarChart(container, title, dataMap, analysisFieldType) {
        select(container).html('');
        let data = Array.from(dataMap.entries()).map(([key, value]) => ({ key, value }));
        if (analysisFieldType === 'numeric') {
            data.sort((a, b) => Number(b.key) - Number(a.key));
        }
        else {
            data.sort((a, b) => b.value - a.value);
        }
        data = data.slice(0, 50);
        if (data.length === 0)
            return;
        const isDark = document.documentElement.classList.contains('dark');
        const textColor = this.theme().colors.graphSecondary;
        const barStep = 25;
        const margin = { top: 5, right: 20, bottom: 60, left: 120 };
        const height = data.length * barStep;
        const width = container.clientWidth - margin.left - margin.right;
        const svg = select(container).append('svg')
            .attr('width', width + margin.left + margin.right)
            .attr('height', height + margin.top + margin.bottom)
            .append('g')
            .attr('transform', `translate(${margin.left},${margin.top})`);
        const maxValue = max(data, d => d.value) || 0;
        const x = scaleLinear().domain([0, maxValue]).nice().range([0, width]);
        const y = scaleBand().domain(data.map(d => d.key)).range([0, height]).padding(0.2);
        const niceMax = x.domain()[1];
        let tickCount;
        if (niceMax > 1 && niceMax <= 10) {
            tickCount = Math.floor(niceMax);
        }
        else if (niceMax > 10 && niceMax <= 20) {
            tickCount = 10;
        }
        else {
            tickCount = Math.max(5, Math.round(width / 75));
        }
        const maxTicksForWidth = Math.floor(width / 40);
        const finalTickCount = Math.min(tickCount, maxTicksForWidth);
        const xAxisGroup = svg.append('g').attr('transform', `translate(0,${height})`).call(axisBottom(x).ticks(finalTickCount));
        xAxisGroup.selectAll('text').style('fill', textColor).style('font-size', 'var(--lt-font-chart-axis-label, 10px)');
        xAxisGroup.select('.domain').style('stroke', textColor);
        xAxisGroup.selectAll('.tick line').style('stroke', textColor);
        const yAxisGroup = svg.append('g').call(axisLeft(y).tickSize(0).tickFormat(d => this.truncateText(String(d), 15)));
        yAxisGroup.select(".domain").remove();
        yAxisGroup.selectAll('text').style('fill', textColor).style('font-size', 'var(--lt-font-chart-axis-label, 10px)');
        // X-axis Title
        svg.append('text')
            .attr('text-anchor', 'middle')
            .attr('x', width / 2)
            .attr('y', height + 40)
            .style('fill', textColor)
            .style('font-size', 'var(--lt-font-chart-axis-title, 12px)')
            .text('Count');
        // Y-axis Title
        svg.append('text')
            .attr('text-anchor', 'middle')
            .attr('transform', 'rotate(-90)')
            .attr('y', -margin.left + 40)
            .attr('x', -height / 2)
            .style('fill', textColor)
            .style('font-size', 'var(--lt-font-chart-axis-title, 12px)')
            .text(title);
        const tooltip = select(this.tooltip().nativeElement);
        svg.selectAll('.bar').data(data).enter().append('rect')
            .attr('class', 'bar').attr('x', x(0)).attr('y', d => y(d.key))
            .attr('width', d => x(d.value) - x(0)).attr('height', y.bandwidth()).attr('fill', this.theme().colors.graphPrimary)
            .on('mouseover', (event, d) => {
            select(event.currentTarget).style('opacity', '0.85');
            tooltip.style('opacity', '1').html(`<strong>${d.key}</strong><br/>Count: ${d.value}`);
        })
            .on('mousemove', (event) => tooltip.style('left', (event.clientX + 15) + 'px').style('top', (event.clientY + 15) + 'px'))
            .on('mouseout', (event) => {
            select(event.currentTarget).style('opacity', '1');
            tooltip.style('opacity', '0');
        });
    }
    _renderStackedBarChart(container, title, dataMap, analysisFieldType, stackByFieldType, dropdownOptions) {
        select(container).html('');
        const stackKeys = Array.from(new Set(Array.from(dataMap.values()).flatMap(innerMap => Array.from(innerMap.keys())))).sort((a, b) => stackByFieldType === 'numeric' ? Number(a) - Number(b) : a.localeCompare(b));
        let data = Array.from(dataMap.entries()).map(([key, innerMap]) => {
            const entry = { key, total: 0 };
            stackKeys.forEach(stackKey => { entry[stackKey] = innerMap.get(stackKey) || 0; entry.total += entry[stackKey]; });
            return entry;
        });
        if (analysisFieldType === 'numeric') {
            data.sort((a, b) => Number(b.key) - Number(a.key));
        }
        else {
            data.sort((a, b) => b.total - a.total);
        }
        data = data.slice(0, 50);
        if (data.length === 0)
            return;
        const series = stack().keys(stackKeys)(data);
        const isDark = document.documentElement.classList.contains('dark');
        const textColor = this.theme().colors.graphSecondary;
        const barStep = 30;
        const margin = { top: 5, right: 120, bottom: 60, left: 120 };
        const height = data.length * barStep;
        const width = container.clientWidth - margin.left - margin.right;
        const svg = select(container).append('svg').attr('width', width + margin.left + margin.right).attr('height', height + margin.top + margin.bottom).append('g').attr('transform', `translate(${margin.left},${margin.top})`);
        const maxValue = max(data, d => d.total) || 0;
        const x = scaleLinear().domain([0, maxValue]).nice().range([0, width]);
        const y = scaleBand().domain(data.map(d => d.key)).range([0, height]).padding(0.2);
        let color;
        if (dropdownOptions) {
            const colorMap = new Map(dropdownOptions.map(opt => [opt.value, opt.color]));
            color = scaleOrdinal(stackKeys.map(key => colorMap.get(key) || '#cccccc')).domain(stackKeys);
        }
        else if (stackByFieldType === 'numeric') {
            const numericKeys = stackKeys.map(Number);
            color = scaleSequential(interpolatePlasma).domain(extent(numericKeys));
        }
        else {
            color = scaleOrdinal(schemeSet2).domain(stackKeys);
        }
        const stackField = this.state()().stackByField;
        const stackLabel = stackField !== null ? this.analysisOptions().find(o => o.value === stackField)?.label : '';
        const niceMax = x.domain()[1];
        let tickCount;
        if (niceMax > 1 && niceMax <= 10) {
            tickCount = Math.floor(niceMax);
        }
        else if (niceMax > 10 && niceMax <= 20) {
            tickCount = 10;
        }
        else {
            tickCount = Math.max(5, Math.round(width / 75));
        }
        const maxTicksForWidth = Math.floor(width / 40);
        const finalTickCount = Math.min(tickCount, maxTicksForWidth);
        const xAxisGroup = svg.append('g').attr('transform', `translate(0,${height})`).call(axisBottom(x).ticks(finalTickCount));
        xAxisGroup.selectAll('text').style('fill', textColor).style('font-size', 'var(--lt-font-chart-axis-label, 10px)');
        xAxisGroup.select('.domain').style('stroke', textColor);
        xAxisGroup.selectAll('.tick line').style('stroke', textColor);
        const yAxisGroup = svg.append('g').call(axisLeft(y).tickSize(0).tickFormat(d => this.truncateText(String(d), 15)));
        yAxisGroup.select(".domain").remove();
        yAxisGroup.selectAll('text').style('fill', textColor).style('font-size', 'var(--lt-font-chart-axis-label, 10px)');
        // X-axis Title
        svg.append('text')
            .attr('text-anchor', 'middle')
            .attr('x', width / 2)
            .attr('y', height + 40)
            .style('fill', textColor)
            .style('font-size', 'var(--lt-font-chart-axis-title, 12px)')
            .text('Total Count');
        // Y-axis Title
        svg.append('text')
            .attr('text-anchor', 'middle')
            .attr('transform', 'rotate(-90)')
            .attr('y', -margin.left + 40)
            .attr('x', -height / 2)
            .style('fill', textColor)
            .style('font-size', 'var(--lt-font-chart-axis-title, 12px)')
            .text(title);
        const tooltip = select(this.tooltip().nativeElement);
        svg.append('g').selectAll('g').data(series).join('g')
            .attr('fill', d => (stackByFieldType === 'numeric' && !dropdownOptions) ? color(Number(String(d.key))) : color(String(d.key)))
            .selectAll('rect').data(d => d).join('rect')
            .attr('x', d => x(d[0])).attr('y', d => y(String(d.data.key))).attr('width', d => x(d[1]) - x(d[0])).attr('height', y.bandwidth())
            .on('mouseover', (event, d) => {
            select(event.currentTarget).style('opacity', '0.85');
            const seriesKey = select(event.currentTarget.parentNode).datum().key;
            const value = d.data[seriesKey];
            const seriesColor = (stackByFieldType === 'numeric' && !dropdownOptions) ? color(Number(String(seriesKey))) : color(String(seriesKey));
            tooltip.style('opacity', '1').html(`<strong>${d.data.key}</strong><br/><span style="color:${seriesColor}">■</span> ${stackLabel}: ${seriesKey}<br/>Count: ${value}<hr class="my-1 border-slate-500">Total: ${d.data.total}`);
        }).on('mousemove', (event) => tooltip.style('left', (event.clientX + 15) + 'px').style('top', (event.clientY + 15) + 'px'))
            .on('mouseout', (event) => {
            select(event.currentTarget).style('opacity', '1');
            tooltip.style('opacity', '0');
        });
        if (stackByFieldType === 'numeric' && !dropdownOptions) {
            this._renderGradientLegend(svg, color, width + 20, 0, 150, "Value");
        }
        else {
            const legend = svg.selectAll('.legend').data(color.domain()).enter().append('g')
                .attr('class', 'legend')
                .attr('transform', (d, i) => `translate(${width + 20}, ${i * 20})`)
                .style('cursor', 'default')
                .on('mouseover', (event, d) => {
                select(event.currentTarget).select('text').style('font-weight', 'bold');
                tooltip.style('opacity', '1').html(String(d));
            })
                .on('mousemove', (event) => tooltip.style('left', (event.clientX + 15) + 'px').style('top', (event.clientY + 15) + 'px'))
                .on('mouseout', (event) => {
                select(event.currentTarget).select('text').style('font-weight', 'normal');
                tooltip.style('opacity', '0');
            });
            // FIX: The datum `d` from the d3 domain can be inferred as a number, but the ordinal color scale expects a string.
            // Explicitly convert `d` to a string to ensure type compatibility.
            legend.append('rect').attr('width', 18).attr('height', 18).style('fill', (d) => color(String(d)));
            legend.append('text').attr('x', 24).attr('y', 9).attr('dy', '.35em').style('text-anchor', 'start').text((d) => this.truncateText(String(d), 12)).style('fill', textColor).style('font-size', 'var(--lt-font-chart-legend, 12px)');
        }
    }
    _renderGradientLegend(svg, colorScale, legendX, legendY, height, title) {
        const textColor = this.theme().colors.graphSecondary;
        const [min, max] = colorScale.domain();
        if (min === undefined || max === undefined)
            return;
        const legendId = `legend-gradient-${Math.random().toString(36).substring(2, 9)}`;
        const defs = svg.append("defs");
        const linearGradient = defs.append("linearGradient")
            .attr("id", legendId)
            .attr("x1", "0%").attr("y1", "100%")
            .attr("x2", "0%").attr("y2", "0%");
        linearGradient.selectAll("stop")
            .data(range(0, 1.01, 0.1).map(t => ({ offset: `${t * 100}%`, color: colorScale(min + t * (max - min)) })))
            .enter().append("stop")
            .attr("offset", d => d.offset)
            .attr("stop-color", d => d.color);
        const legendWidth = 18;
        svg.append("rect")
            .attr("x", legendX)
            .attr("y", legendY)
            .attr("width", legendWidth)
            .attr("height", height)
            .style("fill", `url(#${legendId})`);
        const legendScale = scaleLinear().domain([min, max]).range([height, 0]);
        const legendAxis = axisRight(legendScale).ticks(5).tickFormat(format(".2s"));
        const legendAxisGroup = svg.append("g")
            .attr("class", "legend-axis")
            .attr("transform", `translate(${legendX + legendWidth}, ${legendY})`)
            .call(legendAxis)
            .style('font-size', 'var(--lt-font-chart-axis-label, 10px)');
        legendAxisGroup.select(".domain").remove();
        legendAxisGroup.selectAll('text').style('fill', textColor);
        legendAxisGroup.selectAll('.tick line').style('stroke', textColor);
        svg.append("text")
            .attr("x", legendX)
            .attr("y", legendY - 5)
            .style("text-anchor", "start")
            .text(title)
            .style("font-weight", "bold")
            .style("fill", textColor)
            .style('font-size', 'var(--lt-font-chart-legend, 12px)');
    }
    truncateText(text, maxLength) {
        if (text.length <= maxLength)
            return text;
        return text.slice(0, maxLength - 1) + '…';
    }
    static { this.ɵfac = function DistributionAnalysisComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || DistributionAnalysisComponent)(); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DistributionAnalysisComponent, selectors: [["long-distribution-analysis"]], viewQuery: function DistributionAnalysisComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuerySignal(ctx.chartContainer, _c0$2, 5)(ctx.tooltip, _c1$2, 5);
        } if (rf & 2) {
            i0.ɵɵqueryAdvance(2);
        } }, inputs: { rows: [1, "rows"], useCountColumn: [1, "useCountColumn"], initialAnalysisField: [1, "initialAnalysisField"], state: [1, "state"], columnConfig: [1, "columnConfig"], theme: [1, "theme"] }, decls: 33, vars: 25, consts: [["statsTooltip", ""], ["distributionChartContainer", ""], [1, "relative", "h-full"], [1, "pb-2", "mb-4"], [1, "flex", "justify-between", "items-center"], [1, "flex", "items-center", "gap-3"], [1, "font-semibold", "text-[var(--lt-text-primary,theme(colors.gray.800))]"], [1, "p-1.5", "leading-none", "h-7", "w-7", "rounded-full", "text-[var(--lt-icon-default,theme(colors.gray.500))]", "hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.200))]", "focus:outline-none", "flex", "items-center", "justify-center", "transition-colors"], [1, "flex", "items-center", "p-0.5", "bg-[var(--lt-bg-header,theme(colors.slate.200))]", "rounded-[10px]"], [3, "click"], [1, "grid", "grid-cols-1", "md:grid-cols-2", "gap-4", "mt-2"], [1, "block", "font-medium", "text-[var(--lt-text-primary,theme(colors.gray.700))]"], [1, "mt-1", "block", "w-full", "pl-3", "pr-8", "py-1.5", "border", "border-transparent", "hover:border-[var(--lt-border-default,theme(colors.slate.300))]", "focus:outline-none", "focus:ring-[var(--lt-border-editing,theme(colors.blue.500))]", "focus:border-[var(--lt-border-editing,theme(colors.blue.500))]", "rounded-[10px]", "bg-[var(--lt-input-bg,white)]", "text-[var(--lt-text-primary,inherit)]", 3, "ngModelChange", "ngModel"], ["value", "null"], [3, "value"], [1, "mt-1", "block", "w-full", "pl-3", "pr-8", "py-1.5", "border", "border-transparent", "hover:border-[var(--lt-border-default,theme(colors.slate.300))]", "focus:outline-none", "focus:ring-[var(--lt-border-editing,theme(colors.blue.500))]", "focus:border-[var(--lt-border-editing,theme(colors.blue.500))]", "rounded-[10px]", "bg-[var(--lt-input-bg,white)]", "text-[var(--lt-text-primary,inherit)]", "disabled:opacity-50", 3, "ngModelChange", "ngModel", "disabled"], [1, "fixed", "opacity-0", "pointer-events-none", "z-[120]", "bg-slate-800", "text-white", "text-sm", "rounded-md", "shadow-lg", "p-2", "leading-tight", "transition-opacity", "duration-200", "max-w-xs"], [1, "p-1.5", "leading-none", "h-7", "w-7", "rounded-full", "text-[var(--lt-icon-default,theme(colors.gray.500))]", "hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.200))]", "focus:outline-none", "flex", "items-center", "justify-center", "transition-colors", 3, "click"], [1, "pi", "pi-check", "text-[14px]", "text-green-500"], [1, "pi", "pi-copy", "text-[14px]"], [1, "text-center", "font-medium", "text-[var(--lt-text-primary,theme(colors.gray.700))]", "mb-2", "truncate"], [1, "w-full", "overflow-x-auto", "modal-scroll-content"], [1, "max-h-[400px]", "overflow-y-auto", "border", "rounded-[10px]", "border-[var(--lt-border-default,theme(colors.slate.700))]", "modal-scroll-content"], [1, "h-[400px]", "flex", "items-center", "justify-center"], [1, "w-full", "text-left", "text-[var(--lt-text-primary,theme(colors.gray.500))]"], [1, "font-semibold", "bg-[var(--lt-bg-header,theme(colors.slate.100))]", "text-[var(--lt-text-header,theme(colors.gray.600))]", "sticky", "top-0"], ["scope", "col", 1, "px-4", "py-2"], [1, "border-b", "border-[var(--lt-border-default,theme(colors.slate.700))]"], [1, "px-4", "py-2"], [1, "px-4", "py-2", "font-semibold"], [1, "text-center", "text-gray-500", "dark:text-slate-400", "p-4"]], template: function DistributionAnalysisComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "div", 2)(1, "div", 3)(2, "div", 4)(3, "div", 5)(4, "h3", 6);
            i0.ɵɵtext(5, "Distribution Analysis");
            i0.ɵɵelementEnd();
            i0.ɵɵconditionalCreate(6, DistributionAnalysisComponent_Conditional_6_Template, 3, 2, "button", 7);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "div", 8)(8, "button", 9);
            i0.ɵɵlistener("click", function DistributionAnalysisComponent_Template_button_click_8_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.setView("chart")); });
            i0.ɵɵtext(9, "Chart");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(10, "button", 9);
            i0.ɵɵlistener("click", function DistributionAnalysisComponent_Template_button_click_10_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.setView("table")); });
            i0.ɵɵtext(11, "Table");
            i0.ɵɵelementEnd()()();
            i0.ɵɵelementStart(12, "div", 10)(13, "div")(14, "label", 11);
            i0.ɵɵtext(15, "Analyze");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(16, "select", 12);
            i0.ɵɵlistener("ngModelChange", function DistributionAnalysisComponent_Template_select_ngModelChange_16_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onAnalysisFieldChange($event)); });
            i0.ɵɵelementStart(17, "option", 13);
            i0.ɵɵtext(18, "Select Field");
            i0.ɵɵelementEnd();
            i0.ɵɵrepeaterCreate(19, DistributionAnalysisComponent_For_20_Template, 2, 2, "option", 14, _forTrack0$2);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(21, "div")(22, "label", 11);
            i0.ɵɵtext(23, "Stack by");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(24, "select", 15);
            i0.ɵɵlistener("ngModelChange", function DistributionAnalysisComponent_Template_select_ngModelChange_24_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onStackByChange($event)); });
            i0.ɵɵelementStart(25, "option", 13);
            i0.ɵɵtext(26, "None");
            i0.ɵɵelementEnd();
            i0.ɵɵrepeaterCreate(27, DistributionAnalysisComponent_For_28_Template, 2, 2, "option", 14, _forTrack0$2);
            i0.ɵɵelementEnd()()()();
            i0.ɵɵconditionalCreate(29, DistributionAnalysisComponent_Conditional_29_Template, 4, 3)(30, DistributionAnalysisComponent_Conditional_30_Template, 2, 1);
            i0.ɵɵelement(31, "div", 16, 0);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance(4);
            i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-title, 18px)");
            i0.ɵɵadvance(2);
            i0.ɵɵconditional(ctx.state()().view === "table" && ctx.tableData() ? 6 : -1);
            i0.ɵɵadvance(2);
            i0.ɵɵclassMap("px-2 py-1 rounded-lg " + (ctx.state()().view === "chart" ? "bg-[var(--lt-bg-header-hover)] shadow font-medium text-[var(--lt-text-primary)]" : "text-[var(--lt-text-header)]"));
            i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
            i0.ɵɵadvance(2);
            i0.ɵɵclassMap("px-2 py-1 rounded-lg " + (ctx.state()().view === "table" ? "bg-[var(--lt-bg-header-hover)] shadow font-medium text-[var(--lt-text-primary)]" : "text-[var(--lt-text-header)]"));
            i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
            i0.ɵɵadvance(4);
            i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
            i0.ɵɵadvance(2);
            i0.ɵɵstyleProp("font-size", "var(--lt-font-input, 14px)");
            i0.ɵɵproperty("ngModel", ctx.state()().analysisField);
            i0.ɵɵadvance(3);
            i0.ɵɵrepeater(ctx.analysisOptions());
            i0.ɵɵadvance(3);
            i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
            i0.ɵɵadvance(2);
            i0.ɵɵstyleProp("font-size", "var(--lt-font-input, 14px)");
            i0.ɵɵproperty("ngModel", ctx.state()().stackByField)("disabled", ctx.state()().analysisField === null);
            i0.ɵɵadvance(3);
            i0.ɵɵrepeater(ctx.stackByOptions());
            i0.ɵɵadvance(2);
            i0.ɵɵconditional(ctx.state()().view === "chart" ? 29 : 30);
            i0.ɵɵadvance(2);
            i0.ɵɵstyleProp("font-family", "var(--lt-font-family-mono, monospace)");
        } }, dependencies: [CommonModule, FormsModule, i1.NgSelectOption, i1.ɵNgSelectMultipleOption, i1.SelectControlValueAccessor, i1.NgControlStatus, i1.NgModel], encapsulation: 2, changeDetection: 0 }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DistributionAnalysisComponent, [{
        type: Component,
        args: [{ selector: 'long-distribution-analysis', imports: [CommonModule, FormsModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"relative h-full\">\n  <div class=\"pb-2 mb-4\">\n      <div class=\"flex justify-between items-center\">\n          <div class=\"flex items-center gap-3\">\n              <h3 class=\"font-semibold text-[var(--lt-text-primary,theme(colors.gray.800))]\" [style.fontSize]=\"'var(--lt-font-modal-title, 18px)'\">Distribution Analysis</h3>\n              @if (state()().view === 'table' && tableData()) {\n                  <button (click)=\"copyTableDataToClipboard()\" [attr.title]=\"copyState() === 'idle' ? 'Copy table data' : 'Copied!'\" class=\"p-1.5 leading-none h-7 w-7 rounded-full text-[var(--lt-icon-default,theme(colors.gray.500))] hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.200))] focus:outline-none flex items-center justify-center transition-colors\">\n                      @if (copyState() === 'copied') {\n                          <i class=\"pi pi-check text-[14px] text-green-500\"></i>\n                      } @else {\n                          <i class=\"pi pi-copy text-[14px]\"></i>\n                      }\n                  </button>\n              }\n          </div>\n          <div class=\"flex items-center p-0.5 bg-[var(--lt-bg-header,theme(colors.slate.200))] rounded-[10px]\">\n              <button (click)=\"setView('chart')\" [class]=\"'px-2 py-1 rounded-lg ' + (state()().view === 'chart' ? 'bg-[var(--lt-bg-header-hover)] shadow font-medium text-[var(--lt-text-primary)]' : 'text-[var(--lt-text-header)]')\" [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">Chart</button>\n              <button (click)=\"setView('table')\" [class]=\"'px-2 py-1 rounded-lg ' + (state()().view === 'table' ? 'bg-[var(--lt-bg-header-hover)] shadow font-medium text-[var(--lt-text-primary)]' : 'text-[var(--lt-text-header)]')\" [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">Table</button>\n          </div>\n      </div>\n      <div class=\"grid grid-cols-1 md:grid-cols-2 gap-4 mt-2\">\n          <div>\n              <label class=\"block font-medium text-[var(--lt-text-primary,theme(colors.gray.700))]\" [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">Analyze</label>\n              <select [ngModel]=\"state()().analysisField\" (ngModelChange)=\"onAnalysisFieldChange($event)\" class=\"mt-1 block w-full pl-3 pr-8 py-1.5 border border-transparent hover:border-[var(--lt-border-default,theme(colors.slate.300))] focus:outline-none focus:ring-[var(--lt-border-editing,theme(colors.blue.500))] focus:border-[var(--lt-border-editing,theme(colors.blue.500))] rounded-[10px] bg-[var(--lt-input-bg,white)] text-[var(--lt-text-primary,inherit)]\" [style.fontSize]=\"'var(--lt-font-input, 14px)'\">\n                  <option value=\"null\">Select Field</option>\n                  @for (col of analysisOptions(); track col.value) { <option [value]=\"col.value\">{{ col.label }}</option> }\n              </select>\n          </div>\n          <div>\n              <label class=\"block font-medium text-[var(--lt-text-primary,theme(colors.gray.700))]\" [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">Stack by</label>\n              <select [ngModel]=\"state()().stackByField\" (ngModelChange)=\"onStackByChange($event)\" [disabled]=\"state()().analysisField === null\" class=\"mt-1 block w-full pl-3 pr-8 py-1.5 border border-transparent hover:border-[var(--lt-border-default,theme(colors.slate.300))] focus:outline-none focus:ring-[var(--lt-border-editing,theme(colors.blue.500))] focus:border-[var(--lt-border-editing,theme(colors.blue.500))] rounded-[10px] bg-[var(--lt-input-bg,white)] text-[var(--lt-text-primary,inherit)] disabled:opacity-50\" [style.fontSize]=\"'var(--lt-font-input, 14px)'\">\n                  <option value=\"null\">None</option>\n                  @for (col of stackByOptions(); track col.value) { <option [value]=\"col.value\">{{ col.label }}</option> }\n              </select>\n          </div>\n      </div>\n  </div>\n  \n  @if (state()().view === 'chart') {\n      <h4 class=\"text-center font-medium text-[var(--lt-text-primary,theme(colors.gray.700))] mb-2 truncate\" [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">{{ chartTitle() }}</h4>\n      <div #distributionChartContainer class=\"w-full overflow-x-auto modal-scroll-content\"></div>\n  } @else {\n      @if (tableData(); as tableData) {\n          <div class=\"max-h-[400px] overflow-y-auto border rounded-[10px] border-[var(--lt-border-default,theme(colors.slate.700))] modal-scroll-content\">\n              <table class=\"w-full text-left text-[var(--lt-text-primary,theme(colors.gray.500))]\" [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">\n                  <thead class=\"font-semibold bg-[var(--lt-bg-header,theme(colors.slate.100))] text-[var(--lt-text-header,theme(colors.gray.600))] sticky top-0\">\n                      <tr>\n                          @for(header of tableData.headers; track header) {\n                              <th scope=\"col\" class=\"px-4 py-2\">{{ header }}</th>\n                          }\n                      </tr>\n                  </thead>\n                  <tbody>\n                      @if (!tableData.isStacked) {\n                          @for (row of tableData.rows; track row.value) {\n                              <tr class=\"border-b border-[var(--lt-border-default,theme(colors.slate.700))]\">\n                                  <td class=\"px-4 py-2\">{{ row.value }}</td>\n                                  <td class=\"px-4 py-2\">{{ row.count }}</td>\n                              </tr>\n                          }\n                      } @else {\n                          @for (row of tableData.rows; track row.primaryValue) {\n                              <tr class=\"border-b border-[var(--lt-border-default,theme(colors.slate.700))]\">\n                                  <td class=\"px-4 py-2\">{{ row.primaryValue }}</td>\n                                  @for (key of tableData.stackKeys; track key) {\n                                      <td class=\"px-4 py-2\">{{ row[key] }}</td>\n                                  }\n                                  <td class=\"px-4 py-2 font-semibold\">{{ row.total }}</td>\n                              </tr>\n                          }\n                      }\n                  </tbody>\n              </table>\n          </div>\n      } @else {\n          <div class=\"h-[400px] flex items-center justify-center\">\n              <p class=\"text-center text-gray-500 dark:text-slate-400 p-4\" [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">Select a field to analyze.</p>\n          </div>\n      }\n  }\n  <div #statsTooltip class=\"fixed opacity-0 pointer-events-none z-[120] bg-slate-800 text-white text-sm rounded-md shadow-lg p-2 leading-tight transition-opacity duration-200 max-w-xs\" [style.font-family]=\"'var(--lt-font-family-mono, monospace)'\"></div>\n</div>" }]
    }], () => [], { rows: [{ type: i0.Input, args: [{ isSignal: true, alias: "rows", required: true }] }], useCountColumn: [{ type: i0.Input, args: [{ isSignal: true, alias: "useCountColumn", required: true }] }], initialAnalysisField: [{ type: i0.Input, args: [{ isSignal: true, alias: "initialAnalysisField", required: false }] }], state: [{ type: i0.Input, args: [{ isSignal: true, alias: "state", required: true }] }], columnConfig: [{ type: i0.Input, args: [{ isSignal: true, alias: "columnConfig", required: true }] }], theme: [{ type: i0.Input, args: [{ isSignal: true, alias: "theme", required: true }] }], chartContainer: [{ type: i0.ViewChild, args: ['distributionChartContainer', { isSignal: true }] }], tooltip: [{ type: i0.ViewChild, args: ['statsTooltip', { isSignal: true }] }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(DistributionAnalysisComponent, { className: "DistributionAnalysisComponent", filePath: "lib/components/distribution-analysis/distribution-analysis.component.ts", lineNumber: 35 }); })();

const _c0$1 = ["correlationChartContainer"];
const _c1$1 = ["statsTooltip"];
const _forTrack0$1 = ($index, $item) => $item.value;
function CorrelationAnalysisComponent_For_12_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "option", 9);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const col_r2 = ctx.$implicit;
    i0.ɵɵproperty("value", col_r2.value);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(col_r2.label);
} }
function CorrelationAnalysisComponent_For_20_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "option", 9);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const col_r3 = ctx.$implicit;
    i0.ɵɵproperty("value", col_r3.value);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(col_r3.label);
} }
function CorrelationAnalysisComponent_For_28_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "option", 9);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const col_r4 = ctx.$implicit;
    i0.ɵɵproperty("value", col_r4.value);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(col_r4.label);
} }
class CorrelationAnalysisComponent {
    constructor() {
        this.rows = input.required(...(ngDevMode ? [{ debugName: "rows" }] : []));
        this.useCountColumn = input.required(...(ngDevMode ? [{ debugName: "useCountColumn" }] : []));
        this.state = input.required(...(ngDevMode ? [{ debugName: "state" }] : []));
        this.columnConfig = input.required(...(ngDevMode ? [{ debugName: "columnConfig" }] : []));
        this.theme = input.required(...(ngDevMode ? [{ debugName: "theme" }] : []));
        this.chartContainer = viewChild('correlationChartContainer', ...(ngDevMode ? [{ debugName: "chartContainer" }] : []));
        this.tooltip = viewChild('statsTooltip', ...(ngDevMode ? [{ debugName: "tooltip" }] : []));
        this.cdr = inject(ChangeDetectorRef);
        this.hasInitialized = false;
        this.countColumnIndex = computed(() => this.columnConfig().findIndex(c => c.name.toLowerCase() === 'count'), ...(ngDevMode ? [{ debugName: "countColumnIndex" }] : []));
        this.analysisOptions = computed(() => {
            return this.columnConfig()
                .map((col, index) => {
                const editor = col?.editor;
                let type = 'token';
                if (editor === 'dropdown' || editor === 'checkbox')
                    type = 'categorical';
                else if (editor === 'numeric')
                    type = 'numeric';
                if (this.countColumnIndex() === index && this.useCountColumn())
                    return null;
                return { label: col.name, value: index, type };
            })
                .filter((c) => c !== null);
        }, ...(ngDevMode ? [{ debugName: "analysisOptions" }] : []));
        this.numericColumns = computed(() => {
            return this.analysisOptions()
                .filter(opt => opt.type === 'numeric')
                .map(opt => ({ label: opt.label, value: opt.value }));
        }, ...(ngDevMode ? [{ debugName: "numericColumns" }] : []));
        this.categoryOptions = computed(() => this.analysisOptions().filter(opt => opt.value !== this.state()().fieldX && opt.value !== this.state()().fieldY), ...(ngDevMode ? [{ debugName: "categoryOptions" }] : []));
        this.chartTitle = computed(() => {
            const state = this.state()();
            if (state.fieldX === null || state.fieldY === null)
                return '';
            const numericOptions = this.numericColumns();
            const xLabel = numericOptions.find(o => o.value === state.fieldX)?.label;
            const yLabel = numericOptions.find(o => o.value === state.fieldY)?.label;
            if (!xLabel || !yLabel)
                return '';
            let title = `Correlation between ${xLabel} and ${yLabel}`;
            const catField = state.categoryField;
            if (catField !== null) {
                const catLabel = this.categoryOptions().find(o => o.value === catField)?.label;
                if (catLabel)
                    title += `, categorized by ${catLabel}`;
            }
            return title;
        }, ...(ngDevMode ? [{ debugName: "chartTitle" }] : []));
        this.correlationData = computed(() => {
            const dataRows = this.rows();
            const { fieldX, fieldY, categoryField } = this.state()();
            if (fieldX === null || fieldY === null)
                return [];
            const nameColIndex = this.columnConfig().findIndex(c => { const val = c.name.toLowerCase(); return val.includes('name') || val.includes('title'); });
            // FIX: Replaced map/filter with flatMap to resolve a complex TypeScript type inference error with the type guard.
            // flatMap naturally handles filtering out null/empty values while mapping and ensures the correct output type.
            return dataRows.flatMap((row) => {
                const x = row.cells[fieldX]?.value;
                const y = row.cells[fieldY]?.value;
                if (typeof x !== 'number' || typeof y !== 'number')
                    return [];
                const point = {
                    x: x,
                    y: y,
                    category: categoryField !== null ? String(row.cells[categoryField]?.value ?? 'N/A') : undefined,
                    name: nameColIndex > -1 ? String(row.cells[nameColIndex]?.value ?? `Row ${row.originalModelIndex}`) : `Row ${row.originalModelIndex}`
                };
                return [point];
            });
        }, ...(ngDevMode ? [{ debugName: "correlationData" }] : []));
        effect(() => {
            this.rows();
            this.columnConfig();
            this.initializeFields();
            this.cdr.markForCheck();
        });
        effect(() => {
            if (this.chartContainer()) {
                this.renderChart();
            }
        });
    }
    initializeFields() {
        const state = this.state();
        const numericCols = this.numericColumns();
        if (state().fieldX !== null && !numericCols.some(c => c.value === state().fieldX)) {
            state.update(s => ({ ...s, fieldX: null }));
        }
        if (state().fieldY !== null && !numericCols.some(c => c.value === state().fieldY)) {
            state.update(s => ({ ...s, fieldY: null }));
        }
        const catOptions = this.categoryOptions();
        if (state().categoryField !== null && !catOptions.some(o => o.value === state().categoryField)) {
            state.update(s => ({ ...s, categoryField: null }));
        }
        if (this.hasInitialized)
            return;
        if (state().fieldX === null && numericCols.length > 0) {
            state.update(s => ({ ...s, fieldX: numericCols[0].value }));
        }
        if (state().fieldY === null) {
            state.update(s => ({ ...s, fieldY: numericCols.length > 1 ? numericCols[1].value : (numericCols.length > 0 ? numericCols[0].value : null) }));
        }
        this.hasInitialized = true;
    }
    renderChart() {
        const data = this.correlationData();
        setTimeout(() => {
            if (this.chartContainer()) {
                const xLabel = this.numericColumns().find(c => c.value === this.state()().fieldX)?.label ?? 'X-Axis';
                const yLabel = this.numericColumns().find(c => c.value === this.state()().fieldY)?.label ?? 'Y-Axis';
                const catField = this.state()().categoryField;
                const catFieldInfo = catField !== null ? this.analysisOptions().find(opt => opt.value === catField) : undefined;
                let dropdownOptions;
                if (catFieldInfo && this.rows().length > 0) {
                    const colConfig = this.columnConfig()[catFieldInfo.value];
                    if (colConfig?.editor === 'dropdown' && colConfig.options) {
                        dropdownOptions = colConfig.options.map(opt => typeof opt === 'string' ? { value: opt, color: '#e5e7eb' } : opt);
                    }
                }
                this.renderScatterPlot(this.chartContainer().nativeElement, data, xLabel, yLabel, catFieldInfo?.type, dropdownOptions);
            }
        });
    }
    onFieldXChange(v) { this.state().update(s => ({ ...s, fieldX: v === 'null' ? null : Number(v) })); }
    onFieldYChange(v) { this.state().update(s => ({ ...s, fieldY: v === 'null' ? null : Number(v) })); }
    onCategoryFieldChange(v) { this.state().update(s => ({ ...s, categoryField: v === 'null' ? null : Number(v) })); }
    renderScatterPlot(container, data, xLabel, yLabel, categoryType, dropdownOptions) {
        select(container).html('');
        if (data.length === 0) {
            select(container).html(`<p class="text-sm text-center text-gray-500 dark:text-slate-400 p-4">Select two numeric fields to see their correlation.</p>`);
            return;
        }
        const pointMap = new Map();
        data.forEach(p => {
            const key = `${p.x}-${p.y}-${p.category}`;
            if (pointMap.has(key)) {
                const point = pointMap.get(key);
                point.count++;
                point.names.push(p.name);
            }
            else {
                pointMap.set(key, { x: p.x, y: p.y, category: p.category, count: 1, names: [p.name] });
            }
        });
        const aggregatedData = Array.from(pointMap.values());
        const isDark = document.documentElement.classList.contains('dark');
        const textColor = this.theme().colors.graphSecondary;
        const margin = { top: 5, right: 100, bottom: 60, left: 60 };
        const width = container.clientWidth - margin.left - margin.right;
        const height = 400 - margin.top - margin.bottom;
        const svg = select(container).append('svg').attr('width', width + margin.left + margin.right).attr('height', height + margin.top + margin.bottom).append('g').attr('transform', `translate(${margin.left},${margin.top})`);
        const x = scaleLinear().domain(extent(data, d => d.x)).range([0, width]).nice();
        const y = scaleLinear().domain(extent(data, d => d.y)).range([height, 0]).nice();
        const maxCount = max(aggregatedData, d => d.count) || 1;
        const radius = scaleSqrt().domain([1, maxCount]).range([4, 15]);
        const categories = Array.from(new Set(data.map(d => d.category))).filter(c => c !== undefined);
        let color;
        const hasCategory = categories.length > 0;
        if (hasCategory && dropdownOptions) {
            const colorMap = new Map(dropdownOptions.map(opt => [opt.value, opt.color]));
            color = scaleOrdinal(categories.map(cat => colorMap.get(cat) || '#cccccc')).domain(categories);
        }
        else if (hasCategory && categoryType === 'numeric') {
            const numericCategories = categories.map(c => Number(c)).filter(n => !isNaN(n));
            if (numericCategories.length > 0) {
                color = scaleSequential(interpolatePlasma).domain(extent(numericCategories));
            }
        }
        else if (hasCategory) {
            color = scaleOrdinal(schemeSet2).domain(categories);
        }
        const xAxisGroup = svg.append('g').attr('transform', `translate(0,${height})`).call(axisBottom(x));
        xAxisGroup.selectAll('text').style('fill', textColor).style('font-size', 'var(--lt-font-chart-axis-label, 10px)');
        xAxisGroup.select('.domain').style('stroke', textColor);
        xAxisGroup.selectAll('.tick line').style('stroke', textColor);
        svg.append('text').attr('text-anchor', 'middle').attr('x', width / 2).attr('y', height + 45).text(xLabel).style('fill', textColor).style('font-size', 'var(--lt-font-chart-axis-title, 12px)');
        const yAxisGroup = svg.append('g').call(axisLeft(y));
        yAxisGroup.selectAll('text').style('fill', textColor).style('font-size', 'var(--lt-font-chart-axis-label, 10px)');
        yAxisGroup.select('.domain').style('stroke', textColor);
        yAxisGroup.selectAll('.tick line').style('stroke', textColor);
        svg.append('text').attr('text-anchor', 'end').attr('transform', 'rotate(-90)').attr('y', -margin.left + 20).attr('x', -height / 2).text(yLabel).style('fill', textColor).style('font-size', 'var(--lt-font-chart-axis-title, 12px)');
        const tooltip = select(this.tooltip().nativeElement);
        svg.append('g').selectAll('dot').data(aggregatedData).enter().append('circle').attr('cx', d => x(d.x)).attr('cy', d => y(d.y)).attr('r', d => radius(d.count))
            // Fix: Corrected the logic for point coloring. The original code incorrectly passed a number to an ordinal scale 
            // when a category was numeric but also had dropdown options. This ensures the correct value type is always used.
            .style('fill', d => d.category && color ? (categoryType === 'numeric' && !dropdownOptions ? color(Number(d.category)) : color(d.category)) : this.theme().colors.graphPrimary).style('opacity', '0.7')
            .on('mouseover', (event, d) => {
            select(event.currentTarget).attr('stroke', isDark ? '#fff' : '#000').attr('stroke-width', 2).style('opacity', '1');
            let tipHtml = `<strong>${xLabel}:</strong> ${d.x}<br/><strong>${yLabel}:</strong> ${d.y}`;
            if (d.category)
                tipHtml += `<br/><strong>Category:</strong> ${d.category}`;
            tipHtml += `<br/><strong>Count:</strong> ${d.count}`;
            if (d.names?.length) {
                tipHtml += `<hr class="my-1 border-slate-500">`;
                const maxNames = 5;
                d.names.slice(0, maxNames).forEach(name => {
                    tipHtml += `<div class="truncate">- ${name}</div>`;
                });
                if (d.names.length > maxNames) {
                    tipHtml += `<div>...and ${d.names.length - maxNames} more</div>`;
                }
            }
            tooltip.style('opacity', '1').html(tipHtml);
        }).on('mousemove', (event) => tooltip.style('left', (event.clientX + 15) + 'px').style('top', (event.clientY + 15) + 'px'))
            .on('mouseout', (event) => {
            select(event.currentTarget).attr('stroke', null).attr('stroke-width', null).style('opacity', '0.7');
            tooltip.style('opacity', '0');
        });
        if (color && hasCategory) {
            if (categoryType === 'numeric' && !dropdownOptions) {
                this._renderGradientLegend(svg, color, width + 20, 0, 150, "Value");
            }
            else {
                const legend = svg.selectAll('.legend').data(color.domain()).enter().append('g')
                    .attr('class', 'legend')
                    .attr('transform', (d, i) => `translate(0,${i * 20})`)
                    .style('cursor', 'default')
                    .on('mouseover', (event, d) => {
                    select(event.currentTarget).select('text').style('font-weight', 'bold');
                    tooltip.style('opacity', '1').html(String(d));
                })
                    .on('mousemove', (event) => tooltip.style('left', (event.clientX + 15) + 'px').style('top', (event.clientY + 15) + 'px'))
                    .on('mouseout', (event) => {
                    select(event.currentTarget).select('text').style('font-weight', 'normal');
                    tooltip.style('opacity', '0');
                });
                legend.append('rect').attr('x', width + 10).attr('width', 18).attr('height', 18).style('fill', d => color(String(d)));
                legend.append('text').attr('x', width + 34).attr('y', 9).attr('dy', '.35em').style('text-anchor', 'start').text(d => this.truncateText(String(d), 12)).style('fill', textColor).style('font-size', 'var(--lt-font-chart-legend, 12px)');
            }
        }
    }
    // Fix: The ScaleSequentialType was incorrectly defined with a 'never' parameter. 
    // This has been corrected to align with modern D3 typings, preventing potential type errors during compilation.
    _renderGradientLegend(svg, colorScale, legendX, legendY, height, title) {
        const textColor = this.theme().colors.graphSecondary;
        const [min, max] = colorScale.domain();
        if (min === undefined || max === undefined)
            return;
        const legendId = `legend-gradient-${Math.random().toString(36).substring(2, 9)}`;
        const defs = svg.append("defs");
        const linearGradient = defs.append("linearGradient")
            .attr("id", legendId)
            .attr("x1", "0%").attr("y1", "100%")
            .attr("x2", "0%").attr("y2", "0%");
        linearGradient.selectAll("stop")
            .data(range(0, 1.01, 0.1).map(t => ({ offset: `${t * 100}%`, color: colorScale(min + t * (max - min)) })))
            .enter().append("stop")
            .attr("offset", d => d.offset)
            .attr("stop-color", d => d.color);
        const legendWidth = 18;
        svg.append("rect")
            .attr("x", legendX)
            .attr("y", legendY)
            .attr("width", legendWidth)
            .attr("height", height)
            .style("fill", `url(#${legendId})`);
        const legendScale = scaleLinear().domain([min, max]).range([height, 0]);
        const legendAxis = axisRight(legendScale).ticks(5).tickFormat(format(".2s"));
        const legendAxisGroup = svg.append("g")
            .attr("class", "legend-axis")
            .attr("transform", `translate(${legendX + legendWidth}, ${legendY})`)
            .call(legendAxis)
            .style('font-size', 'var(--lt-font-chart-axis-label, 10px)');
        legendAxisGroup.select(".domain").remove();
        legendAxisGroup.selectAll('text').style('fill', textColor);
        legendAxisGroup.selectAll('.tick line').style('stroke', textColor);
        svg.append("text")
            .attr("x", legendX)
            .attr("y", legendY - 5)
            .style("text-anchor", "start")
            .text(title)
            .style("font-weight", "bold")
            .style("fill", textColor)
            .style('font-size', 'var(--lt-font-chart-legend, 12px)');
    }
    truncateText(text, maxLength) {
        if (text.length <= maxLength)
            return text;
        return text.slice(0, maxLength - 1) + '…';
    }
    static { this.ɵfac = function CorrelationAnalysisComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || CorrelationAnalysisComponent)(); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: CorrelationAnalysisComponent, selectors: [["long-correlation-analysis"]], viewQuery: function CorrelationAnalysisComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuerySignal(ctx.chartContainer, _c0$1, 5)(ctx.tooltip, _c1$1, 5);
        } if (rf & 2) {
            i0.ɵɵqueryAdvance(2);
        } }, inputs: { rows: [1, "rows"], useCountColumn: [1, "useCountColumn"], state: [1, "state"], columnConfig: [1, "columnConfig"], theme: [1, "theme"] }, decls: 35, vars: 22, consts: [["correlationChartContainer", ""], ["statsTooltip", ""], [1, "relative", "h-full"], [1, "pb-2", "mb-4"], [1, "font-semibold", "text-[var(--lt-text-primary,theme(colors.gray.800))]"], [1, "grid", "grid-cols-1", "md:grid-cols-3", "gap-4", "mt-2"], [1, "block", "font-medium", "text-[var(--lt-text-primary,theme(colors.gray.700))]"], [1, "mt-1", "block", "w-full", "pl-3", "pr-8", "py-1.5", "border", "border-transparent", "hover:border-[var(--lt-border-default,theme(colors.slate.300))]", "focus:outline-none", "focus:ring-[var(--lt-border-editing,theme(colors.blue.500))]", "focus:border-[var(--lt-border-editing,theme(colors.blue.500))]", "rounded-[10px]", "bg-[var(--lt-input-bg,white)]", "text-[var(--lt-text-primary,inherit)]", 3, "ngModelChange", "ngModel"], ["value", "null"], [3, "value"], [1, "text-center", "font-medium", "text-[var(--lt-text-primary,theme(colors.gray.700))]", "mb-2", "truncate"], [1, "w-full", "h-[400px]"], [1, "fixed", "opacity-0", "pointer-events-none", "z-[120]", "bg-slate-800", "text-white", "text-sm", "rounded-md", "shadow-lg", "p-2", "leading-tight", "transition-opacity", "duration-200", "max-w-xs"]], template: function CorrelationAnalysisComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "div", 2)(1, "div", 3)(2, "h3", 4);
            i0.ɵɵtext(3, "Correlation Analysis");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "div", 5)(5, "div")(6, "label", 6);
            i0.ɵɵtext(7, "X-Axis");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(8, "select", 7);
            i0.ɵɵlistener("ngModelChange", function CorrelationAnalysisComponent_Template_select_ngModelChange_8_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onFieldXChange($event)); });
            i0.ɵɵelementStart(9, "option", 8);
            i0.ɵɵtext(10, "Select Field");
            i0.ɵɵelementEnd();
            i0.ɵɵrepeaterCreate(11, CorrelationAnalysisComponent_For_12_Template, 2, 2, "option", 9, _forTrack0$1);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(13, "div")(14, "label", 6);
            i0.ɵɵtext(15, "Y-Axis");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(16, "select", 7);
            i0.ɵɵlistener("ngModelChange", function CorrelationAnalysisComponent_Template_select_ngModelChange_16_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onFieldYChange($event)); });
            i0.ɵɵelementStart(17, "option", 8);
            i0.ɵɵtext(18, "Select Field");
            i0.ɵɵelementEnd();
            i0.ɵɵrepeaterCreate(19, CorrelationAnalysisComponent_For_20_Template, 2, 2, "option", 9, _forTrack0$1);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(21, "div")(22, "label", 6);
            i0.ɵɵtext(23, "Categorize by");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(24, "select", 7);
            i0.ɵɵlistener("ngModelChange", function CorrelationAnalysisComponent_Template_select_ngModelChange_24_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onCategoryFieldChange($event)); });
            i0.ɵɵelementStart(25, "option", 8);
            i0.ɵɵtext(26, "None");
            i0.ɵɵelementEnd();
            i0.ɵɵrepeaterCreate(27, CorrelationAnalysisComponent_For_28_Template, 2, 2, "option", 9, _forTrack0$1);
            i0.ɵɵelementEnd()()()();
            i0.ɵɵelementStart(29, "h4", 10);
            i0.ɵɵtext(30);
            i0.ɵɵelementEnd();
            i0.ɵɵelement(31, "div", 11, 0)(33, "div", 12, 1);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-title, 18px)");
            i0.ɵɵadvance(4);
            i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
            i0.ɵɵadvance(2);
            i0.ɵɵstyleProp("font-size", "var(--lt-font-input, 14px)");
            i0.ɵɵproperty("ngModel", ctx.state()().fieldX);
            i0.ɵɵadvance(3);
            i0.ɵɵrepeater(ctx.numericColumns());
            i0.ɵɵadvance(3);
            i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
            i0.ɵɵadvance(2);
            i0.ɵɵstyleProp("font-size", "var(--lt-font-input, 14px)");
            i0.ɵɵproperty("ngModel", ctx.state()().fieldY);
            i0.ɵɵadvance(3);
            i0.ɵɵrepeater(ctx.numericColumns());
            i0.ɵɵadvance(3);
            i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
            i0.ɵɵadvance(2);
            i0.ɵɵstyleProp("font-size", "var(--lt-font-input, 14px)");
            i0.ɵɵproperty("ngModel", ctx.state()().categoryField);
            i0.ɵɵadvance(3);
            i0.ɵɵrepeater(ctx.categoryOptions());
            i0.ɵɵadvance(2);
            i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
            i0.ɵɵadvance();
            i0.ɵɵtextInterpolate(ctx.chartTitle());
            i0.ɵɵadvance(3);
            i0.ɵɵstyleProp("font-family", "var(--lt-font-family-mono, monospace)");
        } }, dependencies: [CommonModule, FormsModule, i1.NgSelectOption, i1.ɵNgSelectMultipleOption, i1.SelectControlValueAccessor, i1.NgControlStatus, i1.NgModel], encapsulation: 2, changeDetection: 0 }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CorrelationAnalysisComponent, [{
        type: Component,
        args: [{ selector: 'long-correlation-analysis', imports: [CommonModule, FormsModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"relative h-full\">\n  <div class=\"pb-2 mb-4\">\n      <h3 class=\"font-semibold text-[var(--lt-text-primary,theme(colors.gray.800))]\" [style.fontSize]=\"'var(--lt-font-modal-title, 18px)'\">Correlation Analysis</h3>\n      <div class=\"grid grid-cols-1 md:grid-cols-3 gap-4 mt-2\">\n          <div>\n              <label class=\"block font-medium text-[var(--lt-text-primary,theme(colors.gray.700))]\" [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">X-Axis</label>\n              <select [ngModel]=\"state()().fieldX\" (ngModelChange)=\"onFieldXChange($event)\" class=\"mt-1 block w-full pl-3 pr-8 py-1.5 border border-transparent hover:border-[var(--lt-border-default,theme(colors.slate.300))] focus:outline-none focus:ring-[var(--lt-border-editing,theme(colors.blue.500))] focus:border-[var(--lt-border-editing,theme(colors.blue.500))] rounded-[10px] bg-[var(--lt-input-bg,white)] text-[var(--lt-text-primary,inherit)]\" [style.fontSize]=\"'var(--lt-font-input, 14px)'\">\n                  <option value=\"null\">Select Field</option>\n                  @for (col of numericColumns(); track col.value) { <option [value]=\"col.value\">{{ col.label }}</option> }\n              </select>\n          </div>\n          <div>\n              <label class=\"block font-medium text-[var(--lt-text-primary,theme(colors.gray.700))]\" [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">Y-Axis</label>\n              <select [ngModel]=\"state()().fieldY\" (ngModelChange)=\"onFieldYChange($event)\" class=\"mt-1 block w-full pl-3 pr-8 py-1.5 border border-transparent hover:border-[var(--lt-border-default,theme(colors.slate.300))] focus:outline-none focus:ring-[var(--lt-border-editing,theme(colors.blue.500))] focus:border-[var(--lt-border-editing,theme(colors.blue.500))] rounded-[10px] bg-[var(--lt-input-bg,white)] text-[var(--lt-text-primary,inherit)]\" [style.fontSize]=\"'var(--lt-font-input, 14px)'\">\n                  <option value=\"null\">Select Field</option>\n                  @for (col of numericColumns(); track col.value) { <option [value]=\"col.value\">{{ col.label }}</option> }\n              </select>\n          </div>\n          <div>\n              <label class=\"block font-medium text-[var(--lt-text-primary,theme(colors.gray.700))]\" [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">Categorize by</label>\n              <select [ngModel]=\"state()().categoryField\" (ngModelChange)=\"onCategoryFieldChange($event)\" class=\"mt-1 block w-full pl-3 pr-8 py-1.5 border border-transparent hover:border-[var(--lt-border-default,theme(colors.slate.300))] focus:outline-none focus:ring-[var(--lt-border-editing,theme(colors.blue.500))] focus:border-[var(--lt-border-editing,theme(colors.blue.500))] rounded-[10px] bg-[var(--lt-input-bg,white)] text-[var(--lt-text-primary,inherit)]\" [style.fontSize]=\"'var(--lt-font-input, 14px)'\">\n                  <option value=\"null\">None</option>\n                  @for (col of categoryOptions(); track col.value) { <option [value]=\"col.value\">{{ col.label }}</option> }\n              </select>\n          </div>\n      </div>\n  </div>\n  <h4 class=\"text-center font-medium text-[var(--lt-text-primary,theme(colors.gray.700))] mb-2 truncate\" [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">{{ chartTitle() }}</h4>\n  <div #correlationChartContainer class=\"w-full h-[400px]\"></div>\n  <div #statsTooltip class=\"fixed opacity-0 pointer-events-none z-[120] bg-slate-800 text-white text-sm rounded-md shadow-lg p-2 leading-tight transition-opacity duration-200 max-w-xs\" [style.font-family]=\"'var(--lt-font-family-mono, monospace)'\"></div>\n</div>" }]
    }], () => [], { rows: [{ type: i0.Input, args: [{ isSignal: true, alias: "rows", required: true }] }], useCountColumn: [{ type: i0.Input, args: [{ isSignal: true, alias: "useCountColumn", required: true }] }], state: [{ type: i0.Input, args: [{ isSignal: true, alias: "state", required: true }] }], columnConfig: [{ type: i0.Input, args: [{ isSignal: true, alias: "columnConfig", required: true }] }], theme: [{ type: i0.Input, args: [{ isSignal: true, alias: "theme", required: true }] }], chartContainer: [{ type: i0.ViewChild, args: ['correlationChartContainer', { isSignal: true }] }], tooltip: [{ type: i0.ViewChild, args: ['statsTooltip', { isSignal: true }] }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(CorrelationAnalysisComponent, { className: "CorrelationAnalysisComponent", filePath: "lib/components/correlation-analysis/correlation-analysis.component.ts", lineNumber: 33 }); })();

function TableStatsComponent_Conditional_0_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    const _r2 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "label", 9)(1, "input", 10);
    i0.ɵɵlistener("change", function TableStatsComponent_Conditional_0_Conditional_5_Template_input_change_1_listener($event) { i0.ɵɵrestoreView(_r2); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.useCountColumn().set($event.target.checked)); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(2, "span");
    i0.ɵɵtext(3, "Multiply by 'Count' column");
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
    i0.ɵɵadvance();
    i0.ɵɵproperty("checked", ctx_r2.useCountColumn()());
} }
function TableStatsComponent_Conditional_0_For_11_Case_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "long-distribution-analysis", 11);
} if (rf & 2) {
    const ctx_r3 = i0.ɵɵnextContext();
    const graph_r5 = ctx_r3.$implicit;
    const $index_r6 = ctx_r3.$index;
    const ctx_r2 = i0.ɵɵnextContext(2);
    const distIndex_r7 = ctx_r2.getDistributionIndex($index_r6);
    i0.ɵɵproperty("rows", ctx_r2.rows())("useCountColumn", ctx_r2.useCountColumn()())("initialAnalysisField", ctx_r2.initialAnalysisFields()[distIndex_r7])("state", graph_r5.state)("columnConfig", ctx_r2.columnConfig())("theme", ctx_r2.theme());
} }
function TableStatsComponent_Conditional_0_For_11_Case_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "long-correlation-analysis", 12);
} if (rf & 2) {
    const graph_r5 = i0.ɵɵnextContext().$implicit;
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("rows", ctx_r2.rows())("useCountColumn", ctx_r2.useCountColumn()())("state", graph_r5.state)("columnConfig", ctx_r2.columnConfig())("theme", ctx_r2.theme());
} }
function TableStatsComponent_Conditional_0_For_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵconditionalCreate(0, TableStatsComponent_Conditional_0_For_11_Case_0_Template, 1, 6, "long-distribution-analysis", 11)(1, TableStatsComponent_Conditional_0_For_11_Case_1_Template, 1, 5, "long-correlation-analysis", 12);
} if (rf & 2) {
    let tmp_11_0;
    const graph_r5 = ctx.$implicit;
    i0.ɵɵconditional((tmp_11_0 = graph_r5.type) === "distribution" ? 0 : tmp_11_0 === "correlation" ? 1 : -1);
} }
function TableStatsComponent_Conditional_0_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 0)(1, "div", 1);
    i0.ɵɵlistener("click", function TableStatsComponent_Conditional_0_Template_div_click_1_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView($event.stopPropagation()); })("mousedown", function TableStatsComponent_Conditional_0_Template_div_mousedown_1_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵelementStart(2, "header", 2)(3, "h3", 3);
    i0.ɵɵtext(4, "Table Statistics");
    i0.ɵɵelementEnd();
    i0.ɵɵconditionalCreate(5, TableStatsComponent_Conditional_0_Conditional_5_Template, 4, 3, "label", 4);
    i0.ɵɵelementStart(6, "button", 5);
    i0.ɵɵlistener("click", function TableStatsComponent_Conditional_0_Template_button_click_6_listener() { i0.ɵɵrestoreView(_r1); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.close.emit()); });
    i0.ɵɵelement(7, "i", 6);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(8, "div", 7)(9, "div", 8);
    i0.ɵɵrepeaterCreate(10, TableStatsComponent_Conditional_0_For_11_Template, 2, 1, null, null, i0.ɵɵrepeaterTrackByIndex);
    i0.ɵɵelementEnd()()()();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵstyleProp("background", "var(--lt-popup-bg, white)");
    i0.ɵɵadvance(2);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-large-title, 20px)");
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(ctx_r2.countColumnIndex() > -1 ? 5 : -1);
    i0.ɵɵadvance(5);
    i0.ɵɵrepeater(ctx_r2.graphs());
} }
class TableStatsComponent {
    constructor() {
        this.isVisible = input.required(...(ngDevMode ? [{ debugName: "isVisible" }] : []));
        this.rows = input.required(...(ngDevMode ? [{ debugName: "rows" }] : []));
        this.columnConfig = input.required(...(ngDevMode ? [{ debugName: "columnConfig" }] : []));
        this.graphs = input.required(...(ngDevMode ? [{ debugName: "graphs" }] : []));
        this.useCountColumn = input.required(...(ngDevMode ? [{ debugName: "useCountColumn" }] : []));
        this.theme = input.required(...(ngDevMode ? [{ debugName: "theme" }] : []));
        this.close = output();
        this.countColumnIndex = computed(() => this.columnConfig().findIndex(c => c.name.toLowerCase() === 'count'), ...(ngDevMode ? [{ debugName: "countColumnIndex" }] : []));
        this.analysisOptions = computed(() => {
            return this.columnConfig()
                .map((col, index) => {
                const editor = col?.editor;
                let type = 'token';
                if (editor === 'dropdown' || editor === 'checkbox')
                    type = 'categorical';
                else if (editor === 'numeric')
                    type = 'numeric';
                if (this.countColumnIndex() === index && this.useCountColumn()())
                    return null;
                return { label: col.name, value: index, type };
            })
                .filter((c) => c !== null);
        }, ...(ngDevMode ? [{ debugName: "analysisOptions" }] : []));
        this.categoricalOptions = computed(() => {
            return this.analysisOptions().filter(opt => opt.type === 'categorical');
        }, ...(ngDevMode ? [{ debugName: "categoricalOptions" }] : []));
        this.initialAnalysisFields = computed(() => {
            const catOptions = this.categoricalOptions();
            const allOptions = this.analysisOptions();
            const usedFields = new Set();
            const distributionGraphCount = this.graphs().filter(g => g.type === 'distribution').length;
            const result = [];
            for (let i = 0; i < distributionGraphCount; i++) {
                // Try to find an unused categorical option first
                let bestOption = catOptions.find(opt => !usedFields.has(opt.value));
                if (bestOption) {
                    usedFields.add(bestOption.value);
                    result.push(bestOption.value);
                    continue;
                }
                // Then try to find any unused option
                bestOption = allOptions.find(opt => !usedFields.has(opt.value));
                if (bestOption) {
                    usedFields.add(bestOption.value);
                    result.push(bestOption.value);
                    continue;
                }
                // If all are used, just return the first available option
                result.push(allOptions.length > 0 ? allOptions[0].value : null);
            }
            return result;
        }, ...(ngDevMode ? [{ debugName: "initialAnalysisFields" }] : []));
    }
    getDistributionIndex(graphIndex) {
        let distIndex = -1;
        for (let i = 0; i <= graphIndex; i++) {
            if (this.graphs()[i].type === 'distribution') {
                distIndex++;
            }
        }
        return distIndex;
    }
    static { this.ɵfac = function TableStatsComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || TableStatsComponent)(); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: TableStatsComponent, selectors: [["long-table-stats"]], inputs: { isVisible: [1, "isVisible"], rows: [1, "rows"], columnConfig: [1, "columnConfig"], graphs: [1, "graphs"], useCountColumn: [1, "useCountColumn"], theme: [1, "theme"] }, outputs: { close: "close" }, decls: 1, vars: 1, consts: [[1, "fixed", "inset-0", "bg-black/40", "backdrop-blur-sm", "z-[110]", "flex", "items-center", "justify-center", "p-4"], [1, "stats-modal-panel", "rounded-[10px]", "shadow-xl", "w-full", "max-w-6xl", "max-h-full", "flex", "flex-col", "border", "border-[var(--lt-popup-border,theme(colors.slate.200))]", 3, "click", "mousedown"], [1, "flex", "items-center", "justify-between", "p-4"], [1, "font-medium", "leading-6", "text-[var(--lt-text-primary,theme(colors.gray.900))]"], [1, "flex", "items-center", "gap-2", "text-[var(--lt-text-primary,theme(colors.gray.700))]", "cursor-pointer", 3, "fontSize"], ["type", "button", 1, "p-2", "-m-2", "rounded-full", "text-[var(--lt-icon-default,theme(colors.gray.500))]", "hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.200))]", 3, "click"], [1, "pi", "pi-times"], [1, "flex-grow", "p-6", "overflow-y-auto", "modal-scroll-content"], [1, "grid", "grid-cols-1", "lg:grid-cols-2", "gap-8"], [1, "flex", "items-center", "gap-2", "text-[var(--lt-text-primary,theme(colors.gray.700))]", "cursor-pointer"], ["type", "checkbox", 1, "h-4", "w-4", "rounded", "border", "border-[var(--lt-checkbox-border,theme(colors.slate.300))]", "focus:ring-[var(--lt-icon-active,theme(colors.blue.600))]", "bg-[var(--lt-checkbox-bg,white)]", "accent-[var(--lt-icon-active,theme(colors.blue.600))]", 3, "change", "checked"], [3, "rows", "useCountColumn", "initialAnalysisField", "state", "columnConfig", "theme"], [3, "rows", "useCountColumn", "state", "columnConfig", "theme"]], template: function TableStatsComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵconditionalCreate(0, TableStatsComponent_Conditional_0_Template, 12, 5, "div", 0);
        } if (rf & 2) {
            i0.ɵɵconditional(ctx.isVisible() ? 0 : -1);
        } }, dependencies: [CommonModule, FormsModule, DistributionAnalysisComponent, CorrelationAnalysisComponent], encapsulation: 2, changeDetection: 0 }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TableStatsComponent, [{
        type: Component,
        args: [{ selector: 'long-table-stats', imports: [CommonModule, FormsModule, DistributionAnalysisComponent, CorrelationAnalysisComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (isVisible()) {\n<div class=\"fixed inset-0 bg-black/40 backdrop-blur-sm z-[110] flex items-center justify-center p-4\">\n  <div\n    class=\"stats-modal-panel rounded-[10px] shadow-xl w-full max-w-6xl max-h-full flex flex-col border border-[var(--lt-popup-border,theme(colors.slate.200))]\"\n    (click)=\"$event.stopPropagation()\" (mousedown)=\"$event.stopPropagation()\"\n    [style.background]=\"'var(--lt-popup-bg, white)'\">\n    <header class=\"flex items-center justify-between p-4\">\n      <h3 class=\"font-medium leading-6 text-[var(--lt-text-primary,theme(colors.gray.900))]\"\n        [style.fontSize]=\"'var(--lt-font-modal-large-title, 20px)'\">Table Statistics</h3>\n      @if (countColumnIndex() > -1) {\n      <label class=\"flex items-center gap-2 text-[var(--lt-text-primary,theme(colors.gray.700))] cursor-pointer\"\n        [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">\n        <input type=\"checkbox\" [checked]=\"useCountColumn()()\"\n          (change)=\"useCountColumn().set($any($event.target).checked)\"\n          class=\"h-4 w-4 rounded border border-[var(--lt-checkbox-border,theme(colors.slate.300))] focus:ring-[var(--lt-icon-active,theme(colors.blue.600))] bg-[var(--lt-checkbox-bg,white)] accent-[var(--lt-icon-active,theme(colors.blue.600))]\">\n        <span>Multiply by 'Count' column</span>\n      </label>\n      }\n      <button (click)=\"close.emit()\" type=\"button\"\n        class=\"p-2 -m-2 rounded-full text-[var(--lt-icon-default,theme(colors.gray.500))] hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.200))]\">\n        <i class=\"pi pi-times\"></i>\n      </button>\n    </header>\n\n    <div class=\"flex-grow p-6 overflow-y-auto modal-scroll-content\">\n      <div class=\"grid grid-cols-1 lg:grid-cols-2 gap-8\">\n        @for(graph of graphs(); track $index) {\n        @switch (graph.type) {\n        @case ('distribution') {\n        @let distIndex = getDistributionIndex($index);\n        <long-distribution-analysis [rows]=\"rows()\" [useCountColumn]=\"useCountColumn()()\"\n          [initialAnalysisField]=\"initialAnalysisFields()[distIndex]\" [state]=\"graph.state\"\n          [columnConfig]=\"columnConfig()\" [theme]=\"theme()\">\n        </long-distribution-analysis>\n        }\n        @case ('correlation') {\n        <long-correlation-analysis [rows]=\"rows()\" [useCountColumn]=\"useCountColumn()()\" [state]=\"graph.state\"\n          [columnConfig]=\"columnConfig()\" [theme]=\"theme()\">\n        </long-correlation-analysis>\n        }\n        }\n        }\n      </div>\n    </div>\n  </div>\n</div>\n}" }]
    }], null, { isVisible: [{ type: i0.Input, args: [{ isSignal: true, alias: "isVisible", required: true }] }], rows: [{ type: i0.Input, args: [{ isSignal: true, alias: "rows", required: true }] }], columnConfig: [{ type: i0.Input, args: [{ isSignal: true, alias: "columnConfig", required: true }] }], graphs: [{ type: i0.Input, args: [{ isSignal: true, alias: "graphs", required: true }] }], useCountColumn: [{ type: i0.Input, args: [{ isSignal: true, alias: "useCountColumn", required: true }] }], theme: [{ type: i0.Input, args: [{ isSignal: true, alias: "theme", required: true }] }], close: [{ type: i0.Output, args: ["close"] }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(TableStatsComponent, { className: "TableStatsComponent", filePath: "lib/components/table-stats/table-stats.component.ts", lineNumber: 14 }); })();

const _c0 = ["rootContainer"];
const _c1 = ["spreadsheetContainer"];
const _c2 = ["spreadsheetTable"];
const _c3 = ["editingInput"];
const _c4 = ["dropdownEditor"];
const _c5 = ["dropdownSearchInput"];
const _c6 = ["contextMenuEl"];
const _c7 = ["filterPopupEl"];
const _c8 = ["findReplacePanelEl"];
const _c9 = ["csvImporter"];
const _c10 = ["validationTooltip"];
const _c11 = ["headerTooltip"];
const _forTrack0 = ($index, $item) => $item.originalModelIndex;
function SpreadsheetComponent_Conditional_11_For_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "col");
} if (rf & 2) {
    const ɵ$index_16_r2 = ctx.$index;
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵstyleProp("width", ctx_r2.getColumnWidth(ɵ$index_16_r2));
} }
function SpreadsheetComponent_Conditional_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵrepeaterCreate(0, SpreadsheetComponent_Conditional_11_For_1_Template, 1, 2, "col", 35, i0.ɵɵrepeaterTrackByIndex);
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵrepeater(ctx_r2.columnConfig()());
} }
function SpreadsheetComponent_Conditional_15_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "i", 20);
} }
function SpreadsheetComponent_Conditional_16_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "i", 21);
} }
function SpreadsheetComponent_For_18_Conditional_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "i");
} if (rf & 2) {
    let tmp_19_0;
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵclassMap(i0.ɵɵinterpolate1("pi text-[var(--lt-text-primary,theme(colors.slate.600))] ", ((tmp_19_0 = ctx_r2.sortConfig()) == null ? null : tmp_19_0.direction) === "asc" ? "pi-sort-amount-up-alt" : "pi-sort-amount-down"));
} }
function SpreadsheetComponent_For_18_Conditional_7_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "i", 42);
} }
function SpreadsheetComponent_For_18_Conditional_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "i", 44);
} }
function SpreadsheetComponent_For_18_Conditional_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "i", 45);
} }
function SpreadsheetComponent_For_18_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "th", 36);
    i0.ɵɵlistener("contextmenu", function SpreadsheetComponent_For_18_Template_th_contextmenu_0_listener($event) { const ɵ$index_31_r5 = i0.ɵɵrestoreView(_r4).$index; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onColumnContextMenu($event, ɵ$index_31_r5)); })("dblclick", function SpreadsheetComponent_For_18_Template_th_dblclick_0_listener() { const ɵ$index_31_r5 = i0.ɵɵrestoreView(_r4).$index; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.openColumnSettings(ɵ$index_31_r5)); })("mouseenter", function SpreadsheetComponent_For_18_Template_th_mouseenter_0_listener($event) { const ɵ$index_31_r5 = i0.ɵɵrestoreView(_r4).$index; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onHeaderMouseEnter($event, ɵ$index_31_r5)); })("mouseleave", function SpreadsheetComponent_For_18_Template_th_mouseleave_0_listener() { i0.ɵɵrestoreView(_r4); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onHeaderMouseLeave()); });
    i0.ɵɵelementStart(1, "div", 37)(2, "span", 38);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "div", 39)(5, "div", 40);
    i0.ɵɵlistener("click", function SpreadsheetComponent_For_18_Template_div_click_5_listener($event) { const ɵ$index_31_r5 = i0.ɵɵrestoreView(_r4).$index; const ctx_r2 = i0.ɵɵnextContext(); ctx_r2.toggleSort(ɵ$index_31_r5); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵconditionalCreate(6, SpreadsheetComponent_For_18_Conditional_6_Template, 1, 3, "i", 41)(7, SpreadsheetComponent_For_18_Conditional_7_Template, 1, 0, "i", 42);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(8, "div", 43);
    i0.ɵɵlistener("click", function SpreadsheetComponent_For_18_Template_div_click_8_listener($event) { const ɵ$index_31_r5 = i0.ɵɵrestoreView(_r4).$index; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.toggleFilterPopup(ɵ$index_31_r5, $event)); });
    i0.ɵɵconditionalCreate(9, SpreadsheetComponent_For_18_Conditional_9_Template, 1, 0, "i", 44)(10, SpreadsheetComponent_For_18_Conditional_10_Template, 1, 0, "i", 45);
    i0.ɵɵelementEnd()()();
    i0.ɵɵelementStart(11, "div", 46);
    i0.ɵɵlistener("mousedown", function SpreadsheetComponent_For_18_Template_div_mousedown_11_listener($event) { const ɵ$index_31_r5 = i0.ɵɵrestoreView(_r4).$index; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onColResizeMouseDown($event, ɵ$index_31_r5)); });
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    let tmp_21_0;
    const col_r6 = ctx.$implicit;
    const ɵ$index_31_r5 = ctx.$index;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵclassProp("opacity-50", ctx_r2.isColumnDragged().has(ɵ$index_31_r5));
    i0.ɵɵattribute("data-col-index", ɵ$index_31_r5);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(col_r6.name);
    i0.ɵɵadvance(3);
    i0.ɵɵconditional(((tmp_21_0 = ctx_r2.sortConfig()) == null ? null : tmp_21_0.col) === ɵ$index_31_r5 ? 6 : 7);
    i0.ɵɵadvance(3);
    i0.ɵɵconditional(ctx_r2.filterConfig().has(ɵ$index_31_r5) ? 9 : 10);
} }
function SpreadsheetComponent_For_21_For_4_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    const _r12 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 54);
    i0.ɵɵlistener("mouseenter", function SpreadsheetComponent_For_21_For_4_Conditional_1_Template_div_mouseenter_0_listener($event) { i0.ɵɵrestoreView(_r12); const ɵ$index_67_r10 = i0.ɵɵnextContext().$index; const item_r11 = i0.ɵɵnextContext().$implicit; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onCellMouseEnter($event, item_r11.originalModelIndex, ɵ$index_67_r10)); });
    i0.ɵɵelementEnd();
} }
function SpreadsheetComponent_For_21_For_4_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    const _r13 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 55);
    i0.ɵɵlistener("dblclick", function SpreadsheetComponent_For_21_For_4_Conditional_2_Template_div_dblclick_0_listener($event) { i0.ɵɵrestoreView(_r13); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵelementStart(1, "input", 56);
    i0.ɵɵlistener("change", function SpreadsheetComponent_For_21_For_4_Conditional_2_Template_input_change_1_listener($event) { i0.ɵɵrestoreView(_r13); const ɵ$index_67_r10 = i0.ɵɵnextContext().$index; const item_r11 = i0.ɵɵnextContext().$implicit; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onCheckboxChange($event, item_r11.originalModelIndex, ɵ$index_67_r10)); })("mousedown", function SpreadsheetComponent_For_21_For_4_Conditional_2_Template_input_mousedown_1_listener($event) { i0.ɵɵrestoreView(_r13); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    let tmp_31_0;
    const ɵ$index_67_r10 = i0.ɵɵnextContext().$index;
    const item_r11 = i0.ɵɵnextContext().$implicit;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("checked", ctx_r2.isCheckboxChecked(item_r11.originalModelIndex, ɵ$index_67_r10))("disabled", (tmp_31_0 = ctx_r2.getCell(item_r11.originalModelIndex, ɵ$index_67_r10)) == null ? null : tmp_31_0.readOnly);
} }
function SpreadsheetComponent_For_21_For_4_Conditional_3_Conditional_1_Conditional_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "span", 59);
} if (rf & 2) {
    i0.ɵɵstyleProp("background-color", ctx);
} }
function SpreadsheetComponent_For_21_For_4_Conditional_3_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵconditionalCreate(0, SpreadsheetComponent_For_21_For_4_Conditional_3_Conditional_1_Conditional_0_Template, 1, 2, "span", 58);
} if (rf & 2) {
    let tmp_31_0;
    const ɵ$index_67_r10 = i0.ɵɵnextContext(2).$index;
    const item_r11 = i0.ɵɵnextContext().$implicit;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵconditional((tmp_31_0 = ctx_r2.getDropdownOptionColor(item_r11.originalModelIndex, ɵ$index_67_r10)) ? 0 : -1, tmp_31_0);
} }
function SpreadsheetComponent_For_21_For_4_Conditional_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 52);
    i0.ɵɵconditionalCreate(1, SpreadsheetComponent_For_21_For_4_Conditional_3_Conditional_1_Template, 1, 1);
    i0.ɵɵelement(2, "span", 57);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    let tmp_30_0;
    const ɵ$index_67_r10 = i0.ɵɵnextContext().$index;
    const item_r11 = i0.ɵɵnextContext().$implicit;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵconditional(((tmp_30_0 = ctx_r2.columnConfig()()[ɵ$index_67_r10]) == null ? null : tmp_30_0.editor) === "dropdown" ? 1 : -1);
    i0.ɵɵadvance();
    i0.ɵɵproperty("innerHTML", ctx_r2.getHighlightedCellContent(item_r11.originalModelIndex, ɵ$index_67_r10), i0.ɵɵsanitizeHtml);
} }
function SpreadsheetComponent_For_21_For_4_Conditional_4_Template(rf, ctx) { if (rf & 1) {
    const _r14 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 60);
    i0.ɵɵlistener("dblclick", function SpreadsheetComponent_For_21_For_4_Conditional_4_Template_div_dblclick_0_listener($event) { i0.ɵɵrestoreView(_r14); const ctx_r2 = i0.ɵɵnextContext(3); return i0.ɵɵresetView(ctx_r2.onFillHandleDoubleClick($event)); });
    i0.ɵɵelementEnd();
} }
function SpreadsheetComponent_For_21_For_4_Template(rf, ctx) { if (rf & 1) {
    const _r9 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "td", 49);
    i0.ɵɵlistener("dblclick", function SpreadsheetComponent_For_21_For_4_Template_td_dblclick_0_listener() { const ɵ$index_67_r10 = i0.ɵɵrestoreView(_r9).$index; const item_r11 = i0.ɵɵnextContext().$implicit; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onCellDoubleClick(item_r11.originalModelIndex, ɵ$index_67_r10)); })("contextmenu", function SpreadsheetComponent_For_21_For_4_Template_td_contextmenu_0_listener($event) { const ɵ$index_67_r10 = i0.ɵɵrestoreView(_r9).$index; const item_r11 = i0.ɵɵnextContext().$implicit; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onCellContextMenu($event, item_r11.originalModelIndex, ɵ$index_67_r10)); })("mouseenter", function SpreadsheetComponent_For_21_For_4_Template_td_mouseenter_0_listener($event) { const ɵ$index_67_r10 = i0.ɵɵrestoreView(_r9).$index; const item_r11 = i0.ɵɵnextContext().$implicit; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onCellMouseEnter($event, item_r11.originalModelIndex, ɵ$index_67_r10)); })("mouseleave", function SpreadsheetComponent_For_21_For_4_Template_td_mouseleave_0_listener() { i0.ɵɵrestoreView(_r9); const ctx_r2 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r2.onCellMouseLeave()); });
    i0.ɵɵconditionalCreate(1, SpreadsheetComponent_For_21_For_4_Conditional_1_Template, 1, 0, "div", 50);
    i0.ɵɵconditionalCreate(2, SpreadsheetComponent_For_21_For_4_Conditional_2_Template, 2, 2, "div", 51)(3, SpreadsheetComponent_For_21_For_4_Conditional_3_Template, 3, 2, "div", 52);
    i0.ɵɵconditionalCreate(4, SpreadsheetComponent_For_21_For_4_Conditional_4_Template, 1, 0, "div", 53);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    let tmp_29_0;
    let tmp_33_0;
    const ɵ$index_67_r10 = ctx.$index;
    const item_r11 = i0.ɵɵnextContext().$implicit;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵclassMap(i0.ɵɵinterpolate4("border-r border-b relative whitespace-pre-wrap align-top long-spreadsheet-cell ", ctx_r2.isEditing(item_r11.originalModelIndex, ɵ$index_67_r10) ? "invisible" : "", " ", ((tmp_29_0 = ctx_r2.getCell(item_r11.originalModelIndex, ɵ$index_67_r10)) == null ? null : tmp_29_0.readOnly) ? "text-[var(--lt-text-read-only,theme(colors.gray.500))] bg-[var(--lt-bg-primary,transparent)]" : "text-[var(--lt-text-primary,theme(colors.gray.900))]", " ", ctx_r2.isCellInvalid(item_r11.originalModelIndex, ɵ$index_67_r10) ? "!bg-[var(--lt-bg-invalid,theme(colors.red.100))]" : ctx_r2.isSelected(item_r11.originalModelIndex, ɵ$index_67_r10) ? "bg-[var(--lt-bg-selection,theme(colors.blue.100))]" : "", " ", ctx_r2.isSelected(item_r11.originalModelIndex, ɵ$index_67_r10) ? "border-transparent" : "border-[var(--lt-border-grid,theme(colors.slate.200))]"));
    i0.ɵɵattribute("data-row", item_r11.originalModelIndex)("data-col", ɵ$index_67_r10);
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r2.isCellInvalid(item_r11.originalModelIndex, ɵ$index_67_r10) ? 1 : -1);
    i0.ɵɵadvance();
    i0.ɵɵconditional(((tmp_33_0 = ctx_r2.columnConfig()()[ɵ$index_67_r10]) == null ? null : tmp_33_0.editor) === "checkbox" ? 2 : 3);
    i0.ɵɵadvance(2);
    i0.ɵɵconditional(ctx_r2.isFillHandleVisible(item_r11.originalModelIndex, ɵ$index_67_r10) ? 4 : -1);
} }
function SpreadsheetComponent_For_21_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "tr", 23)(1, "th", 47);
    i0.ɵɵlistener("contextmenu", function SpreadsheetComponent_For_21_Template_th_contextmenu_1_listener($event) { const ɵ$index_61_r8 = i0.ɵɵrestoreView(_r7).$index; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.onRowContextMenu($event, ɵ$index_61_r8)); });
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
    i0.ɵɵrepeaterCreate(3, SpreadsheetComponent_For_21_For_4_Template, 5, 11, "td", 48, i0.ɵɵrepeaterTrackByIndex);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const item_r11 = ctx.$implicit;
    const ɵ$index_61_r8 = ctx.$index;
    i0.ɵɵadvance();
    i0.ɵɵattribute("data-row-index", ɵ$index_61_r8);
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", ɵ$index_61_r8 + 1, " ");
    i0.ɵɵadvance();
    i0.ɵɵrepeater(item_r11.cells);
} }
function SpreadsheetComponent_Conditional_22_Conditional_0_Conditional_0_Conditional_0_For_7_Conditional_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "span", 59);
} if (rf & 2) {
    i0.ɵɵstyleProp("background-color", ctx);
} }
function SpreadsheetComponent_Conditional_22_Conditional_0_Conditional_0_Conditional_0_For_7_Conditional_5_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "i", 73);
} }
function SpreadsheetComponent_Conditional_22_Conditional_0_Conditional_0_Conditional_0_For_7_Template(rf, ctx) { if (rf & 1) {
    const _r16 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "button", 71);
    i0.ɵɵlistener("click", function SpreadsheetComponent_Conditional_22_Conditional_0_Conditional_0_Conditional_0_For_7_Template_button_click_0_listener() { const option_r17 = i0.ɵɵrestoreView(_r16).$implicit; const ctx_r2 = i0.ɵɵnextContext(5); return i0.ɵɵresetView(ctx_r2.selectDropdownOption(option_r17)); });
    i0.ɵɵelementStart(1, "div", 72);
    i0.ɵɵconditionalCreate(2, SpreadsheetComponent_Conditional_22_Conditional_0_Conditional_0_Conditional_0_For_7_Conditional_2_Template, 1, 2, "span", 58);
    i0.ɵɵelementStart(3, "span", 38);
    i0.ɵɵtext(4);
    i0.ɵɵelementEnd()();
    i0.ɵɵconditionalCreate(5, SpreadsheetComponent_Conditional_22_Conditional_0_Conditional_0_Conditional_0_For_7_Conditional_5_Template, 1, 0, "i", 73);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    let tmp_31_0;
    const option_r17 = ctx.$implicit;
    const ɵ$index_102_r18 = ctx.$index;
    const cell_r19 = i0.ɵɵnextContext(2);
    const ctx_r2 = i0.ɵɵnextContext(3);
    i0.ɵɵclassMap("w-full text-left px-2 py-1.5 leading-[12px] flex items-center justify-between rounded-md " + (ctx_r2.getOptionValue(option_r17) == cell_r19.value ? "bg-[var(--lt-bg-selection,theme(colors.blue.100))] text-[var(--lt-text-selection,theme(colors.blue.800))] font-semibold" : ɵ$index_102_r18 === ctx_r2.dropdownActiveOptionIndex() ? "bg-[var(--lt-bg-header-hover,theme(colors.slate.200))] text-[var(--lt-text-primary,theme(colors.gray.800))]" : "text-[var(--lt-text-primary,theme(colors.gray.700))] hover:bg-[var(--lt-icon-hover-bg,theme(colors.gray.100))]"));
    i0.ɵɵstyleProp("font-size", "var(--lt-font-table-cell, 12px)")("font-family", "var(--lt-font-family-mono, monospace)");
    i0.ɵɵproperty("id", "dropdown-option-" + ɵ$index_102_r18);
    i0.ɵɵadvance(2);
    i0.ɵɵconditional((tmp_31_0 = ctx_r2.getOptionColor(option_r17)) ? 2 : -1, tmp_31_0);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(ctx_r2.getOptionValue(option_r17));
    i0.ɵɵadvance();
    i0.ɵɵconditional(ctx_r2.getOptionValue(option_r17) == cell_r19.value ? 5 : -1);
} }
function SpreadsheetComponent_Conditional_22_Conditional_0_Conditional_0_Conditional_0_Template(rf, ctx) { if (rf & 1) {
    const _r15 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 63, 7);
    i0.ɵɵlistener("mousedown", function SpreadsheetComponent_Conditional_22_Conditional_0_Conditional_0_Conditional_0_Template_div_mousedown_0_listener($event) { i0.ɵɵrestoreView(_r15); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵelementStart(2, "div", 64)(3, "input", 65, 8);
    i0.ɵɵlistener("ngModelChange", function SpreadsheetComponent_Conditional_22_Conditional_0_Conditional_0_Conditional_0_Template_input_ngModelChange_3_listener($event) { i0.ɵɵrestoreView(_r15); const ctx_r2 = i0.ɵɵnextContext(4); return i0.ɵɵresetView(ctx_r2.dropdownSearchText.set($event)); })("keydown", function SpreadsheetComponent_Conditional_22_Conditional_0_Conditional_0_Conditional_0_Template_input_keydown_3_listener($event) { i0.ɵɵrestoreView(_r15); const ctx_r2 = i0.ɵɵnextContext(4); return i0.ɵɵresetView(ctx_r2.onDropdownKeyDown($event)); });
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(5, "div", 66);
    i0.ɵɵrepeaterCreate(6, SpreadsheetComponent_Conditional_22_Conditional_0_Conditional_0_Conditional_0_For_7_Template, 6, 10, "button", 67, i0.ɵɵrepeaterTrackByIdentity);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(8, "div", 68)(9, "button", 69);
    i0.ɵɵlistener("click", function SpreadsheetComponent_Conditional_22_Conditional_0_Conditional_0_Conditional_0_Template_button_click_9_listener() { i0.ɵɵrestoreView(_r15); const ctx_r2 = i0.ɵɵnextContext(4); return i0.ɵɵresetView(ctx_r2.editDropdownOptions()); });
    i0.ɵɵelement(10, "i", 70);
    i0.ɵɵelementStart(11, "span");
    i0.ɵɵtext(12, "Edit Options");
    i0.ɵɵelementEnd()()()();
} if (rf & 2) {
    const pos_r20 = i0.ɵɵnextContext(2);
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵstyleProp("top", pos_r20.top, "px")("left", pos_r20.left, "px")("width", pos_r20.width, "px")("background", "var(--lt-popup-bg)");
    i0.ɵɵadvance(3);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-input, 14px)");
    i0.ɵɵproperty("ngModel", ctx_r2.dropdownSearchText());
    i0.ɵɵadvance(3);
    i0.ɵɵrepeater(ctx_r2.filteredDropdownOptions());
    i0.ɵɵadvance(3);
    i0.ɵɵstyleProp("font-size", "var(--lt-font-modal-content, 14px)");
} }
function SpreadsheetComponent_Conditional_22_Conditional_0_Conditional_0_Conditional_1_Template(rf, ctx) { if (rf & 1) {
    const _r21 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 74)(1, "textarea", 75, 9);
    i0.ɵɵtwoWayListener("ngModelChange", function SpreadsheetComponent_Conditional_22_Conditional_0_Conditional_0_Conditional_1_Template_textarea_ngModelChange_1_listener($event) { i0.ɵɵrestoreView(_r21); const ctx_r2 = i0.ɵɵnextContext(4); i0.ɵɵtwoWayBindingSet(ctx_r2.editValue, $event) || (ctx_r2.editValue = $event); return i0.ɵɵresetView($event); });
    i0.ɵɵlistener("blur", function SpreadsheetComponent_Conditional_22_Conditional_0_Conditional_0_Conditional_1_Template_textarea_blur_1_listener() { i0.ɵɵrestoreView(_r21); const ctx_r2 = i0.ɵɵnextContext(4); return i0.ɵɵresetView(ctx_r2.onEditBlur()); })("keydown", function SpreadsheetComponent_Conditional_22_Conditional_0_Conditional_0_Conditional_1_Template_textarea_keydown_1_listener($event) { i0.ɵɵrestoreView(_r21); const ctx_r2 = i0.ɵɵnextContext(4); return i0.ɵɵresetView(ctx_r2.onEditKeyDown($event)); })("input", function SpreadsheetComponent_Conditional_22_Conditional_0_Conditional_0_Conditional_1_Template_textarea_input_1_listener() { i0.ɵɵrestoreView(_r21); const ctx_r2 = i0.ɵɵnextContext(4); return i0.ɵɵresetView(ctx_r2.onEditorInput()); });
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const pos_r20 = i0.ɵɵnextContext(2);
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵstyleProp("top", pos_r20.top, "px")("left", pos_r20.left, "px")("width", pos_r20.width, "px")("height", pos_r20.height, "px")("padding", "7px 10px");
    i0.ɵɵadvance();
    i0.ɵɵstyleProp("font-family", "var(--lt-font-family-mono, monospace)")("font-size", "var(--lt-font-table-cell, 12px)");
    i0.ɵɵtwoWayProperty("ngModel", ctx_r2.editValue);
} }
function SpreadsheetComponent_Conditional_22_Conditional_0_Conditional_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵconditionalCreate(0, SpreadsheetComponent_Conditional_22_Conditional_0_Conditional_0_Conditional_0_Template, 13, 13, "div", 61)(1, SpreadsheetComponent_Conditional_22_Conditional_0_Conditional_0_Conditional_1_Template, 3, 15, "div", 62);
} if (rf & 2) {
    let tmp_13_0;
    const coords_r22 = i0.ɵɵnextContext(2);
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵconditional(((tmp_13_0 = ctx_r2.columnConfig()()[coords_r22.col]) == null ? null : tmp_13_0.editor) === "dropdown" ? 0 : 1);
} }
function SpreadsheetComponent_Conditional_22_Conditional_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵconditionalCreate(0, SpreadsheetComponent_Conditional_22_Conditional_0_Conditional_0_Template, 2, 1);
} if (rf & 2) {
    let tmp_11_0;
    const coords_r22 = i0.ɵɵnextContext();
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵconditional((tmp_11_0 = ctx_r2.getCell(coords_r22.row, coords_r22.col)) ? 0 : -1, tmp_11_0);
} }
function SpreadsheetComponent_Conditional_22_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵconditionalCreate(0, SpreadsheetComponent_Conditional_22_Conditional_0_Template, 1, 1);
} if (rf & 2) {
    let tmp_9_0;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵconditional((tmp_9_0 = ctx_r2.editorPosition()) ? 0 : -1, tmp_9_0);
} }
function SpreadsheetComponent_For_24_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "div", 76);
} if (rf & 2) {
    const pos_r23 = ctx.$implicit;
    i0.ɵɵstyleMap(pos_r23);
} }
function SpreadsheetComponent_Conditional_25_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "div", 77);
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵstyleMap(ctx_r2.fillRangePosition());
} }
function SpreadsheetComponent_Conditional_26_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "div", 78);
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵstyleMap(ctx_r2.dropIndicatorPosition());
} }
function SpreadsheetComponent_Conditional_29_Template(rf, ctx) { if (rf & 1) {
    const _r24 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "long-filter-popup", 79);
    i0.ɵɵlistener("apply", function SpreadsheetComponent_Conditional_29_Template_long_filter_popup_apply_0_listener($event) { const popup_r25 = i0.ɵɵrestoreView(_r24); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.handleApplyFilter({ col: popup_r25.col, selection: $event })); })("clear", function SpreadsheetComponent_Conditional_29_Template_long_filter_popup_clear_0_listener() { const popup_r25 = i0.ɵɵrestoreView(_r24); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.handleClearFilter(popup_r25.col)); })("close", function SpreadsheetComponent_Conditional_29_Template_long_filter_popup_close_0_listener() { i0.ɵɵrestoreView(_r24); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.activeFilterPopup.set(null)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵproperty("isVisible", !!ctx)("position", ctx_r2.filterPopupPosition())("uniqueValues", ctx_r2.currentFilterUniqueValues())("initialSelection", ctx_r2.filterPopupInitialSelection());
} }
function SpreadsheetComponent_Conditional_34_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 80, 10);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    const pos_r26 = ctx_r2.tooltipPosition();
    i0.ɵɵstyleProp("font-family", "var(--lt-font-family-mono, monospace)")("left", pos_r26.x, "px")("top", pos_r26.y, "px");
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1(" ", ctx_r2.tooltipText(), " ");
} }
function SpreadsheetComponent_Conditional_37_Conditional_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 83);
    i0.ɵɵtext(1);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const content_r27 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate(content_r27.description);
} }
function SpreadsheetComponent_Conditional_37_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 81, 11)(2, "div", 82);
    i0.ɵɵtext(3);
    i0.ɵɵelementEnd();
    i0.ɵɵconditionalCreate(4, SpreadsheetComponent_Conditional_37_Conditional_4_Template, 2, 1, "div", 83);
    i0.ɵɵelement(5, "div", 84);
    i0.ɵɵelementStart(6, "div", 85);
    i0.ɵɵtext(7, "Field: ");
    i0.ɵɵelementStart(8, "span", 86);
    i0.ɵɵtext(9);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(10, "div", 85);
    i0.ɵɵtext(11, "Type: ");
    i0.ɵɵelementStart(12, "span", 86);
    i0.ɵɵtext(13);
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const content_r27 = ctx;
    const pos_r28 = i0.ɵɵnextContext().headerTooltipPosition();
    i0.ɵɵstyleProp("background-color", "var(--lt-tooltip-bg, #1e293b)")("color", "var(--lt-tooltip-text, #ffffff)")("font-family", "var(--lt-font-family-mono, monospace)")("left", pos_r28.x, "px")("top", pos_r28.y, "px");
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(content_r27.name);
    i0.ɵɵadvance();
    i0.ɵɵconditional(content_r27.description ? 4 : -1);
    i0.ɵɵadvance(5);
    i0.ɵɵtextInterpolate(content_r27.kebabName);
    i0.ɵɵadvance(4);
    i0.ɵɵtextInterpolate(content_r27.type);
} }
class SpreadsheetComponent {
    constructor() {
        this.data = input.required(...(ngDevMode ? [{ debugName: "data" }] : []));
        this.columnConfig = input.required(...(ngDevMode ? [{ debugName: "columnConfig" }] : []));
        this.theme = input.required(...(ngDevMode ? [{ debugName: "theme" }] : []));
        this.showLoading = input(false, ...(ngDevMode ? [{ debugName: "showLoading" }] : []));
        this.onDataChange = output();
        this.onColumnChange = output();
        this.uniqueId = `long-spreadsheet-${Math.random().toString(36).substring(2, 9)}`;
        // Signals for state management
        this.activeCell = signal(null, ...(ngDevMode ? [{ debugName: "activeCell" }] : []));
        this.selectionRanges = signal([], ...(ngDevMode ? [{ debugName: "selectionRanges" }] : []));
        this.editingCell = signal(null, ...(ngDevMode ? [{ debugName: "editingCell" }] : []));
        this.isMouseDown = signal(false, ...(ngDevMode ? [{ debugName: "isMouseDown" }] : []));
        this.isDraggingFill = signal(false, ...(ngDevMode ? [{ debugName: "isDraggingFill" }] : []));
        this.isSelectingRows = signal(false, ...(ngDevMode ? [{ debugName: "isSelectingRows" }] : []));
        this.isSelectingCols = signal(false, ...(ngDevMode ? [{ debugName: "isSelectingCols" }] : []));
        this.fillRange = signal(null, ...(ngDevMode ? [{ debugName: "fillRange" }] : []));
        this.editValue = signal('', ...(ngDevMode ? [{ debugName: "editValue" }] : []));
        this.editorPosition = signal(null, ...(ngDevMode ? [{ debugName: "editorPosition" }] : []));
        this.isNewValueEntry = signal(false, ...(ngDevMode ? [{ debugName: "isNewValueEntry" }] : []));
        // Column Resizing State
        this.isResizingCol = signal(null, ...(ngDevMode ? [{ debugName: "isResizingCol" }] : []));
        this.resizingColStart = signal(null, ...(ngDevMode ? [{ debugName: "resizingColStart" }] : []));
        // Column Drag & Drop State
        this.isDraggingColumn = signal(false, ...(ngDevMode ? [{ debugName: "isDraggingColumn" }] : []));
        this.draggedColumnInfo = signal(null, ...(ngDevMode ? [{ debugName: "draggedColumnInfo" }] : []));
        this.dropColumnIndex = signal(null, ...(ngDevMode ? [{ debugName: "dropColumnIndex" }] : []));
        // Sorting and Filtering
        this.sortConfig = signal(null, ...(ngDevMode ? [{ debugName: "sortConfig" }] : []));
        this.filterConfig = signal(new Map(), ...(ngDevMode ? [{ debugName: "filterConfig" }] : []));
        // Custom Dropdown Editor State
        this.dropdownSearchText = signal('', ...(ngDevMode ? [{ debugName: "dropdownSearchText" }] : []));
        this.dropdownActiveOptionIndex = signal(0, ...(ngDevMode ? [{ debugName: "dropdownActiveOptionIndex" }] : []));
        // Validation State
        this.validationErrors = signal(new Map(), ...(ngDevMode ? [{ debugName: "validationErrors" }] : []));
        // Tooltip State
        this.isTooltipVisible = signal(false, ...(ngDevMode ? [{ debugName: "isTooltipVisible" }] : []));
        this.tooltipText = signal('', ...(ngDevMode ? [{ debugName: "tooltipText" }] : []));
        this.tooltipPosition = signal({ x: 0, y: 0 }, ...(ngDevMode ? [{ debugName: "tooltipPosition" }] : []));
        // Header Tooltip State
        this.isHeaderTooltipVisible = signal(false, ...(ngDevMode ? [{ debugName: "isHeaderTooltipVisible" }] : []));
        this.headerTooltipContent = signal(null, ...(ngDevMode ? [{ debugName: "headerTooltipContent" }] : []));
        this.headerTooltipPosition = signal({ x: 0, y: 0 }, ...(ngDevMode ? [{ debugName: "headerTooltipPosition" }] : []));
        this.lastHeaderHoverTarget = null;
        // Undo/Redo State
        this.undoStack = signal([], ...(ngDevMode ? [{ debugName: "undoStack" }] : []));
        this.redoStack = signal([], ...(ngDevMode ? [{ debugName: "redoStack" }] : []));
        // Child component visibility states
        this.isContextMenuVisible = signal(false, ...(ngDevMode ? [{ debugName: "isContextMenuVisible" }] : []));
        this.isColumnSettingsVisible = signal(false, ...(ngDevMode ? [{ debugName: "isColumnSettingsVisible" }] : []));
        this.isFindReplaceVisible = signal(false, ...(ngDevMode ? [{ debugName: "isFindReplaceVisible" }] : []));
        this.isStatsModalVisible = signal(false, ...(ngDevMode ? [{ debugName: "isStatsModalVisible" }] : []));
        // Find and Replace State
        this.findQuery = signal('', ...(ngDevMode ? [{ debugName: "findQuery" }] : []));
        this.findOptions = signal({ matchCase: false, matchEntireCell: false }, ...(ngDevMode ? [{ debugName: "findOptions" }] : []));
        this.currentFindIndex = signal(-1, ...(ngDevMode ? [{ debugName: "currentFindIndex" }] : []));
        this.activeFilterPopup = signal(null, ...(ngDevMode ? [{ debugName: "activeFilterPopup" }] : []));
        // State for child components
        this.contextMenuPosition = signal({ x: 0, y: 0 }, ...(ngDevMode ? [{ debugName: "contextMenuPosition" }] : []));
        this.menuLaunchCoords = signal(null, ...(ngDevMode ? [{ debugName: "menuLaunchCoords" }] : []));
        // Fix: Initialize signal with a default value.
        this.contextMenuType = signal(null, ...(ngDevMode ? [{ debugName: "contextMenuType" }] : []));
        this.contextMenuCoords = signal(null, ...(ngDevMode ? [{ debugName: "contextMenuCoords" }] : []));
        this.columnSettingsColIndex = signal(null, ...(ngDevMode ? [{ debugName: "columnSettingsColIndex" }] : []));
        // State signals for stats modal
        this.statsUseCountColumn = signal(false, ...(ngDevMode ? [{ debugName: "statsUseCountColumn" }] : []));
        this.statsGraphsConfig = signal([
            { type: 'distribution', state: signal({ analysisField: null, stackByField: null, view: 'chart' }) },
            { type: 'distribution', state: signal({ analysisField: null, stackByField: null, view: 'chart' }) },
            { type: 'distribution', state: signal({ analysisField: null, stackByField: null, view: 'chart' }) },
            { type: 'correlation', state: signal({ fieldX: null, fieldY: null, categoryField: null }) }
        ], ...(ngDevMode ? [{ debugName: "statsGraphsConfig" }] : []));
        // DOM elements
        this.rootContainer = viewChild.required('rootContainer');
        this.spreadsheetContainer = viewChild.required('spreadsheetContainer');
        this.spreadsheetTable = viewChild.required('spreadsheetTable');
        this.editingInput = viewChild('editingInput', ...(ngDevMode ? [{ debugName: "editingInput" }] : []));
        this.dropdownEditor = viewChild('dropdownEditor', ...(ngDevMode ? [{ debugName: "dropdownEditor" }] : []));
        this.dropdownSearchInput = viewChild('dropdownSearchInput', ...(ngDevMode ? [{ debugName: "dropdownSearchInput" }] : []));
        this.contextMenuEl = viewChild('contextMenuEl', ...(ngDevMode ? [{ debugName: "contextMenuEl" }] : []));
        this.filterPopupEl = viewChild('filterPopupEl', ...(ngDevMode ? [{ debugName: "filterPopupEl" }] : []));
        this.findReplacePanelEl = viewChild('findReplacePanelEl', ...(ngDevMode ? [{ debugName: "findReplacePanelEl" }] : []));
        this.csvImporter = viewChild('csvImporter', ...(ngDevMode ? [{ debugName: "csvImporter" }] : []));
        this.validationTooltip = viewChild('validationTooltip', ...(ngDevMode ? [{ debugName: "validationTooltip" }] : []));
        this.headerTooltip = viewChild('headerTooltip', ...(ngDevMode ? [{ debugName: "headerTooltip" }] : []));
        // Layout change tracking
        this.layoutTick = signal(0, ...(ngDevMode ? [{ debugName: "layoutTick" }] : []));
        // Output flags
        this.isDataInitialized = false;
        this.isColumnConfigInitialized = false;
        // Computed properties
        this.rows = computed(() => this.data()() || [], ...(ngDevMode ? [{ debugName: "rows" }] : []));
        this.colsCount = computed(() => this.columnConfig()().length || 0, ...(ngDevMode ? [{ debugName: "colsCount" }] : []));
        this.height = input('60vh', ...(ngDevMode ? [{ debugName: "height" }] : []));
        this.spreadsheetContainerClasses = computed(() => `w-full overflow-auto border rounded-[10px] relative select-none focus:outline-none border-[var(--lt-border-default,theme(colors.slate.200))] ${this.uniqueId}`, ...(ngDevMode ? [{ debugName: "spreadsheetContainerClasses" }] : []));
        this.containerHeight = computed(() => {
            const h = this.height();
            if (h === 'auto' || h === 'full' || h === '100%') {
                return h === 'auto' ? 'auto' : '100%';
            }
            return typeof h === 'number' ? `${h}px` : h;
        }, ...(ngDevMode ? [{ debugName: "containerHeight" }] : []));
        this.isFullHeight = computed(() => {
            const h = this.height();
            return h === 'full' || h === '100%';
        }, ...(ngDevMode ? [{ debugName: "isFullHeight" }] : []));
        this.themeCssVariables = computed(() => {
            const theme = this.theme();
            if (!theme) {
                return {};
            }
            const styles = Object.entries(theme.colors).reduce((acc, [key, value]) => {
                // camelCase to kebab-case
                const cssVar = `--lt-${key.replace(/[A-Z]/g, letter => `-${letter.toLowerCase()}`)}`;
                if (typeof value === 'string') {
                    acc[cssVar] = value;
                }
                return acc;
            }, {});
            if (theme.fontFamily) {
                Object.entries(theme.fontFamily).forEach(([key, value]) => {
                    const cssVar = `--lt-font-family-${key.replace(/[A-Z]/g, letter => `-${letter.toLowerCase()}`)}`;
                    if (typeof value === 'string') {
                        styles[cssVar] = value;
                    }
                });
            }
            if (theme.fontSizes) {
                Object.entries(theme.fontSizes).forEach(([key, value]) => {
                    const cssVar = `--lt-font-${key.replace(/[A-Z]/g, letter => `-${letter.toLowerCase()}`)}`;
                    if (typeof value === 'string') {
                        styles[cssVar] = value;
                    }
                });
            }
            if (theme.colorScheme) {
                styles['color-scheme'] = theme.colorScheme;
            }
            return styles;
        }, ...(ngDevMode ? [{ debugName: "themeCssVariables" }] : []));
        this.scrollbarStyles = computed(() => {
            const theme = this.theme();
            if (!theme?.scrollbar) {
                return '';
            }
            const sb = theme.scrollbar;
            const colors = theme.colors;
            const selector = `.${this.uniqueId}`;
            return `
      /* Main spreadsheet scrollbar */
      ${selector}::-webkit-scrollbar {
        width: 15px;
        height: 15px;
      }
      ${selector}::-webkit-scrollbar-track {
        background-color: ${sb.track};
      }
      ${selector}::-webkit-scrollbar-thumb {
        background-color: ${sb.thumb};
        border-radius: 10px;
        border: 4px solid ${sb.border};
        background-clip: content-box;
      }
      ${selector}::-webkit-scrollbar-thumb:hover {
        background-color: ${sb.thumbHover};
      }
      ${selector}::-webkit-scrollbar-corner {
        background-color: ${sb.corner};
      }

      /* Modal scrollbars within this spreadsheet instance */
      ${selector} .modal-scroll-content::-webkit-scrollbar {
        width: 15px;
        height: 15px;
      }
      ${selector} .modal-scroll-content::-webkit-scrollbar-track {
        background-color: ${colors.popupBg};
      }
      ${selector} .modal-scroll-content::-webkit-scrollbar-thumb {
        background-color: ${sb.thumb};
        border-radius: 10px;
        border: 4px solid ${colors.popupBg};
        background-clip: content-box;
      }
      ${selector} .modal-scroll-content::-webkit-scrollbar-thumb:hover {
        background-color: ${sb.thumbHover};
      }
      ${selector} .modal-scroll-content::-webkit-scrollbar-corner {
        background-color: ${colors.popupBg};
      }
    `;
        }, ...(ngDevMode ? [{ debugName: "scrollbarStyles" }] : []));
        this.filteredDropdownOptions = computed(() => {
            const editing = this.editingCell();
            if (!editing)
                return [];
            const colConfig = this.columnConfig()()[editing.col];
            if (colConfig?.editor !== 'dropdown' || !colConfig.options)
                return [];
            const search = this.dropdownSearchText().toLowerCase();
            if (!search)
                return colConfig.options;
            return colConfig.options.filter(opt => this.getOptionValue(opt).toLowerCase().includes(search));
        }, ...(ngDevMode ? [{ debugName: "filteredDropdownOptions" }] : []));
        this.displayedRows = computed(() => {
            const data = this.rows();
            if (data.length === 0)
                return [];
            const filters = this.filterConfig();
            const sort = this.sortConfig();
            let processedRows = data.map((cells, index) => ({ cells, originalModelIndex: index }));
            if (filters.size > 0) {
                processedRows = processedRows.filter(rowItem => {
                    for (const [col, selectedValues] of filters.entries()) {
                        if (!selectedValues.has(String(rowItem.cells[col]?.value ?? ''))) {
                            return false;
                        }
                    }
                    return true;
                });
            }
            if (sort) {
                processedRows.sort((a, b) => {
                    const valA = a.cells[sort.col]?.value;
                    const valB = b.cells[sort.col]?.value;
                    let comparison = 0;
                    if (valA === valB)
                        comparison = 0;
                    else if (valA == null)
                        comparison = -1;
                    else if (valB == null)
                        comparison = 1;
                    else if (typeof valA === 'number' && typeof valB === 'number')
                        comparison = valA - valB;
                    else
                        comparison = String(valA).localeCompare(String(valB));
                    return sort.direction === 'asc' ? comparison : -comparison;
                });
            }
            return processedRows;
        }, ...(ngDevMode ? [{ debugName: "displayedRows" }] : []));
        this.findResults = computed(() => {
            const query = this.findQuery();
            if (!query)
                return [];
            const options = this.findOptions();
            const results = [];
            const searchQuery = options.matchCase ? query : query.toLowerCase();
            this.rows().forEach((row, rowIndex) => {
                row.forEach((cell, colIndex) => {
                    const cellValue = String(cell?.value ?? '');
                    const compareValue = options.matchCase ? cellValue : cellValue.toLowerCase();
                    if (options.matchEntireCell) {
                        if (compareValue === searchQuery) {
                            results.push({ row: rowIndex, col: colIndex });
                        }
                    }
                    else {
                        if (compareValue.includes(searchQuery)) {
                            results.push({ row: rowIndex, col: colIndex });
                        }
                    }
                });
            });
            return results;
        }, ...(ngDevMode ? [{ debugName: "findResults" }] : []));
        this.selectionRangePositions = computed(() => {
            this.rows();
            this.layoutTick();
            const ranges = this.selectionRanges();
            const container = this.spreadsheetContainer();
            if (ranges.length === 0 || !container?.nativeElement)
                return [];
            return ranges.map(range => {
                const norm = this.normalizeRange(range);
                const startModel = this.visualToModelCoords(norm.start);
                const endModel = this.visualToModelCoords(norm.end);
                if (!startModel || !endModel)
                    return { display: 'none' };
                const startEl = container.nativeElement.querySelector(`td[data-row="${startModel.row}"][data-col="${startModel.col}"]`);
                const endEl = container.nativeElement.querySelector(`td[data-row="${endModel.row}"][data-col="${endModel.col}"]`);
                if (!startEl || !endEl)
                    return { display: 'none' };
                const left = startEl.offsetLeft;
                const top = startEl.offsetTop;
                const width = (endEl.offsetLeft + endEl.offsetWidth) - left;
                const height = (endEl.offsetTop + endEl.offsetHeight) - top;
                return { display: 'block', left: `${left}px`, top: `${top}px`, width: `${width}px`, height: `${height}px` };
            });
        }, ...(ngDevMode ? [{ debugName: "selectionRangePositions" }] : []));
        this.fillRangePosition = computed(() => {
            this.rows();
            this.layoutTick();
            const fill = this.fillRange();
            const selection = this.selectionRanges()[this.selectionRanges().length - 1];
            const container = this.spreadsheetContainer();
            if (!fill || !selection || !container?.nativeElement)
                return { display: 'none' };
            const normSelection = this.normalizeRange(selection);
            const normFill = this.normalizeRange(fill);
            const startModel = this.visualToModelCoords(normSelection.start);
            const endModel = this.visualToModelCoords(normFill.end);
            if (!startModel || !endModel)
                return { display: 'none' };
            const startEl = container.nativeElement.querySelector(`td[data-row="${startModel.row}"][data-col="${startModel.col}"]`);
            const endEl = container.nativeElement.querySelector(`td[data-row="${endModel.row}"][data-col="${endModel.col}"]`);
            if (!startEl || !endEl)
                return { display: 'none' };
            const left = startEl.offsetLeft;
            const top = startEl.offsetTop;
            const width = (endEl.offsetLeft + endEl.offsetWidth) - left;
            const height = (endEl.offsetTop + endEl.offsetHeight) - top;
            return { display: 'block', left: `${left}px`, top: `${top}px`, width: `${width}px`, height: `${height}px` };
        }, ...(ngDevMode ? [{ debugName: "fillRangePosition" }] : []));
        this.activeSelectionRange = computed(() => {
            const active = this.activeCell();
            const ranges = this.selectionRanges();
            if (ranges.length === 0)
                return null;
            if (!active)
                return ranges[ranges.length - 1];
            return ranges.find(range => {
                const norm = this.normalizeRange(range);
                return active.row >= norm.start.row && active.row <= norm.end.row && active.col >= norm.start.col && active.col <= norm.end.col;
            }) ?? ranges[ranges.length - 1];
        }, ...(ngDevMode ? [{ debugName: "activeSelectionRange" }] : []));
        this.selectedRowCount = computed(() => {
            const selection = this.activeSelectionRange();
            if (!selection)
                return 0;
            const norm = this.normalizeRange(selection);
            return norm.end.row - norm.start.row + 1;
        }, ...(ngDevMode ? [{ debugName: "selectedRowCount" }] : []));
        this.selectedColCount = computed(() => {
            const selection = this.activeSelectionRange();
            if (!selection)
                return 0;
            const norm = this.normalizeRange(selection);
            return norm.end.col - norm.start.col + 1;
        }, ...(ngDevMode ? [{ debugName: "selectedColCount" }] : []));
        this.contextMenuData = computed(() => {
            const rowCount = this.selectedRowCount();
            const colCount = this.selectedColCount();
            const colIndex = this.contextMenuCoords()?.col;
            const selection = this.activeSelectionRange();
            let isDeleteReadOnly = true;
            if (selection) {
                const norm = this.normalizeRange(selection);
                const config = this.columnConfig()();
                isDeleteReadOnly = false;
                for (let c = norm.start.col; c <= norm.end.col; c++) {
                    if (config[c]?.readOnly || config[c]?.lockSettings) {
                        isDeleteReadOnly = true;
                        break;
                    }
                }
            }
            return {
                insertRowsAboveText: rowCount > 1 ? `Insert ${rowCount} rows above` : 'Insert row above',
                insertRowsBelowText: rowCount > 1 ? `Insert ${rowCount} rows below` : 'Insert row below',
                deleteRowText: rowCount > 1 ? `Delete ${rowCount} rows` : 'Delete row',
                deleteColText: colCount > 1 ? `Delete ${colCount} columns` : 'Delete column',
                isInsertColumnActionReadOnly: colIndex != null ? (this.columnConfig()()[colIndex]?.readOnly ?? false) : false,
                isDeleteColumnActionReadOnly: isDeleteReadOnly,
                canDeleteRows: this.rows().length > rowCount,
                canDeleteCols: this.colsCount() > colCount,
            };
        }, ...(ngDevMode ? [{ debugName: "contextMenuData" }] : []));
        this.filterPopupPosition = computed(() => {
            const popup = this.activeFilterPopup();
            const container = this.spreadsheetContainer();
            if (!popup || !container?.nativeElement)
                return { display: 'none', left: '0px', top: '0px' };
            const containerEl = container.nativeElement;
            const targetEl = popup.target;
            const containerRect = containerEl.getBoundingClientRect();
            const targetRect = targetEl.getBoundingClientRect();
            let left = targetRect.left - containerRect.left + containerEl.scrollLeft;
            const top = targetRect.top - containerRect.top + containerEl.scrollTop + targetRect.height + 2;
            const popupWidth = 256;
            if (left + popupWidth > containerEl.clientWidth + containerEl.scrollLeft) {
                left = containerEl.clientWidth + containerEl.scrollLeft - popupWidth;
            }
            left = Math.max(containerEl.scrollLeft, left);
            return { display: 'block', left: `${left}px`, top: `${top}px` };
        }, ...(ngDevMode ? [{ debugName: "filterPopupPosition" }] : []));
        this.currentFilterUniqueValues = computed(() => {
            const popup = this.activeFilterPopup();
            if (!popup)
                return [];
            const values = new Set();
            this.rows().forEach(row => values.add(String(row[popup.col]?.value ?? '')));
            return Array.from(values).sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
        }, ...(ngDevMode ? [{ debugName: "currentFilterUniqueValues" }] : []));
        this.filterPopupInitialSelection = computed(() => {
            const popup = this.activeFilterPopup();
            if (!popup) {
                return new Set();
            }
            return this.filterConfig().get(popup.col) ?? new Set(this.currentFilterUniqueValues());
        }, ...(ngDevMode ? [{ debugName: "filterPopupInitialSelection" }] : []));
        this.isColumnDragged = computed(() => {
            if (!this.isDraggingColumn() || !this.draggedColumnInfo())
                return new Set();
            const { startIndex, count } = this.draggedColumnInfo();
            const indices = new Set();
            for (let i = 0; i < count; i++) {
                indices.add(startIndex + i);
            }
            return indices;
        }, ...(ngDevMode ? [{ debugName: "isColumnDragged" }] : []));
        this.dropIndicatorPosition = computed(() => {
            this.rows();
            this.layoutTick();
            const dropIndex = this.dropColumnIndex();
            const container = this.spreadsheetContainer();
            if (!this.isDraggingColumn() || dropIndex === null || !container?.nativeElement)
                return { display: 'none' };
            const table = container.nativeElement.querySelector('table');
            const headerRow = table?.querySelector('thead tr');
            if (!headerRow)
                return { display: 'none' };
            const ths = Array.from(headerRow.children);
            if (ths.length < 2)
                return { display: 'none' };
            const rowHeaderTh = ths[0];
            let leftPosition = rowHeaderTh.offsetWidth;
            const colThs = ths.slice(1);
            for (let i = 0; i < dropIndex; i++) {
                leftPosition += colThs[i]?.offsetWidth ?? (typeof this.columnConfig()()[i]?.width === 'number' ? this.columnConfig()()[i].width : 135);
            }
            return { display: 'block', left: `${leftPosition - 1}px`, top: `${headerRow.offsetTop}px`, height: `${table.offsetHeight - headerRow.offsetTop}px` };
        }, ...(ngDevMode ? [{ debugName: "dropIndicatorPosition" }] : []));
        this.renderer = inject(Renderer2);
        this.document = inject(DOCUMENT);
        this.styleElement = null;
        this.getOptionValue = (option) => typeof option === 'string' ? option : option.value;
        this.getOptionColor = (option) => typeof option === 'string' ? undefined : option.color;
        this.getColumnWidth = (colIndex) => `${this.columnConfig()()[colIndex]?.width ?? 135}px`;
        this.isEditing = (r, c) => this.editingCell()?.row === r && this.editingCell()?.col === c;
        this.isCellInvalid = (r, c) => this.validationErrors().has(`${r}-${c}`);
        this.onCellDoubleClick = (r, c) => this.startEditing({ row: r, col: c });
        this.onCellMouseLeave = () => { clearTimeout(this.tooltipTimeout); this.isTooltipVisible.set(false); };
        this.onHeaderMouseLeave = () => { clearTimeout(this.headerTooltipTimeout); this.isHeaderTooltipVisible.set(false); };
        this.onEditBlur = () => { if (this.editingCell())
            this.saveEdit(); };
        this.closeContextMenu = () => { this.isContextMenuVisible.set(false); this.contextMenuType.set(null); this.contextMenuCoords.set(null); };
        this.onImportCSVClick = () => this.csvImporter()?.nativeElement.click();
        this.escapeHtml = (unsafe) => unsafe.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
        this.visualToModelCoords = (c) => c.row < 0 || c.row >= this.displayedRows().length ? null : { row: this.displayedRows()[c.row].originalModelIndex, col: c.col };
        this.modelToVisualCoords = (c) => { const vr = this.displayedRows().findIndex(i => i.originalModelIndex === c.row); return vr === -1 ? null : { row: vr, col: c.col }; };
        this._convertDataToTSV = (data) => data.map(row => row.map(cell => {
            const v = String(cell?.value ?? '');
            return v.match(/["\n\r\t]/) ? `"${v.replace(/"/g, '""')}"` : v;
        }).join('\t')).join('\n');
        this._convertDataToCSV = (data) => data.map(row => row.map(cell => {
            const v = String(cell?.value ?? '');
            return v.match(/["\n\r,]/) ? `"${v.replace(/"/g, '""')}"` : v;
        }).join(',')).join('\n');
        this.getCoordsFromTarget = (t) => { const c = t.closest('td[data-row][data-col]'); return c ? { row: parseInt(c.getAttribute('data-row')), col: parseInt(c.getAttribute('data-col')) } : null; };
        this.normalizeRange = (r) => ({ start: { row: Math.min(r.start.row, r.end.row), col: Math.min(r.start.col, r.end.col) }, end: { row: Math.max(r.start.row, r.end.row), col: Math.max(r.start.col, r.end.col) } });
        this._toKebabCase = (str) => String(str).replace(/([a-z\d])([A-Z])/g, '$1-$2').replace(/[\s_]+/g, '-').toLowerCase();
        effect(() => {
            const currentData = this.data()();
            if (this.isDataInitialized) {
                this.onDataChange.emit(currentData);
            }
            this.isDataInitialized = true;
        });
        effect(() => {
            const currentColumnConfig = this.columnConfig()();
            if (this.isColumnConfigInitialized) {
                this.onColumnChange.emit(currentColumnConfig);
            }
            this.isColumnConfigInitialized = true;
        });
        effect(() => {
            if (this.editingCell()) {
                setTimeout(() => {
                    const el = this.editingInput()?.nativeElement ?? this.dropdownSearchInput()?.nativeElement;
                    if (el) {
                        el.focus();
                        if (el instanceof HTMLTextAreaElement) {
                            this.isNewValueEntry() ? (el.selectionStart = el.selectionEnd = el.value.length) : el.select();
                            this.onEditorInput();
                        }
                    }
                }, 0);
            }
        });
        effect(() => { if (this.activeFilterPopup())
            setTimeout(() => this.filterPopupEl()?.nativeElement.querySelector('input')?.focus(), 0); });
        effect(() => { if (this.isDraggingColumn())
            document.body.style.cursor = 'grabbing';
        else
            document.body.style.cursor = ''; });
        // This effect handles resetting the active option index when the user types to filter.
        effect(() => {
            this.dropdownSearchText(); // Rerun when search text changes.
            this.dropdownActiveOptionIndex.set(0);
        });
        // This effect handles scrolling the active dropdown option into view when it changes.
        effect(() => {
            if (this.editingCell() && this.columnConfig()()[this.editingCell().col]?.editor === 'dropdown') {
                this.dropdownActiveOptionIndex(); // Rerun when index changes.
                this.scrollActiveDropdownOptionIntoView();
            }
        });
        effect(() => {
            if (this.isTooltipVisible()) {
                setTimeout(() => {
                    const tooltipEl = this.validationTooltip()?.nativeElement;
                    const containerEl = this.spreadsheetContainer()?.nativeElement;
                    if (!tooltipEl || !containerEl)
                        return;
                    let pos = this.tooltipPosition();
                    let { x, y } = pos;
                    if (x + tooltipEl.offsetWidth > containerEl.clientWidth + containerEl.scrollLeft)
                        x = x - tooltipEl.offsetWidth - 20;
                    if (y + tooltipEl.offsetHeight > containerEl.clientHeight + containerEl.scrollTop)
                        y = y - tooltipEl.offsetHeight - 20;
                    this.tooltipPosition.set({ x: Math.max(containerEl.scrollLeft + 5, x), y: Math.max(containerEl.scrollTop + 5, y) });
                }, 0);
            }
        }, { allowSignalWrites: true });
        effect(() => {
            if (this.isHeaderTooltipVisible()) {
                setTimeout(() => {
                    const tooltipEl = this.headerTooltip()?.nativeElement;
                    const rootEl = this.rootContainer()?.nativeElement;
                    const target = this.lastHeaderHoverTarget;
                    const spreadsheetEl = this.spreadsheetContainer()?.nativeElement;
                    if (!tooltipEl || !rootEl || !target || !spreadsheetEl)
                        return;
                    let { x, y } = this.headerTooltipPosition();
                    const rootRect = rootEl.getBoundingClientRect();
                    const targetRect = target.getBoundingClientRect();
                    const spreadsheetRect = spreadsheetEl.getBoundingClientRect();
                    if (rootRect.left + x + tooltipEl.offsetWidth > spreadsheetRect.right) {
                        x = Math.min(targetRect.right, spreadsheetRect.right) - tooltipEl.offsetWidth - rootRect.left;
                    }
                    if (rootRect.top + y + tooltipEl.offsetHeight > window.innerHeight) {
                        y = (targetRect.top - rootRect.top) - tooltipEl.offsetHeight - 2;
                    }
                    if (rootRect.left + x < spreadsheetRect.left) {
                        x = spreadsheetRect.left - rootRect.left;
                    }
                    this.headerTooltipPosition.set({ x, y });
                }, 0);
            }
        }, { allowSignalWrites: true });
        // Effect for dynamic scrollbar styling
        effect(() => {
            const styles = this.scrollbarStyles();
            const theme = this.theme();
            if (theme && styles) {
                if (!this.styleElement) {
                    this.styleElement = this.renderer.createElement('style');
                    this.renderer.appendChild(this.document.head, this.styleElement);
                }
                this.renderer.setProperty(this.styleElement, 'textContent', styles);
            }
            else if (this.styleElement) {
                this.renderer.removeChild(this.document.head, this.styleElement);
                this.styleElement = null;
            }
        });
        // Effect for layout observation
        effect(() => {
            const table = this.spreadsheetTable()?.nativeElement;
            if (table) {
                this.resizeObserver = new ResizeObserver(() => {
                    this.layoutTick.update(v => v + 1);
                });
                this.resizeObserver.observe(table);
            }
        });
    }
    ngOnDestroy() {
        if (this.styleElement) {
            this.renderer.removeChild(this.document.head, this.styleElement);
            this.styleElement = null;
        }
        this.resizeObserver?.disconnect();
    }
    // --- Public Methods / Template Helpers ---
    selectAllCells() {
        const lastRow = this.displayedRows().length - 1;
        const lastCol = this.colsCount() - 1;
        if (lastRow < 0 || lastCol < 0)
            return;
        const startCoords = { row: 0, col: 0 };
        this.activeCell.set(startCoords);
        this.selectionRanges.set([{ start: startCoords, end: { row: lastRow, col: lastCol } }]);
    }
    getCell(modelRow, modelCol) {
        return this.rows()[modelRow]?.[modelCol];
    }
    getDropdownOptionColor(modelRow, modelCol) {
        const cell = this.getCell(modelRow, modelCol);
        const colConfig = this.columnConfig()()[modelCol];
        if (!cell || colConfig?.editor !== 'dropdown' || !colConfig.options)
            return;
        const option = colConfig.options.find(opt => this.getOptionValue(opt) === String(cell.value));
        return option && typeof option !== 'string' ? option.color : undefined;
    }
    getHighlightedCellContent(modelRow, modelCol) {
        const cellValue = String(this.getCell(modelRow, modelCol)?.value ?? '');
        const query = this.findQuery();
        if (!query) {
            return this.escapeHtml(cellValue);
        }
        const options = this.findOptions();
        const escapedValue = this.escapeHtml(cellValue);
        const escapedQuery = this.escapeHtml(query);
        if (options.matchEntireCell) {
            const matches = options.matchCase
                ? cellValue === query
                : cellValue.toLowerCase() === query.toLowerCase();
            return matches ? `<mark class="bg-yellow-300 text-gray-900">${escapedValue}</mark>` : escapedValue;
        }
        // For partial matches, we need to highlight all occurrences
        const flags = options.matchCase ? 'g' : 'gi';
        const regex = new RegExp(this.escapeRegex(query), flags);
        // Find all matches and their positions in the original string
        let result = '';
        let lastIndex = 0;
        let match;
        while ((match = regex.exec(cellValue)) !== null) {
            // Add text before the match
            result += this.escapeHtml(cellValue.slice(lastIndex, match.index));
            // Add the highlighted match
            result += `<mark class="bg-yellow-300 text-gray-900">${this.escapeHtml(match[0])}</mark>`;
            lastIndex = match.index + match[0].length;
        }
        // Add remaining text after last match
        result += this.escapeHtml(cellValue.slice(lastIndex));
        return result;
    }
    escapeRegex(str) {
        return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
    // --- Find and Replace Methods ---
    onFindQueryChange(query) {
        this.findQuery.set(query);
        // Reset to first result when query changes
        if (this.findResults().length > 0) {
            this.currentFindIndex.set(0);
            this.navigateToCurrentMatch();
        }
        else {
            this.currentFindIndex.set(-1);
        }
    }
    onFindOptionsChange(options) {
        this.findOptions.set(options);
        // Reset to first result when options change
        if (this.findResults().length > 0) {
            this.currentFindIndex.set(0);
            this.navigateToCurrentMatch();
        }
        else {
            this.currentFindIndex.set(-1);
        }
    }
    navigateToNextMatch() {
        const results = this.findResults();
        if (results.length === 0)
            return;
        const nextIndex = (this.currentFindIndex() + 1) % results.length;
        this.currentFindIndex.set(nextIndex);
        this.navigateToCurrentMatch();
    }
    navigateToPrevMatch() {
        const results = this.findResults();
        if (results.length === 0)
            return;
        const prevIndex = (this.currentFindIndex() - 1 + results.length) % results.length;
        this.currentFindIndex.set(prevIndex);
        this.navigateToCurrentMatch();
    }
    navigateToCurrentMatch() {
        const results = this.findResults();
        const index = this.currentFindIndex();
        if (index < 0 || index >= results.length)
            return;
        const coords = results[index];
        // Select the cell and scroll to it
        const visualCoords = this.modelToVisualCoords(coords);
        if (visualCoords) {
            this.activeCell.set(visualCoords);
            this.selectionRanges.set([{ start: visualCoords, end: visualCoords }]);
            this.scrollCellIntoView(coords, visualCoords);
        }
    }
    replaceCurrentMatch(replacement) {
        const results = this.findResults();
        const index = this.currentFindIndex();
        if (index < 0 || index >= results.length)
            return;
        const coords = results[index];
        const cell = this.getCell(coords.row, coords.col);
        if (!cell || cell.readOnly)
            return;
        this.recordHistory();
        const query = this.findQuery();
        const options = this.findOptions();
        const cellValue = String(cell.value ?? '');
        let newValue;
        if (options.matchEntireCell) {
            newValue = replacement;
        }
        else {
            const flags = options.matchCase ? 'g' : 'gi';
            const regex = new RegExp(this.escapeRegex(query), flags);
            newValue = cellValue.replace(regex, replacement);
        }
        this.data().update(grid => {
            const newGrid = grid.map(r => [...r]);
            newGrid[coords.row][coords.col] = { ...newGrid[coords.row][coords.col], value: newValue };
            return newGrid;
        });
        // Move to next match if available
        setTimeout(() => {
            if (this.findResults().length > 0) {
                // Adjust index if current was removed
                const newIndex = Math.min(index, this.findResults().length - 1);
                this.currentFindIndex.set(newIndex);
                this.navigateToCurrentMatch();
            }
            else {
                this.currentFindIndex.set(-1);
            }
        }, 0);
    }
    replaceAllMatches(replacement) {
        const results = this.findResults();
        if (results.length === 0)
            return;
        this.recordHistory();
        const query = this.findQuery();
        const options = this.findOptions();
        this.data().update(grid => {
            const newGrid = grid.map(r => [...r]);
            results.forEach(coords => {
                const cell = newGrid[coords.row][coords.col];
                if (cell.readOnly)
                    return;
                const cellValue = String(cell.value ?? '');
                let newValue;
                if (options.matchEntireCell) {
                    newValue = replacement;
                }
                else {
                    const flags = options.matchCase ? 'g' : 'gi';
                    const regex = new RegExp(this.escapeRegex(query), flags);
                    newValue = cellValue.replace(regex, replacement);
                }
                newGrid[coords.row][coords.col] = { ...cell, value: newValue };
            });
            return newGrid;
        });
        // Clear find state after replace all
        this.currentFindIndex.set(-1);
    }
    closeFindReplace() {
        this.isFindReplaceVisible.set(false);
        this.findQuery.set('');
        this.currentFindIndex.set(-1);
    }
    isSelected(modelRow, modelCol) {
        const visualCoords = this.modelToVisualCoords({ row: modelRow, col: modelCol });
        if (!visualCoords)
            return false;
        return this.selectionRanges().some(range => {
            const norm = this.normalizeRange(range);
            return visualCoords.row >= norm.start.row && visualCoords.row <= norm.end.row && visualCoords.col >= norm.start.col && visualCoords.col <= norm.end.col;
        });
    }
    isActive(modelRow, modelCol) {
        const active = this.activeCell();
        const visualCoords = this.modelToVisualCoords({ row: modelRow, col: modelCol });
        return !!active && !!visualCoords && active.row === visualCoords.row && active.col === visualCoords.col;
    }
    isFillHandleVisible(modelRow, modelCol) {
        const visualCoords = this.modelToVisualCoords({ row: modelRow, col: modelCol });
        if (!visualCoords)
            return false;
        const lastRange = this.selectionRanges()[this.selectionRanges().length - 1];
        if (!lastRange)
            return false;
        const { end } = this.normalizeRange(lastRange);
        return visualCoords.row === end.row && visualCoords.col === end.col;
    }
    isInFillRange(modelRow, modelCol) {
        const visualCoords = this.modelToVisualCoords({ row: modelRow, col: modelCol });
        if (!visualCoords)
            return false;
        const range = this.fillRange();
        if (!range)
            return false;
        const { start, end } = this.normalizeRange(range);
        return visualCoords.row >= start.row && visualCoords.row <= end.row && visualCoords.col >= start.col && visualCoords.col <= end.col;
    }
    onCheckboxChange(event, modelRow, modelCol) {
        const target = event.target;
        if (this.getCell(modelRow, modelCol)?.readOnly) {
            target.checked = !target.checked;
            return;
        }
        this.recordHistory();
        this.data().update(grid => {
            const newGrid = grid.map(r => [...r]);
            newGrid[modelRow][modelCol] = { ...newGrid[modelRow][modelCol], value: target.checked };
            return newGrid;
        });
    }
    isCheckboxChecked(modelRow, modelCol) {
        const cell = this.getCell(modelRow, modelCol);
        if (!cell)
            return false;
        const val = cell.value;
        if (typeof val === 'boolean') {
            return val;
        }
        if (typeof val === 'number') {
            return val !== 0;
        }
        if (typeof val === 'string') {
            const lower = val.toLowerCase().trim();
            return lower === 'true' || lower === '1' || lower === 'yes';
        }
        return false;
    }
    handleContextMenuAction(action) {
        switch (action) {
            case 'openStatsModal':
                this.isStatsModalVisible.set(true);
                break;
            case 'openFindReplace':
                this.isFindReplaceVisible.set(true);
                break;
            case 'copyTableData':
                this.copyTableData();
                break;
            case 'intelligentReplaceTableData':
                this.intelligentReplaceTableData();
                break;
            case 'importCSV':
                this.onImportCSVClick();
                break;
            case 'exportCSV':
                this.exportToCSV();
                break;
            case 'insertRowAbove':
                this.insertRowAbove();
                break;
            case 'insertRowBelow':
                this.insertRowBelow();
                break;
            case 'deleteRows':
                this.deleteRows();
                break;
            case 'openColumnSettings':
                this.openColumnSettings(this.contextMenuCoords().col);
                break;
            case 'insertColumnLeft':
                this.insertColumnLeft();
                break;
            case 'insertColumnRight':
                this.insertColumnRight();
                break;
            case 'deleteColumn':
                this.deleteColumn();
                break;
            case 'copy':
                this._copySelectionToClipboard();
                break;
            case 'paste':
                this.pasteFromContextMenu();
                break;
        }
        this.closeContextMenu();
    }
    // --- Event Handlers ---
    onHostMouseDown(event) {
        const target = event.target;
        if (this.isStatsModalVisible() && !target.closest('.stats-modal-panel'))
            this.isStatsModalVisible.set(false);
        if (target.classList.contains('col-resize-handle') || this.editingCell() || event.button !== 0)
            return;
        const isCtrlOrCmd = event.ctrlKey || event.metaKey;
        if (this.activeFilterPopup() && !target.closest('.filter-popup'))
            this.activeFilterPopup.set(null);
        const colHeader = target.closest('th[data-col-index]');
        if (colHeader) {
            if (target.closest('.pi'))
                return;
            this.isMouseDown.set(true);
            this.isSelectingCols.set(true);
            const colIndex = parseInt(colHeader.getAttribute('data-col-index'), 10);
            const lastRow = this.displayedRows().length - 1;
            if (event.shiftKey && this.activeCell()) {
                const active = this.activeCell();
                this.selectionRanges.set([{ start: { row: 0, col: Math.min(active.col, colIndex) }, end: { row: lastRow, col: Math.max(active.col, colIndex) } }]);
            }
            else {
                const newSelection = { start: { row: 0, col: colIndex }, end: { row: lastRow, col: colIndex } };
                this.activeCell.set({ row: 0, col: colIndex });
                isCtrlOrCmd ? this.selectionRanges.update(r => [...r, newSelection]) : this.selectionRanges.set([newSelection]);
            }
            const selection = this.activeSelectionRange();
            const norm = this.normalizeRange(selection);
            this.draggedColumnInfo.set({ startIndex: norm.start.col, count: norm.end.col - norm.start.col + 1, startX: event.clientX });
            this.fillRange.set(null);
            event.preventDefault();
            return;
        }
        const rowHeader = target.closest('th[data-row-index]');
        if (rowHeader) {
            this.isMouseDown.set(true);
            this.isSelectingRows.set(true);
            const visualRowIndex = parseInt(rowHeader.getAttribute('data-row-index'), 10);
            const lastCol = this.colsCount() - 1;
            if (event.shiftKey && this.activeCell()) {
                const active = this.activeCell();
                this.selectionRanges.set([{ start: { row: Math.min(active.row, visualRowIndex), col: 0 }, end: { row: Math.max(active.row, visualRowIndex), col: lastCol } }]);
            }
            else {
                const newSelection = { start: { row: visualRowIndex, col: 0 }, end: { row: visualRowIndex, col: lastCol } };
                this.activeCell.set(newSelection.start);
                isCtrlOrCmd ? this.selectionRanges.update(r => [...r, newSelection]) : this.selectionRanges.set([newSelection]);
            }
            this.fillRange.set(null);
            event.preventDefault();
            return;
        }
        const modelCoords = this.getCoordsFromTarget(target);
        const isFillHandle = target.classList.contains('fill-handle');
        if (modelCoords || isFillHandle) {
            this.isMouseDown.set(true);
            if (isFillHandle) {
                this.isDraggingFill.set(true);
                return;
            }
            if (modelCoords) {
                const visualCoords = this.modelToVisualCoords(modelCoords);
                if (!visualCoords)
                    return;
                if (event.shiftKey && this.activeCell() && this.selectionRanges().length > 0) {
                    this.selectionRanges.update(r => [...r.slice(0, -1), { start: r[r.length - 1].start, end: visualCoords }]);
                }
                else if (isCtrlOrCmd) {
                    this.activeCell.set(visualCoords);
                    this.selectionRanges.update(r => [...r, { start: visualCoords, end: visualCoords }]);
                }
                else {
                    this.activeCell.set(visualCoords);
                    this.selectionRanges.set([{ start: visualCoords, end: visualCoords }]);
                }
                this.fillRange.set(null);
            }
        }
    }
    onDocumentMouseMove(event) {
        if (!this.spreadsheetContainer()?.nativeElement)
            return;
        if (!this.isMouseDown())
            return;
        const resizingCol = this.isResizingCol();
        if (resizingCol !== null && this.resizingColStart()) {
            const newWidth = Math.max(60, this.resizingColStart().width + (event.clientX - this.resizingColStart().x));
            this.columnConfig().update(configs => {
                const newConfigs = [...configs];
                if (!newConfigs[resizingCol])
                    newConfigs[resizingCol] = { name: '', field: '' };
                newConfigs[resizingCol] = { ...newConfigs[resizingCol], width: newWidth };
                return newConfigs;
            });
            return;
        }
        const dragInfo = this.draggedColumnInfo();
        if (dragInfo) {
            if (!this.isDraggingColumn() && Math.abs(event.clientX - dragInfo.startX) > 5)
                this.isDraggingColumn.set(true);
            if (!this.isDraggingColumn())
                return;
            const colHeader = event.target.closest('th[data-col-index]');
            if (colHeader) {
                const colIndex = parseInt(colHeader.getAttribute('data-col-index'), 10);
                const rect = colHeader.getBoundingClientRect();
                const potentialDropIndex = event.clientX < rect.left + rect.width / 2 ? colIndex : colIndex + 1;
                this.dropColumnIndex.set((potentialDropIndex > dragInfo.startIndex && potentialDropIndex <= dragInfo.startIndex + dragInfo.count) ? null : potentialDropIndex);
            }
            else {
                const spreadsheetRect = this.spreadsheetContainer().nativeElement.getBoundingClientRect();
                if (event.clientX < spreadsheetRect.left)
                    this.dropColumnIndex.set(0);
                else if (event.clientX > spreadsheetRect.right)
                    this.dropColumnIndex.set(this.colsCount());
            }
            return;
        }
        const target = event.target;
        const lastRange = this.selectionRanges()[this.selectionRanges().length - 1];
        if (!lastRange)
            return;
        if (this.isSelectingRows()) {
            const rowHeader = target.closest('th[data-row-index]');
            if (rowHeader) {
                const visualRowIndex = parseInt(rowHeader.getAttribute('data-row-index'), 10);
                this.selectionRanges.update(r => [...r.slice(0, -1), { ...lastRange, end: { ...lastRange.end, row: visualRowIndex } }]);
            }
            return;
        }
        if (this.isSelectingCols()) {
            const colHeader = target.closest('th[data-col-index]');
            if (colHeader) {
                const colIndex = parseInt(colHeader.getAttribute('data-col-index'), 10);
                this.selectionRanges.update(r => [...r.slice(0, -1), { ...lastRange, end: { ...lastRange.end, col: colIndex } }]);
            }
            return;
        }
        const modelCoords = this.getCoordsFromTarget(target);
        if (!modelCoords)
            return;
        const visualCoords = this.modelToVisualCoords(modelCoords);
        if (!visualCoords)
            return;
        if (this.isDraggingFill()) {
            const normSel = this.normalizeRange(lastRange);
            const isVerticalDrag = Math.abs(visualCoords.row - normSel.end.row) > Math.abs(visualCoords.col - normSel.end.col);
            const fillEnd = isVerticalDrag ? { row: Math.max(normSel.end.row, visualCoords.row), col: normSel.end.col } : { row: normSel.end.row, col: Math.max(normSel.end.col, visualCoords.col) };
            this.fillRange.set({ start: normSel.start, end: fillEnd });
        }
        else {
            this.selectionRanges.update(r => [...r.slice(0, -1), { start: lastRange.start, end: visualCoords }]);
        }
    }
    onDocumentMouseUp(event) {
        if (this.isResizingCol() !== null) {
            this.isResizingCol.set(null);
            this.resizingColStart.set(null);
        }
        if (this.isDraggingColumn())
            this.reorderColumns();
        if (this.isDraggingFill())
            this.applyFill(this.fillRange());
        this.isMouseDown.set(false);
        this.isDraggingFill.set(false);
        this.isSelectingRows.set(false);
        this.isSelectingCols.set(false);
        this.fillRange.set(null);
        this.isDraggingColumn.set(false);
        this.draggedColumnInfo.set(null);
        this.dropColumnIndex.set(null);
    }
    onFillHandleDoubleClick(event) {
        event.preventDefault();
        event.stopPropagation();
        const selection = this.activeSelectionRange();
        if (!selection)
            return;
        const normSel = this.normalizeRange(selection);
        const displayedData = this.displayedRows();
        if (normSel.end.row >= displayedData.length - 1)
            return;
        let finalStopRow = displayedData.length;
        for (let c = normSel.start.col; c <= normSel.end.col; c++) {
            let columnStopRow = displayedData.length;
            for (let r = normSel.end.row + 1; r < displayedData.length; r++) {
                const modelCoords = this.visualToModelCoords({ row: r, col: c });
                if (!modelCoords) {
                    columnStopRow = r;
                    break;
                }
                const value = this.getCell(modelCoords.row, modelCoords.col)?.value;
                if (value != null && String(value).trim() !== '') {
                    columnStopRow = r;
                    break;
                }
            }
            finalStopRow = Math.min(finalStopRow, columnStopRow);
        }
        const fillTargetEndRow = finalStopRow - 1;
        if (fillTargetEndRow > normSel.end.row) {
            this.applyFill({ start: normSel.start, end: { row: fillTargetEndRow, col: normSel.end.col } });
        }
    }
    onCellMouseEnter(event, modelRow, modelCol) {
        const error = this.validationErrors().get(`${modelRow}-${modelCol}`);
        if (!error)
            return;
        clearTimeout(this.tooltipTimeout);
        this.tooltipTimeout = setTimeout(() => {
            this.tooltipText.set(error);
            const container = this.spreadsheetContainer().nativeElement;
            const rect = container.getBoundingClientRect();
            this.tooltipPosition.set({ x: event.clientX - rect.left + container.scrollLeft + 10, y: event.clientY - rect.top + container.scrollTop + 10 });
            this.isTooltipVisible.set(true);
        }, 500);
    }
    onHeaderMouseEnter(event, colIndex) {
        this.lastHeaderHoverTarget = event.currentTarget;
        clearTimeout(this.headerTooltipTimeout);
        this.headerTooltipTimeout = setTimeout(() => {
            if (!this.rootContainer())
                return;
            const config = this.columnConfig()()[colIndex];
            const type = config?.editor ?? 'text';
            this.headerTooltipContent.set({ name: config.name, description: config?.description, type: type.charAt(0).toUpperCase() + type.slice(1), kebabName: config.field });
            const rootRect = this.rootContainer().nativeElement.getBoundingClientRect();
            const targetRect = this.lastHeaderHoverTarget.getBoundingClientRect();
            this.headerTooltipPosition.set({ x: targetRect.left - rootRect.left, y: targetRect.top - rootRect.top + targetRect.height + 2 });
            this.isHeaderTooltipVisible.set(true);
        }, 700);
    }
    onKeyDown(event) {
        // Handle Escape key for modals first, and then stop further processing.
        if (this.isFindReplaceVisible()) {
            if (event.key === 'Escape')
                this.isFindReplaceVisible.set(false);
            return; // Stop spreadsheet from handling keys
        }
        if (this.isColumnSettingsVisible()) {
            if (event.key === 'Escape')
                this.isColumnSettingsVisible.set(false);
            return; // Stop spreadsheet from handling keys
        }
        if (this.isStatsModalVisible()) {
            if (event.key === 'Escape')
                this.isStatsModalVisible.set(false);
            return; // Stop spreadsheet from handling keys
        }
        // If we are editing a cell, let the cell editor handle it
        if (this.editingCell())
            return;
        // --- Spreadsheet Global Shortcuts ---
        // Select All
        if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'a') {
            event.preventDefault();
            this.selectAllCells();
            return;
        }
        // Find/Replace shortcut
        if ((event.ctrlKey || event.metaKey) && (event.key.toLowerCase() === 'r' || event.key.toLowerCase() === 'f')) {
            event.preventDefault();
            this.isFindReplaceVisible.set(true);
            return;
        }
        // Undo/Redo
        if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'z') {
            event.preventDefault();
            // The `cancelEdit` is no longer needed here as the `editingCell` guard handles it
            event.shiftKey ? this.redo() : this.undo();
            return;
        }
        // --- Grid Navigation and Interaction ---
        if ((event.ctrlKey || event.metaKey) && ['c', 'v'].includes(event.key.toLowerCase())) {
            event.preventDefault();
            if (event.key.toLowerCase() === 'c')
                this._copySelectionToClipboard();
            else if (this.getPasteStartCoords())
                this._pasteFromClipboard(this.getPasteStartCoords());
            return;
        }
        const active = this.activeCell();
        if (!active)
            return;
        const modelCoords = this.visualToModelCoords(active);
        if (!modelCoords)
            return;
        const colConfig = this.columnConfig()()[modelCoords.col];
        if (colConfig?.editor === 'checkbox' && (event.key === ' ' || event.key === 'Enter')) {
            event.preventDefault();
            this.toggleCheckbox(modelCoords.row, modelCoords.col);
            return;
        }
        const keyMap = {
            Enter: () => this.startEditing(modelCoords),
            Escape: () => { this.activeCell.set(null); this.selectionRanges.set([]); this.closeContextMenu(); this.activeFilterPopup.set(null); this.isColumnSettingsVisible.set(false); },
            ArrowUp: () => this.moveActiveCell(-1, 0, event.shiftKey),
            ArrowDown: () => this.moveActiveCell(1, 0, event.shiftKey),
            ArrowLeft: () => this.moveActiveCell(0, -1, event.shiftKey),
            ArrowRight: () => this.moveActiveCell(0, 1, event.shiftKey),
            Delete: () => this.clearSelectedCells(),
            Backspace: () => this.clearSelectedCells(),
        };
        if (keyMap[event.key]) {
            event.preventDefault();
            keyMap[event.key]();
        }
        else if (!event.ctrlKey && !event.metaKey && event.key.length === 1) {
            event.preventDefault();
            this.startEditing(modelCoords, event.key);
        }
    }
    async onCopy(event) { if (!this.editingCell()) {
        event.preventDefault();
        await this._copySelectionToClipboard();
    } }
    async onPaste(event) { if (!this.editingCell()) {
        event.preventDefault();
        const coords = this.getPasteStartCoords();
        if (coords)
            await this._pasteFromClipboard(coords);
    } }
    onColResizeMouseDown(event, colIndex) {
        event.preventDefault();
        event.stopPropagation();
        this.isMouseDown.set(true);
        this.isResizingCol.set(colIndex);
        const th = event.target.closest('th');
        if (th)
            this.resizingColStart.set({ x: event.clientX, width: th.offsetWidth });
    }
    // --- Editing Logic ---
    startEditing(coords, initialValue) {
        const cell = this.getCell(coords.row, coords.col);
        const colConfig = this.columnConfig()()[coords.col];
        if (cell?.readOnly || colConfig?.editor === 'checkbox')
            return;
        this.isNewValueEntry.set(initialValue !== undefined);
        const cellElement = this.spreadsheetContainer().nativeElement.querySelector(`td[data-row="${coords.row}"][data-col="${coords.col}"]`);
        if (cellElement) {
            const editorBorderOffset = 1;
            this.editorPosition.set({ top: cellElement.offsetTop - editorBorderOffset, left: cellElement.offsetLeft - editorBorderOffset, width: cellElement.offsetWidth + (editorBorderOffset * 2), height: cellElement.offsetHeight + (editorBorderOffset * 2) });
            let valueToEdit = initialValue ?? cell?.value ?? '';
            if (colConfig?.editor === 'dropdown') {
                const currentVal = String(cell?.value);
                // When the dropdown opens, the search text is empty, so we work with the full options list.
                const options = colConfig.options?.map(o => this.getOptionValue(o)) ?? [];
                valueToEdit = options.includes(currentVal) ? currentVal : options[0] ?? '';
                // Set the initial highlighted option to match the cell's current value.
                const activeIndex = options.indexOf(currentVal);
                this.dropdownActiveOptionIndex.set(activeIndex > -1 ? activeIndex : 0);
            }
            this.editValue.set(valueToEdit);
            this.editingCell.set(coords);
        }
    }
    onEditKeyDown(event) {
        if (event.key === 'Enter' && (event.altKey || event.metaKey)) {
            event.preventDefault();
            const textarea = event.target;
            const { selectionStart, selectionEnd, value } = textarea;
            this.editValue.set(value.substring(0, selectionStart) + '\n' + value.substring(selectionEnd));
            setTimeout(() => { textarea.selectionStart = textarea.selectionEnd = selectionStart + 1; this.onEditorInput(); });
            return;
        }
        if (event.key === 'Enter') {
            event.preventDefault();
            this.saveEdit();
            this.moveActiveCell(1, 0, false);
        }
        else if (event.key === 'Escape')
            this.cancelEdit();
    }
    onEditorInput() {
        const el = this.editingInput()?.nativeElement;
        const initialPos = this.editorPosition();
        if (el instanceof HTMLTextAreaElement && initialPos && el.parentElement) {
            el.style.height = 'auto';
            const requiredParentHeight = el.scrollHeight + 18;
            el.parentElement.style.height = `${Math.max(initialPos.height, requiredParentHeight)}px`;
            el.style.height = `${el.parentElement.offsetHeight - 18}px`;
        }
    }
    saveEdit() {
        const editing = this.editingCell();
        if (!editing)
            return;
        const originalValue = this.getCell(editing.row, editing.col)?.value;
        let newValue = this.editValue();
        const colConfig = this.columnConfig()()[editing.col];
        if (colConfig?.editor === 'numeric') {
            const stringValue = String(newValue).trim();
            if (stringValue === '')
                newValue = '';
            else {
                const parsed = parseFloat(stringValue);
                if (!isNaN(parsed) && isFinite(parsed))
                    newValue = parsed;
            }
        }
        if (originalValue !== newValue) {
            this.recordHistory();
            this.data().update(grid => {
                const newGrid = grid.map(r => [...r]);
                newGrid[editing.row][editing.col] = { ...newGrid[editing.row][editing.col], value: newValue };
                return newGrid;
            });
        }
        this.cancelEdit();
    }
    cancelEdit() {
        this.editingCell.set(null);
        this.editorPosition.set(null);
        this.dropdownSearchText.set('');
        this.dropdownActiveOptionIndex.set(0);
        setTimeout(() => this.spreadsheetContainer()?.nativeElement.focus({ preventScroll: true }), 0);
    }
    selectDropdownOption(option) {
        const editing = this.editingCell();
        if (!editing)
            return;
        this.recordHistory();
        const value = this.getOptionValue(option);
        this.data().update(grid => {
            const newGrid = grid.map(r => [...r]);
            newGrid[editing.row][editing.col] = { ...newGrid[editing.row][editing.col], value };
            return newGrid;
        });
        this.cancelEdit();
    }
    editDropdownOptions() {
        const colIndex = this.editingCell().col;
        this.cancelEdit();
        this.openColumnSettings(colIndex);
    }
    onDropdownKeyDown(event) {
        event.stopPropagation();
        const options = this.filteredDropdownOptions();
        if (options.length === 0 && event.key !== 'Escape')
            return;
        const keyMap = {
            ArrowDown: () => this.dropdownActiveOptionIndex.update(i => (i + 1) % options.length),
            ArrowUp: () => this.dropdownActiveOptionIndex.update(i => (i - 1 + options.length) % options.length),
            Enter: () => this.selectDropdownOption(options[this.dropdownActiveOptionIndex()]),
            ' ': () => this.selectDropdownOption(options[this.dropdownActiveOptionIndex()]),
            Escape: () => this.cancelEdit(),
        };
        if (keyMap[event.key]) {
            event.preventDefault();
            keyMap[event.key]();
            if (['ArrowDown', 'ArrowUp'].includes(event.key))
                this.scrollActiveDropdownOptionIntoView();
        }
    }
    // --- Header Actions ---
    toggleSort(col) {
        const current = this.sortConfig();
        if (current?.col === col && current.direction === 'asc')
            this.sortConfig.set({ col, direction: 'desc' });
        else if (current?.col === col)
            this.sortConfig.set(null);
        else
            this.sortConfig.set({ col, direction: 'asc' });
    }
    toggleFilterPopup(col, event) {
        event.stopPropagation();
        if (this.activeFilterPopup()?.col === col)
            this.activeFilterPopup.set(null);
        else {
            this.activeFilterPopup.set({ col, target: event.currentTarget });
        }
    }
    handleApplyFilter({ col, selection }) {
        const allValues = this.currentFilterUniqueValues();
        this.filterConfig.update(filters => {
            const newFilters = new Map(filters);
            if (selection.size === allValues.length || selection.size === 0)
                newFilters.delete(col);
            else
                newFilters.set(col, selection);
            return newFilters;
        });
        this.activeFilterPopup.set(null);
    }
    handleClearFilter(col) {
        this.filterConfig.update(filters => { const newFilters = new Map(filters); newFilters.delete(col); return newFilters; });
        this.activeFilterPopup.set(null);
    }
    // --- Column Settings ---
    openColumnSettings(colIndex) {
        this.closeContextMenu();
        this.columnSettingsColIndex.set(colIndex);
        this.isColumnSettingsVisible.set(true);
    }
    handleSaveColumnSettings({ colIndex, formState }) {
        this.recordHistory();
        this.columnConfig().update(configs => {
            const newConfigs = [...configs];
            const oldConfig = newConfigs[colIndex] ?? { name: '', field: '' };
            const newOptions = formState.type === 'dropdown' ? formState.options.map(opt => ({ value: opt.value.trim(), color: opt.color })).filter(opt => opt.value) : undefined;
            const newEditor = formState.type === 'text' ? undefined : formState.type;
            if (oldConfig.lockSettings) {
                newConfigs[colIndex] = {
                    ...oldConfig,
                    width: formState.widthValue ?? 135,
                };
            }
            else {
                newConfigs[colIndex] = {
                    ...oldConfig,
                    name: formState.name,
                    field: this._toKebabCase(formState.name),
                    description: formState.description || undefined,
                    width: formState.widthValue ?? 135,
                    editor: newEditor,
                    options: newOptions,
                };
            }
            return newConfigs;
        });
        if (!this.columnConfig()()[colIndex]?.lockSettings) {
            this.data().update(grid => {
                const newGrid = grid.map(r => [...r]);
                for (let r = 0; r < newGrid.length; r++) {
                    const oldCell = newGrid[r][colIndex];
                    if (!oldCell)
                        continue;
                    let newValue = oldCell.value;
                    if (formState.type === 'numeric')
                        newValue = (typeof oldCell.value === 'string' && oldCell.value.trim() !== '') ? parseFloat(oldCell.value) : (typeof oldCell.value === 'boolean' ? (oldCell.value ? 1 : 0) : newValue);
                    else if (formState.type === 'checkbox')
                        newValue = ['true', '1'].includes(String(oldCell.value).toLowerCase().trim());
                    else
                        newValue = String(oldCell.value);
                    const newCell = { ...oldCell, value: newValue };
                    newGrid[r][colIndex] = newCell;
                }
                return newGrid;
            });
        }
        this.isColumnSettingsVisible.set(false);
    }
    // --- Context Menu Logic ---
    adjustContextMenuPosition() {
        // If menu was closed, stop.
        if (!this.isContextMenuVisible())
            return;
        const menuHostEl = this.contextMenuEl()?.elementRef.nativeElement;
        const containerEl = this.rootContainer()?.nativeElement;
        if (!menuHostEl || !containerEl) {
            setTimeout(() => this.adjustContextMenuPosition(), 10);
            return;
        }
        const menuPopupEl = menuHostEl.querySelector('.long-spreadsheet-context-menu > div') || menuHostEl.firstElementChild;
        if (!menuPopupEl) {
            setTimeout(() => this.adjustContextMenuPosition(), 10);
            return;
        }
        const { offsetWidth: menuWidth, offsetHeight: menuHeight } = menuPopupEl;
        if (menuWidth === 0 || menuHeight === 0) {
            setTimeout(() => this.adjustContextMenuPosition(), 10);
            return;
        }
        const launchCoords = this.menuLaunchCoords();
        if (!launchCoords)
            return;
        const clickX = launchCoords.x;
        const clickY = launchCoords.y;
        const containerRect = containerEl.getBoundingClientRect();
        const margin = 5;
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;
        const boundRight = Math.min(containerRect.right, viewportWidth);
        const boundBottom = Math.min(containerRect.bottom, viewportHeight);
        const boundLeft = Math.max(containerRect.left, 0);
        const boundTop = Math.max(containerRect.top, 0);
        let finalX = clickX;
        let finalY = clickY;
        if (finalX + menuWidth + margin > boundRight)
            finalX = clickX - menuWidth;
        if (finalY + menuHeight + margin > boundBottom)
            finalY = clickY - menuHeight;
        const maxLeft = boundRight - menuWidth - margin;
        const minLeft = boundLeft + margin;
        finalX = Math.max(minLeft, Math.min(finalX, maxLeft));
        finalY = Math.max(boundTop + margin, Math.min(finalY, boundBottom - menuHeight - margin));
        this.contextMenuPosition.set({ x: finalX, y: finalY });
    }
    onDocumentMouseDown(event) {
        const target = event.target;
        // If a dropdown editor is open, its own mousedown handler stops propagation.
        // Therefore, if this document-level listener fires, the click must have been outside the dropdown.
        const editing = this.editingCell();
        if (editing && this.columnConfig()()[editing.col]?.editor === 'dropdown') {
            this.cancelEdit();
        }
        // Ignore clicks on filter toggles; their own (click) handler will manage state.
        if (target.closest('.filter-toggle-btn')) {
            return;
        }
        // For any other mousedown that reaches the document, close transient UI elements.
        // Clicks inside modals/popups should have propagation stopped by their own handlers.
        this.closeContextMenu();
        this.activeFilterPopup.set(null);
        // If the click was completely outside the component, clear the selection.
        const rootEl = this.rootContainer()?.nativeElement;
        if (rootEl && !rootEl.contains(target)) {
            this.activeCell.set(null);
            this.selectionRanges.set([]);
        }
    }
    onHeaderCornerContextMenu(event) {
        event.preventDefault();
        this.closeContextMenu();
        this.contextMenuType.set('headerCorner');
        this.openContextMenu(event);
    }
    onCellContextMenu(event, modelRow, modelCol) {
        event.preventDefault();
        this.closeContextMenu();
        const visual = this.modelToVisualCoords({ row: modelRow, col: modelCol });
        if (!visual)
            return;
        if (!this.isSelected(modelRow, modelCol)) {
            this.activeCell.set(visual);
            this.selectionRanges.set([{ start: visual, end: visual }]);
        }
        this.contextMenuType.set('cell');
        this.contextMenuCoords.set({ row: modelRow, col: modelCol });
        this.openContextMenu(event);
    }
    onRowContextMenu(event, visualRowIndex) {
        event.preventDefault();
        this.closeContextMenu();
        const modelRow = this.displayedRows()[visualRowIndex].originalModelIndex;
        if (!this.isSelected(modelRow, 0)) {
            const start = { row: visualRowIndex, col: 0 };
            this.activeCell.set(start);
            this.selectionRanges.set([{ start, end: { row: visualRowIndex, col: this.colsCount() - 1 } }]);
        }
        this.contextMenuType.set('row');
        this.contextMenuCoords.set({ row: modelRow, col: 0 });
        this.openContextMenu(event);
    }
    onColumnContextMenu(event, colIndex) {
        event.preventDefault();
        this.closeContextMenu();
        const visual = this.modelToVisualCoords({ row: 0, col: colIndex });
        if (!this.isSelected(0, colIndex) && visual) {
            const start = { row: 0, col: colIndex };
            this.activeCell.set(visual);
            this.selectionRanges.set([{ start, end: { row: this.displayedRows().length - 1, col: colIndex } }]);
        }
        this.contextMenuType.set('col');
        this.contextMenuCoords.set({ row: 0, col: colIndex });
        this.openContextMenu(event);
    }
    openContextMenu(event) {
        this.menuLaunchCoords.set({ x: event.clientX, y: event.clientY });
        this.contextMenuPosition.set({ x: event.clientX, y: event.clientY });
        this.isContextMenuVisible.set(true);
        // Defer adjustment slightly to allow initial render
        setTimeout(() => this.adjustContextMenuPosition(), 0);
    }
    insertRowAbove() {
        const selection = this.activeSelectionRange();
        if (!selection)
            return;
        this.recordHistory();
        const { start } = this.normalizeRange(selection);
        const modelCoords = this.visualToModelCoords(start);
        if (!modelCoords)
            return;
        const newRows = Array.from({ length: this.selectedRowCount() }, () => this._createNewRow());
        this.data().update(grid => { const newGrid = [...grid]; newGrid.splice(modelCoords.row, 0, ...newRows); return newGrid; });
    }
    insertRowBelow() {
        const selection = this.activeSelectionRange();
        if (!selection)
            return;
        this.recordHistory();
        const { end } = this.normalizeRange(selection);
        const modelCoords = this.visualToModelCoords(end);
        if (!modelCoords)
            return;
        const newRows = Array.from({ length: this.selectedRowCount() }, () => this._createNewRow());
        this.data().update(grid => { const newGrid = [...grid]; newGrid.splice(modelCoords.row + 1, 0, ...newRows); return newGrid; });
    }
    deleteRows() {
        const selection = this.activeSelectionRange();
        if (!selection)
            return;
        this.recordHistory();
        const modelRowsToDelete = new Set();
        const { start, end } = this.normalizeRange(selection);
        for (let r = start.row; r <= end.row; r++) {
            const modelCoords = this.visualToModelCoords({ row: r, col: 0 });
            if (modelCoords)
                modelRowsToDelete.add(modelCoords.row);
        }
        this.data().update(grid => grid.filter((_, i) => !modelRowsToDelete.has(i)));
        this.activeCell.set(null);
        this.selectionRanges.set([]);
    }
    insertColumnLeft() {
        const colIndex = this.contextMenuCoords().col;
        this.recordHistory();
        const newColName = this.getNewColumnName();
        this.data().update(grid => grid.map(row => { const newRow = [...row]; newRow.splice(colIndex, 0, { value: '' }); return newRow; }));
        this.columnConfig().update(c => { const newC = [...c]; newC.splice(colIndex, 0, { name: newColName, field: this._toKebabCase(newColName) }); return newC; });
    }
    insertColumnRight() {
        const colIndex = this.contextMenuCoords().col;
        this.recordHistory();
        const newColName = this.getNewColumnName();
        this.data().update(grid => grid.map(row => { const newRow = [...row]; newRow.splice(colIndex + 1, 0, { value: '' }); return newRow; }));
        this.columnConfig().update(c => { const newC = [...c]; newC.splice(colIndex + 1, 0, { name: newColName, field: this._toKebabCase(newColName) }); return newC; });
    }
    deleteColumn() {
        const selection = this.activeSelectionRange();
        if (!selection)
            return;
        this.recordHistory();
        const { start, end } = this.normalizeRange(selection);
        const count = end.col - start.col + 1;
        // Check for locked/read-only columns
        const config = this.columnConfig()();
        for (let c = start.col; c <= end.col; c++) {
            if (config[c]?.readOnly || config[c]?.lockSettings)
                return;
        }
        this.data().update(grid => grid.map(row => { const newRow = [...row]; newRow.splice(start.col, count); return newRow; }));
        this.columnConfig().update(c => { const newC = [...c]; newC.splice(start.col, count); return newC; });
        this.activeCell.set(null);
        this.selectionRanges.set([]);
    }
    copyTableData() {
        const headerRow = this.columnConfig()().map(c => ({ value: c.name }));
        const allRows = [headerRow, ...this.displayedRows().map(item => item.cells)];
        navigator.clipboard.writeText(this._convertDataToTSV(allRows));
    }
    async intelligentReplaceTableData() {
        try {
            const tsv = await navigator.clipboard.readText();
            const pastedGrid = this._parseTSV(tsv);
            if (pastedGrid.length > 0)
                this._performIntelligentReplace(pastedGrid);
        }
        catch (err) {
            console.error('Failed to read clipboard', err);
        }
    }
    pasteFromContextMenu() {
        const coords = this.getPasteStartCoords();
        if (coords)
            this._pasteFromClipboard(coords);
    }
    onCSVFileSelected(event) {
        const input = event.target;
        if (!input.files?.[0])
            return;
        const reader = new FileReader();
        reader.onload = e => {
            const data = this._parseCSV(e.target?.result);
            if (data.length > 0)
                this._performIntelligentReplace(data);
        };
        reader.readAsText(input.files[0]);
        input.value = '';
    }
    exportToCSV() {
        const headerRow = this.columnConfig()().map(c => ({ value: c.name }));
        const allRows = [headerRow, ...this.displayedRows().map(item => item.cells)];
        const csv = this._convertDataToCSV(allRows);
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement("a");
        const url = URL.createObjectURL(blob);
        link.href = url;
        link.download = "spreadsheet_export.csv";
        link.click();
        URL.revokeObjectURL(url);
    }
    // --- History Management ---
    recordHistory() { this.undoStack.update(s => [...s, this.data()()]); this.redoStack.set([]); }
    undo() {
        const lastState = this.undoStack().pop();
        if (!lastState)
            return;
        this.redoStack.update(s => [...s, this.data()()]);
        this.data().set(lastState);
        this.activeCell.set(null);
        this.selectionRanges.set([]);
    }
    redo() {
        const nextState = this.redoStack().pop();
        if (!nextState)
            return;
        this.undoStack.update(s => [...s, this.data()()]);
        this.data().set(nextState);
        this.activeCell.set(null);
        this.selectionRanges.set([]);
    }
    // --- Private Helpers ---
    scrollActiveDropdownOptionIntoView() {
        setTimeout(() => this.dropdownEditor()?.nativeElement.querySelector(`#dropdown-option-${this.dropdownActiveOptionIndex()}`)?.scrollIntoView({ block: 'nearest' }), 0);
    }
    reorderColumns() {
        const dragGroup = this.draggedColumnInfo();
        let dropIndex = this.dropColumnIndex();
        if (!dragGroup || dropIndex == null || (dropIndex > dragGroup.startIndex && (dropIndex -= dragGroup.count) === dragGroup.startIndex))
            return;
        this.recordHistory();
        const from = dragGroup.startIndex;
        const to = dropIndex;
        const N = this.colsCount();
        const newToOld = Array.from({ length: N }, (_, i) => i);
        const moved = newToOld.splice(from, dragGroup.count);
        newToOld.splice(to, 0, ...moved);
        const oldToNew = new Array(N);
        newToOld.forEach((oldIdx, newIdx) => oldToNew[oldIdx] = newIdx);
        this.data().update(grid => grid.map(row => newToOld.map(oldIdx => row[oldIdx])));
        this.columnConfig().update(c => newToOld.map(oldIdx => c[oldIdx] || { name: '', field: '' }));
        this.sortConfig.update(s => s ? { ...s, col: oldToNew[s.col] } : null);
        this.filterConfig.update(f => { const nf = new Map(); for (const [oc, v] of f.entries())
            nf.set(oldToNew[oc], v); return nf; });
        const update = (c) => ({ ...c, col: oldToNew[c.col] });
        this.selectionRanges.update(r => r.map(range => ({ start: update(range.start), end: update(range.end) })));
        this.activeCell.update(a => a ? update(a) : null);
        // Force layout update after DOM has settled to ensure selection outline is correct
        setTimeout(() => this.layoutTick.update(v => v + 1), 0);
    }
    _createNewRow() {
        return Array.from({ length: this.colsCount() }, (_, c) => {
            const colConfig = this.columnConfig()()[c];
            const newCell = { value: '' };
            if (colConfig) {
                if (colConfig.editor === 'checkbox')
                    newCell.value = false;
                else if (colConfig.editor === 'dropdown')
                    newCell.value = this.getOptionValue(colConfig.options?.[0] ?? '');
            }
            return newCell;
        });
    }
    getPasteStartCoords() {
        if (this.selectionRanges().length === 0)
            return this.activeCell() ? this.visualToModelCoords(this.activeCell()) : null;
        let topLeft = { row: Infinity, col: Infinity };
        this.selectionRanges().forEach(r => { const norm = this.normalizeRange(r); if (norm.start.row <= topLeft.row)
            topLeft = norm.start; });
        return this.visualToModelCoords(topLeft);
    }
    getNewColumnName() {
        const headers = new Set(this.columnConfig()().map(c => c.name));
        for (let i = 0; i < 26; i++) {
            const name = `Attribute ${String.fromCharCode(65 + i)}`;
            if (!headers.has(name))
                return name;
        }
        let i = 1;
        while (headers.has(`Attribute ${i}`))
            i++;
        return `Attribute ${i}`;
    }
    toggleCheckbox(r, c) { const cell = this.getCell(r, c); const colConfig = this.columnConfig()()[c]; if (!cell || colConfig?.editor !== 'checkbox' || cell.readOnly)
        return; this.recordHistory(); this.data().update(g => { const ng = g.map(row => [...row]); ng[r][c] = { ...ng[r][c], value: !this.isCheckboxChecked(r, c) }; return ng; }); }
    validateData(grid) {
        const errors = new Map();
        grid.forEach((row, r) => {
            row.forEach((cell, c) => {
                const colConfig = this.columnConfig()()[c];
                if (colConfig?.editor === 'dropdown' && colConfig.options?.length && !colConfig.options.map(o => this.getOptionValue(o)).includes(String(cell.value))) {
                    errors.set(`${r}-${c}`, `Invalid value. Please choose from the available options.`);
                }
                else if (colConfig?.editor === 'numeric' && cell.value != '' && cell.value != null && (typeof cell.value !== 'number' || !isFinite(cell.value))) {
                    errors.set(`${r}-${c}`, `Value must be a number.`);
                }
            });
        });
        this.validationErrors.set(errors);
    }
    async _copySelectionToClipboard() {
        const range = this.activeSelectionRange();
        if (!range)
            return;
        const norm = this.normalizeRange(range);
        const selectedData = this.displayedRows().slice(norm.start.row, norm.end.row + 1).map(item => item.cells.slice(norm.start.col, norm.end.col + 1));
        await navigator.clipboard.writeText(this._convertDataToTSV(selectedData));
    }
    _convertPastedValue(value, colConfig) {
        if (!colConfig)
            return value;
        switch (colConfig.editor) {
            case 'numeric':
                const trimmedValue = value.trim();
                if (trimmedValue === '')
                    return ''; // Allow clearing cell
                const cleanedValue = trimmedValue.replace(/[\$,]/g, '');
                const parsed = parseFloat(cleanedValue);
                return !isNaN(parsed) && isFinite(parsed) ? parsed : value; // Return original string if not a valid number
            case 'checkbox':
                const lowerValue = value.toLowerCase().trim();
                return lowerValue === 'true' || lowerValue === '1';
            default:
                return value;
        }
    }
    async _pasteFromClipboard(startModelCoords) {
        const pastedRows = this._parseTSV(await navigator.clipboard.readText());
        if (pastedRows.length === 0)
            return;
        this.recordHistory();
        if (pastedRows.length === 1 && pastedRows[0].length === 1 && (this.selectionRanges().length > 1 || this.selectedColCount() > 1 || this.selectedRowCount() > 1)) {
            const value = pastedRows[0][0];
            this.data().update(grid => {
                const newGrid = grid.map(r => [...r]);
                this.selectionRanges().forEach(range => {
                    const norm = this.normalizeRange(range);
                    for (let r = norm.start.row; r <= norm.end.row; r++) {
                        for (let c = norm.start.col; c <= norm.end.col; c++) {
                            const model = this.visualToModelCoords({ row: r, col: c });
                            if (!model)
                                continue;
                            const colConfig = this.columnConfig()()[model.col];
                            const target = newGrid[model.row]?.[model.col];
                            if (target && !target.readOnly) {
                                newGrid[model.row][model.col] = { ...target, value: this._convertPastedValue(value, colConfig) };
                            }
                        }
                    }
                });
                return newGrid;
            });
        }
        else {
            const startVisual = this.modelToVisualCoords(startModelCoords);
            if (!startVisual)
                return;
            const sel = this.activeSelectionRange() ?? { start: startVisual, end: startVisual };
            const normSel = this.normalizeRange(sel);
            const selRows = normSel.end.row - normSel.start.row + 1;
            const selCols = normSel.end.col - normSel.start.col + 1;
            const effRows = Math.max(selRows, pastedRows.length), effCols = Math.max(selCols, pastedRows[0].length);
            this.data().update(grid => {
                const newGrid = grid.map(r => [...r]);
                for (let rOff = 0; rOff < effRows; rOff++) {
                    for (let cOff = 0; cOff < effCols; cOff++) {
                        const targetVisualCoords = { row: startVisual.row + rOff, col: startVisual.col + cOff };
                        if (targetVisualCoords.col >= this.colsCount())
                            continue;
                        const modelCoords = this.visualToModelCoords(targetVisualCoords);
                        if (!modelCoords)
                            continue;
                        const target = newGrid[modelCoords.row]?.[modelCoords.col];
                        if (target && !target.readOnly) {
                            const value = pastedRows[rOff % pastedRows.length][cOff % pastedRows[0].length];
                            const colConfig = this.columnConfig()()[modelCoords.col];
                            newGrid[modelCoords.row][modelCoords.col] = { ...target, value: this._convertPastedValue(value, colConfig) };
                        }
                    }
                }
                return newGrid;
            });
        }
    }
    _parseTSV(tsv) { return this._parseDelimitedData(tsv, '\t'); }
    _parseCSV(csv) { return this._parseDelimitedData(csv, ','); }
    _parseDelimitedData(input, delimiter) {
        const rows = [];
        let currentRow = [];
        let currentCell = '';
        let inQuotes = false;
        for (let i = 0; i < input.length; i++) {
            const char = input[i];
            const nextChar = input[i + 1];
            if (inQuotes) {
                if (char === '"') {
                    if (nextChar === '"') {
                        // Escaped quote: "" -> "
                        currentCell += '"';
                        i++;
                    }
                    else {
                        // End of quoted cell
                        inQuotes = false;
                    }
                }
                else {
                    // Regular character inside quotes (including delimiters and newlines)
                    currentCell += char;
                }
            }
            else {
                if (char === '"') {
                    // Start of quoted cell
                    inQuotes = true;
                }
                else if (char === delimiter) {
                    // Cell delimiter
                    currentRow.push(currentCell);
                    currentCell = '';
                }
                else if (char === '\n' || (char === '\r' && nextChar === '\n')) {
                    // Row ending (\n or \r\n)
                    currentRow.push(currentCell);
                    rows.push(currentRow);
                    currentRow = [];
                    currentCell = '';
                    if (char === '\r')
                        i++; // skip \n
                }
                else if (char === '\r') {
                    // Row ending (\r only)
                    currentRow.push(currentCell);
                    rows.push(currentRow);
                    currentRow = [];
                    currentCell = '';
                }
                else {
                    // Regular character
                    currentCell += char;
                }
            }
        }
        // Handle last cell/row if not already handled
        if (currentRow.length > 0 || currentCell !== '') {
            currentRow.push(currentCell);
            rows.push(currentRow);
        }
        return rows;
    }
    moveActiveCell(rd, cd, extend) {
        const a = this.activeCell();
        if (!a)
            return;
        const nc = {
            row: Math.max(0, Math.min(this.displayedRows().length - 1, a.row + rd)),
            col: Math.max(0, Math.min(this.colsCount() - 1, a.col + cd))
        };
        this.activeCell.set(nc);
        if (extend && this.selectionRanges().length > 0) {
            this.selectionRanges.update(r => [...r.slice(0, -1), { start: r[r.length - 1].start, end: nc }]);
        }
        else {
            this.selectionRanges.set([{ start: nc, end: nc }]);
        }
        const mc = this.visualToModelCoords(nc);
        if (mc) {
            this.scrollCellIntoView(mc, nc);
        }
    }
    scrollCellIntoView(modelCoords, visualCoords) {
        const container = this.spreadsheetContainer()?.nativeElement;
        if (!container)
            return;
        // Query for the table cell and the sticky headers
        const cellEl = container.querySelector(`[data-row="${modelCoords.row}"][data-col="${modelCoords.col}"]`);
        const headerEl = container.querySelector('thead');
        // Query for the first row header in the table body to get its width
        const rowHeaderEl = container.querySelector('tbody th.sticky');
        if (!cellEl || !headerEl)
            return;
        const headerHeight = headerEl.offsetHeight;
        // Use a fallback width if the sticky row header isn't found (e.g., table not rendered yet)
        const rowHeaderWidth = rowHeaderEl ? rowHeaderEl.offsetWidth : 0;
        // Cell position relative to the scrollable table content
        const cellTop = cellEl.offsetTop;
        const cellBottom = cellTop + cellEl.offsetHeight;
        const cellLeft = cellEl.offsetLeft;
        const cellRight = cellLeft + cellEl.offsetWidth;
        // Container's current scroll state and dimensions
        const containerScrollTop = container.scrollTop;
        const containerVisibleHeight = container.clientHeight;
        const containerScrollLeft = container.scrollLeft;
        const containerVisibleWidth = container.clientWidth;
        // --- Vertical Scroll Adjustment ---
        // Check if the cell is obscured by the sticky header or is above the current viewport
        if (cellTop < containerScrollTop + headerHeight) {
            container.scrollTop = cellTop - headerHeight;
        }
        // Check if the cell is below the current viewport
        else if (cellBottom > containerScrollTop + containerVisibleHeight) {
            container.scrollTop = cellBottom - containerVisibleHeight;
        }
        // --- Horizontal Scroll Adjustment ---
        // Check if the cell is obscured by the sticky column or is to the left of the current viewport
        if (cellLeft < containerScrollLeft + rowHeaderWidth) {
            container.scrollLeft = cellLeft - rowHeaderWidth;
        }
        // Check if the cell is to the right of the current viewport
        else if (cellRight > containerScrollLeft + containerVisibleWidth) {
            container.scrollLeft = cellRight - containerVisibleWidth;
        }
        // --- Edge Case Snapping ---
        // When navigating to the very first column or row, ensure scrollbars are reset to the origin.
        // This provides a better user experience by fully revealing the headers.
        if (visualCoords.col === 0) {
            container.scrollLeft = 0;
        }
        if (visualCoords.row === 0) {
            container.scrollTop = 0;
        }
    }
    clearSelectedCells() {
        if (this.selectionRanges().length === 0)
            return;
        this.recordHistory();
        this.data().update(grid => {
            const newGrid = grid.map(r => [...r]);
            this.selectionRanges().forEach(range => {
                const norm = this.normalizeRange(range);
                for (let r = norm.start.row; r <= norm.end.row; r++) {
                    for (let c = norm.start.col; c <= norm.end.col; c++) {
                        const model = this.visualToModelCoords({ row: r, col: c });
                        const colConfig = this.columnConfig()()[c];
                        if (model && newGrid[model.row][model.col] && !newGrid[model.row][model.col].readOnly) {
                            newGrid[model.row][model.col] = {
                                ...newGrid[model.row][model.col],
                                value: colConfig?.editor === 'checkbox' ? false : ''
                            };
                        }
                    }
                }
            });
            return newGrid;
        });
    }
    applyFill(fill) {
        const sel = this.activeSelectionRange();
        if (!fill || !sel)
            return;
        this.recordHistory();
        const normSel = this.normalizeRange(sel);
        const normFill = this.normalizeRange(fill);
        this.data().update(grid => {
            const newGrid = grid.map(r => [...r]);
            const sRows = normSel.end.row - normSel.start.row + 1;
            const sCols = normSel.end.col - normSel.start.col + 1;
            for (let r = normSel.start.row; r <= normFill.end.row; r++) {
                for (let c = normSel.start.col; c <= normFill.end.col; c++) {
                    if (r > normSel.end.row || c > normSel.end.col) {
                        const sVisRow = normSel.start.row + ((r - normSel.start.row) % sRows);
                        const sVisCol = normSel.start.col + ((c - normSel.start.col) % sCols);
                        const sMod = this.visualToModelCoords({ row: sVisRow, col: sVisCol });
                        const tMod = this.visualToModelCoords({ row: r, col: c });
                        if (sMod && tMod && newGrid[tMod.row]?.[c] && !newGrid[tMod.row][c].readOnly) {
                            newGrid[tMod.row][c] = {
                                ...newGrid[tMod.row][c],
                                value: grid[sMod.row][sMod.col].value
                            };
                        }
                    }
                }
            }
            return newGrid;
        });
        this.selectionRanges.set([fill]);
    }
    _performIntelligentReplace(pastedGrid) {
        if (!pastedGrid || pastedGrid.length <= 1)
            return;
        this.recordHistory();
        const headers = pastedGrid[0];
        const dataRows = pastedGrid.slice(1);
        const currentConfig = this.columnConfig()();
        const newConfig = [];
        const protectedColumns = [];
        const usedNames = new Set(currentConfig.map(c => c.name));
        // Helper to generate a unique name
        const getUniqueNewName = () => {
            for (let i = 0; i < 26; i++) {
                const name = `Attribute ${String.fromCharCode(65 + i)}`;
                if (!usedNames.has(name)) {
                    usedNames.add(name);
                    return name;
                }
            }
            let i = 1;
            while (usedNames.has(`Attribute ${i}`))
                i++;
            const name = `Attribute ${i}`;
            usedNames.add(name);
            return name;
        };
        // 1. Process incoming headers to build new config
        headers.forEach((headerName, incomingColIndex) => {
            const trimmedHeader = headerName.trim();
            const existingCol = currentConfig.find(c => c.name.trim() === trimmedHeader);
            if (existingCol) {
                newConfig.push(existingCol);
                usedNames.add(existingCol.name);
            }
            else {
                const inferredType = this._inferColumnType(dataRows, incomingColIndex);
                let newName = trimmedHeader;
                if (!newName) {
                    newName = getUniqueNewName();
                }
                else if (usedNames.has(newName)) {
                    // resolve name collision by appending a number if user provides duplicate columns
                    let dupIndex = 1;
                    while (usedNames.has(`${newName} (${dupIndex})`))
                        dupIndex++;
                    newName = `${newName} (${dupIndex})`;
                }
                usedNames.add(newName);
                newConfig.push({
                    name: newName,
                    field: this._toKebabCase(newName),
                    editor: inferredType !== 'text' ? inferredType : undefined
                });
            }
        });
        // 2. Add remaining protected columns that weren't in pasted data
        currentConfig.forEach(col => {
            const isInNewConfig = newConfig.some(c => c.name === col.name);
            if (!isInNewConfig && (col.lockSettings || col.readOnly)) {
                protectedColumns.push(col);
            }
        });
        const finalConfig = [...newConfig, ...protectedColumns];
        // 3. Build new data grid
        const newGrid = [];
        dataRows.forEach((row, rowIndex) => {
            const newCellRow = [];
            // Fill pasted columns
            newConfig.forEach((colConfig, configIndex) => {
                const stringValue = row[configIndex] ?? '';
                let existingOriginalCell;
                const existingColIndex = currentConfig.findIndex(c => c.name === colConfig.name);
                if (existingColIndex !== -1 && rowIndex < this.data()().length) {
                    existingOriginalCell = this.data()()[rowIndex][existingColIndex];
                }
                const value = this._convertPastedValue(stringValue, colConfig);
                const cell = existingOriginalCell ? { ...existingOriginalCell, value } : { value };
                newCellRow.push(cell);
            });
            // Fill protected columns
            protectedColumns.forEach(colConfig => {
                const existingColIndex = currentConfig.findIndex(c => c.name === colConfig.name);
                if (existingColIndex !== -1 && rowIndex < this.data()().length) {
                    const existingCell = this.data()()[rowIndex][existingColIndex];
                    newCellRow.push({ ...existingCell });
                }
                else {
                    let value = '';
                    if (colConfig.editor === 'checkbox')
                        value = false;
                    else if (colConfig.editor === 'dropdown')
                        value = this.getOptionValue(colConfig.options?.[0] ?? '');
                    newCellRow.push({ value });
                }
            });
            newGrid.push(newCellRow);
        });
        this.columnConfig().set(finalConfig);
        this.data().set(newGrid);
        this.activeCell.set(null);
        this.selectionRanges.set([]);
    }
    _inferColumnType(data, colIndex) {
        let allCheckboxes = true;
        let allNumbers = true;
        let hasData = false;
        for (const row of data) {
            const val = (row[colIndex] ?? '').trim();
            if (!val)
                continue;
            hasData = true;
            const lowerVal = val.toLowerCase();
            if (!['true', 'false', '1', '0'].includes(lowerVal)) {
                allCheckboxes = false;
            }
            const numClean = val.replace(/[\$,]/g, '');
            const parsedNum = parseFloat(numClean);
            if (isNaN(parsedNum) || !isFinite(parsedNum)) {
                allNumbers = false;
            }
        }
        if (!hasData)
            return 'text';
        if (allCheckboxes)
            return 'checkbox';
        if (allNumbers)
            return 'numeric';
        return 'text';
    }
    static { this.ɵfac = function SpreadsheetComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || SpreadsheetComponent)(); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: SpreadsheetComponent, selectors: [["long-spreadsheet"]], viewQuery: function SpreadsheetComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuerySignal(ctx.rootContainer, _c0, 5)(ctx.spreadsheetContainer, _c1, 5)(ctx.spreadsheetTable, _c2, 5)(ctx.editingInput, _c3, 5)(ctx.dropdownEditor, _c4, 5)(ctx.dropdownSearchInput, _c5, 5)(ctx.contextMenuEl, _c6, 5)(ctx.filterPopupEl, _c7, 5)(ctx.findReplacePanelEl, _c8, 5)(ctx.csvImporter, _c9, 5)(ctx.validationTooltip, _c10, 5)(ctx.headerTooltip, _c11, 5);
        } if (rf & 2) {
            i0.ɵɵqueryAdvance(12);
        } }, hostVars: 4, hostBindings: function SpreadsheetComponent_HostBindings(rf, ctx) { if (rf & 1) {
            i0.ɵɵlistener("mousedown", function SpreadsheetComponent_mousedown_HostBindingHandler($event) { return ctx.onHostMouseDown($event); })("copy", function SpreadsheetComponent_copy_HostBindingHandler($event) { return ctx.onCopy($event); })("paste", function SpreadsheetComponent_paste_HostBindingHandler($event) { return ctx.onPaste($event); })("keydown", function SpreadsheetComponent_keydown_HostBindingHandler($event) { return ctx.onKeyDown($event); })("mousedown", function SpreadsheetComponent_mousedown_HostBindingHandler($event) { return ctx.onDocumentMouseDown($event); }, i0.ɵɵresolveDocument)("mousemove", function SpreadsheetComponent_mousemove_HostBindingHandler($event) { return ctx.onDocumentMouseMove($event); }, i0.ɵɵresolveDocument)("mouseup", function SpreadsheetComponent_mouseup_HostBindingHandler($event) { return ctx.onDocumentMouseUp($event); }, i0.ɵɵresolveDocument);
        } if (rf & 2) {
            i0.ɵɵstyleMap(ctx.themeCssVariables());
            i0.ɵɵstyleProp("height", ctx.isFullHeight() ? "100%" : null);
        } }, inputs: { data: [1, "data"], columnConfig: [1, "columnConfig"], theme: [1, "theme"], showLoading: [1, "showLoading"], height: [1, "height"] }, outputs: { onDataChange: "onDataChange", onColumnChange: "onColumnChange" }, decls: 38, vars: 41, consts: [["rootContainer", ""], ["csvImporter", ""], ["spreadsheetContainer", ""], ["spreadsheetTable", ""], ["filterPopupEl", ""], ["findReplacePanelEl", ""], ["contextMenuEl", ""], ["dropdownEditor", ""], ["dropdownSearchInput", ""], ["editingInput", ""], ["validationTooltip", ""], ["headerTooltip", ""], [1, "longtable-scope", 2, "width", "100%", "height", "100%"], [1, "relative", "long-spreadsheet-root"], ["type", "file", "accept", ".csv", 2, "display", "none", 3, "change"], ["tabindex", "0", 1, "long-spreadsheet-container"], [1, "table-fixed", "border-separate", "border-spacing-0", "leading-[12px]", "relative", "long-spreadsheet-table", 2, "width", "-webkit-fill-available", "font-size", "var(--lt-font-table-cell, 12px)"], [2, "width", "3rem"], [1, "sticky", "top-0", "z-40", "shadow-sm", "bg-[var(--lt-bg-header,theme(colors.slate.100))]", "long-spreadsheet-header-row"], [1, "sticky", "left-0", "w-12", "min-w-[3rem]", "text-center", "align-middle", "border-r", "border-b", "z-50", "cursor-pointer", "text-[var(--lt-icon-default,theme(colors.slate.400))]", "bg-[var(--lt-bg-header,theme(colors.slate.100))]", "border-b-[var(--lt-border-default,theme(colors.slate.200))]", "border-r-[var(--lt-border-default,theme(colors.slate.200))]", "hover:bg-[var(--lt-bg-header-hover,theme(colors.slate.200))]", "long-spreadsheet-header-corner", 2, "display", "table-cell", "padding", "7px 10px", 3, "click", "contextmenu"], [1, "pi", "pi-spinner-dotted", "pi-spin"], [1, "pi", "pi-table"], [1, "group", "relative", "border-r", "border-b", "font-semibold", "cursor-grab", "bg-[var(--lt-bg-header,theme(colors.slate.100))]", "border-b-[var(--lt-border-default,theme(colors.slate.200))]", "border-r-[var(--lt-border-default,theme(colors.slate.200))]", "text-[var(--lt-text-header,theme(colors.gray.600))]", "hover:bg-[var(--lt-bg-header-hover,theme(colors.slate.200))]", "long-spreadsheet-header-cell", 2, "padding", "7px 10px", 3, "opacity-50"], [1, "long-spreadsheet-row"], [1, "absolute", "pointer-events-none", "z-20", "shadow-[inset_0_0_0_2px]", "shadow-[var(--lt-selection-shadow,theme(colors.blue.600))]", 3, "style"], [1, "absolute", "pointer-events-none", "z-10", "border", "border-dashed", "border-gray-600", "bg-gray-400/10", "dark:border-slate-400", "dark:bg-slate-500/20", 3, "style"], [1, "absolute", "w-0.5", "z-[60]", "pointer-events-none", "bg-[var(--lt-drop-indicator,theme(colors.blue.500))]", 3, "style"], [1, "long-spreadsheet-filter-popup-container"], [3, "isVisible", "position", "uniqueValues", "initialSelection"], [1, "longtable-scope", 3, "findQueryChange", "findOptionsChange", "navigateNext", "navigatePrev", "replaceOne", "replaceAll", "close", "isVisible", "container", "resultsCount", "currentIndex", "theme"], [3, "close", "save", "isVisible", "columnIndex", "allRows", "columnConfig"], [3, "close", "isVisible", "rows", "columnConfig", "useCountColumn", "graphs", "theme"], [1, "absolute", "w-max", "max-w-xs", "bg-red-600", "text-white", "text-sm", "rounded-md", "shadow-lg", "p-2", "z-[110]", "pointer-events-none", "leading-tight", 3, "font-family", "left", "top"], [1, "long-spreadsheet-context-menu", "longtable-scope", 3, "menuAction", "isVisible", "position", "type", "data", "appendTo", "theme"], [1, "absolute", "w-max", "max-w-xs", "text-sm", "rounded-md", "shadow-lg", "p-2.5", "z-[110]", "pointer-events-none", "leading-tight", 3, "background-color", "color", "font-family", "left", "top"], [3, "width"], [1, "group", "relative", "border-r", "border-b", "font-semibold", "cursor-grab", "bg-[var(--lt-bg-header,theme(colors.slate.100))]", "border-b-[var(--lt-border-default,theme(colors.slate.200))]", "border-r-[var(--lt-border-default,theme(colors.slate.200))]", "text-[var(--lt-text-header,theme(colors.gray.600))]", "hover:bg-[var(--lt-bg-header-hover,theme(colors.slate.200))]", "long-spreadsheet-header-cell", 2, "padding", "7px 10px", 3, "contextmenu", "dblclick", "mouseenter", "mouseleave"], [1, "flex", "items-center", "justify-between", "gap-2"], [1, "truncate"], [1, "flex", "items-center", "text-[var(--lt-icon-default,theme(colors.slate.400))]"], [1, "p-1", "rounded-full", "cursor-pointer", "hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.400))]", "hover:text-[var(--lt-icon-hover-text,theme(colors.slate.800))]", 3, "click"], [3, "class"], [1, "pi", "pi-sort-alt", "opacity-0", "group-hover:opacity-100", "transition-opacity"], [1, "filter-toggle-btn", "p-1", "ml-1", "rounded-full", "cursor-pointer", "hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.400))]", "hover:text-[var(--lt-icon-hover-text,theme(colors.slate.800))]", 3, "click"], [1, "pi", "pi-filter-fill", "text-[var(--lt-icon-active,theme(colors.blue.600))]"], [1, "pi", "pi-filter", "opacity-0", "group-hover:opacity-100", "transition-opacity"], [1, "col-resize-handle", "absolute", "top-0", "right-0", "h-full", "w-2", "cursor-col-resize", "z-10", 3, "mousedown"], [1, "sticky", "left-0", "w-12", "min-w-[3rem]", "border-r", "border-b", "font-semibold", "z-30", "align-top", "cursor-pointer", "bg-[var(--lt-bg-header,theme(colors.slate.100))]", "border-b-[var(--lt-border-default,theme(colors.slate.200))]", "border-r-[var(--lt-border-default,theme(colors.slate.200))]", "text-[var(--lt-text-header,theme(colors.gray.600))]", "hover:bg-[var(--lt-bg-header-hover,theme(colors.slate.200))]", "long-spreadsheet-row-header-cell", 2, "padding", "7px 10px", 3, "contextmenu"], [2, "padding", "7px 10px", 3, "class"], [2, "padding", "7px 10px", 3, "dblclick", "contextmenu", "mouseenter", "mouseleave"], [1, "absolute", "top-0", "right-0", "w-0", "h-0", "border-solid", "z-20", "border-b-[4px]", "border-l-[4px]", "border-t-[4px]", "border-r-[4px]", "border-b-transparent", "border-l-transparent", "border-t-[#ff0000]", "border-r-[#ff0000]"], [1, "flex", "items-center", "justify-center", "w-full", "h-full"], [1, "flex", "items-center", "w-full", "min-w-0", "break-words"], [1, "fill-handle", "absolute", "-right-1.5", "-bottom-1.5", "w-3", "h-3", "cursor-crosshair", "z-[70]", "bg-[var(--lt-fill-handle,theme(colors.blue.600))]", "border", "border-[var(--lt-fill-handle-border,white)]"], [1, "absolute", "top-0", "right-0", "w-0", "h-0", "border-solid", "z-20", "border-b-[4px]", "border-l-[4px]", "border-t-[4px]", "border-r-[4px]", "border-b-transparent", "border-l-transparent", "border-t-[#ff0000]", "border-r-[#ff0000]", 3, "mouseenter"], [1, "flex", "items-center", "justify-center", "w-full", "h-full", 3, "dblclick"], ["type", "checkbox", 1, "w-4", "h-4", "rounded", "cursor-pointer", "bg-[var(--lt-checkbox-bg,white)]", "border", "border-[var(--lt-checkbox-border,theme(colors.slate.300))]", "focus:ring-2", "focus:ring-offset-2", "focus:ring-[var(--lt-icon-active,theme(colors.blue.600))]", "focus:ring-offset-[var(--lt-bg-primary,white)]", "accent-[var(--lt-icon-active,theme(colors.blue.600))]", 3, "change", "mousedown", "checked", "disabled"], [3, "innerHTML"], [1, "h-2", "w-2", "rounded-full", "mr-2", "flex-shrink-0", 3, "backgroundColor"], [1, "h-2", "w-2", "rounded-full", "mr-2", "flex-shrink-0"], [1, "fill-handle", "absolute", "-right-1.5", "-bottom-1.5", "w-3", "h-3", "cursor-crosshair", "z-[70]", "bg-[var(--lt-fill-handle,theme(colors.blue.600))]", "border", "border-[var(--lt-fill-handle-border,white)]", 3, "dblclick"], [1, "absolute", "z-[70]", "flex", "flex-col", "rounded-md", "shadow-lg", "border-2", "border-[var(--lt-border-editing,theme(colors.blue.600))]", "long-spreadsheet-floating-editor", 3, "top", "left", "width", "background"], [1, "absolute", "z-[70]", "box-border", "border-2", "bg-[var(--lt-input-bg,white)]", "border-[var(--lt-border-editing,theme(colors.blue.600))]", "long-spreadsheet-floating-editor", 3, "top", "left", "width", "height", "padding"], [1, "absolute", "z-[70]", "flex", "flex-col", "rounded-md", "shadow-lg", "border-2", "border-[var(--lt-border-editing,theme(colors.blue.600))]", "long-spreadsheet-floating-editor", 3, "mousedown"], [1, "p-2", "border-b", "border-[var(--lt-border-default,theme(colors.slate.200))]"], ["type", "text", "placeholder", "Filter options...", 1, "w-full", "px-2", "py-1", "bg-[var(--lt-input-bg,white)]", "border", "border-[var(--lt-border-default,theme(colors.slate.300))]", "rounded-md", "shadow-sm", "focus:outline-none", "focus:border-[var(--lt-border-editing,theme(colors.blue.500))]", "focus:ring-1", "focus:ring-[var(--lt-border-editing,theme(colors.blue.500))]", "text-[var(--lt-text-primary,inherit)]", 3, "ngModelChange", "keydown", "ngModel"], [1, "flex-grow", "overflow-y-auto", "max-h-48", "p-1", "modal-scroll-content"], [3, "id", "fontSize", "font-family", "class"], [1, "p-1"], [1, "w-full", "text-left", "px-2", "py-1.5", "text-sm", "text-[var(--lt-icon-active,theme(colors.blue.600))]", "hover:bg-[var(--lt-icon-hover-bg,theme(colors.gray.100))]", "flex", "items-center", "gap-2", "rounded-md", 3, "click"], [1, "pi", "pi-pencil", "text-xs"], [3, "click", "id"], [1, "flex", "items-center", "truncate"], [1, "pi", "pi-check", "text-xs", "ml-2", "flex-shrink-0"], [1, "absolute", "z-[70]", "box-border", "border-2", "bg-[var(--lt-input-bg,white)]", "border-[var(--lt-border-editing,theme(colors.blue.600))]", "long-spreadsheet-floating-editor"], [1, "w-full", "h-full", "block", "bg-transparent", "select-text", "resize-none", "outline-none", "box-border", "!p-0", "!border-0", "leading-[12px]", "text-[var(--lt-text-primary,inherit)]", 3, "ngModelChange", "blur", "keydown", "input", "ngModel"], [1, "absolute", "pointer-events-none", "z-20", "shadow-[inset_0_0_0_2px]", "shadow-[var(--lt-selection-shadow,theme(colors.blue.600))]"], [1, "absolute", "pointer-events-none", "z-10", "border", "border-dashed", "border-gray-600", "bg-gray-400/10", "dark:border-slate-400", "dark:bg-slate-500/20"], [1, "absolute", "w-0.5", "z-[60]", "pointer-events-none", "bg-[var(--lt-drop-indicator,theme(colors.blue.500))]"], [3, "apply", "clear", "close", "isVisible", "position", "uniqueValues", "initialSelection"], [1, "absolute", "w-max", "max-w-xs", "bg-red-600", "text-white", "text-sm", "rounded-md", "shadow-lg", "p-2", "z-[110]", "pointer-events-none", "leading-tight"], [1, "absolute", "w-max", "max-w-xs", "text-sm", "rounded-md", "shadow-lg", "p-2.5", "z-[110]", "pointer-events-none", "leading-tight"], [1, "font-bold", "mb-1"], [1, "mb-1", "text-slate-300", "italic"], [1, "border-t", "border-slate-600", "my-1"], [1, "text-slate-400"], [1, "font-semibold", "text-slate-200"]], template: function SpreadsheetComponent_Template(rf, ctx) { if (rf & 1) {
            const _r1 = i0.ɵɵgetCurrentView();
            i0.ɵɵelementStart(0, "div", 12)(1, "div", 13, 0)(3, "input", 14, 1);
            i0.ɵɵlistener("change", function SpreadsheetComponent_Template_input_change_3_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onCSVFileSelected($event)); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "div", 15, 2)(7, "table", 16, 3)(9, "colgroup");
            i0.ɵɵelement(10, "col", 17);
            i0.ɵɵconditionalCreate(11, SpreadsheetComponent_Conditional_11_Template, 2, 0);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(12, "thead", 18)(13, "tr")(14, "th", 19);
            i0.ɵɵlistener("click", function SpreadsheetComponent_Template_th_click_14_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.selectAllCells()); })("contextmenu", function SpreadsheetComponent_Template_th_contextmenu_14_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onHeaderCornerContextMenu($event)); });
            i0.ɵɵconditionalCreate(15, SpreadsheetComponent_Conditional_15_Template, 1, 0, "i", 20)(16, SpreadsheetComponent_Conditional_16_Template, 1, 0, "i", 21);
            i0.ɵɵelementEnd();
            i0.ɵɵrepeaterCreate(17, SpreadsheetComponent_For_18_Template, 12, 6, "th", 22, i0.ɵɵrepeaterTrackByIndex);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(19, "tbody");
            i0.ɵɵrepeaterCreate(20, SpreadsheetComponent_For_21_Template, 5, 2, "tr", 23, _forTrack0);
            i0.ɵɵelementEnd()();
            i0.ɵɵconditionalCreate(22, SpreadsheetComponent_Conditional_22_Template, 1, 1);
            i0.ɵɵrepeaterCreate(23, SpreadsheetComponent_For_24_Template, 1, 2, "div", 24, i0.ɵɵrepeaterTrackByIndex);
            i0.ɵɵconditionalCreate(25, SpreadsheetComponent_Conditional_25_Template, 1, 2, "div", 25);
            i0.ɵɵconditionalCreate(26, SpreadsheetComponent_Conditional_26_Template, 1, 2, "div", 26);
            i0.ɵɵelementStart(27, "div", 27, 4);
            i0.ɵɵconditionalCreate(29, SpreadsheetComponent_Conditional_29_Template, 1, 4, "long-filter-popup", 28);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(30, "long-find-replace", 29, 5);
            i0.ɵɵlistener("findQueryChange", function SpreadsheetComponent_Template_long_find_replace_findQueryChange_30_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onFindQueryChange($event)); })("findOptionsChange", function SpreadsheetComponent_Template_long_find_replace_findOptionsChange_30_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.onFindOptionsChange($event)); })("navigateNext", function SpreadsheetComponent_Template_long_find_replace_navigateNext_30_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.navigateToNextMatch()); })("navigatePrev", function SpreadsheetComponent_Template_long_find_replace_navigatePrev_30_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.navigateToPrevMatch()); })("replaceOne", function SpreadsheetComponent_Template_long_find_replace_replaceOne_30_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.replaceCurrentMatch($event)); })("replaceAll", function SpreadsheetComponent_Template_long_find_replace_replaceAll_30_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.replaceAllMatches($event)); })("close", function SpreadsheetComponent_Template_long_find_replace_close_30_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.closeFindReplace()); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(32, "long-column-editor", 30);
            i0.ɵɵlistener("close", function SpreadsheetComponent_Template_long_column_editor_close_32_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.isColumnSettingsVisible.set(false)); })("save", function SpreadsheetComponent_Template_long_column_editor_save_32_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.handleSaveColumnSettings($event)); });
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(33, "long-table-stats", 31);
            i0.ɵɵlistener("close", function SpreadsheetComponent_Template_long_table_stats_close_33_listener() { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.isStatsModalVisible.set(false)); });
            i0.ɵɵelementEnd();
            i0.ɵɵconditionalCreate(34, SpreadsheetComponent_Conditional_34_Template, 3, 7, "div", 32);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(35, "long-context-menu", 33, 6);
            i0.ɵɵlistener("menuAction", function SpreadsheetComponent_Template_long_context_menu_menuAction_35_listener($event) { i0.ɵɵrestoreView(_r1); return i0.ɵɵresetView(ctx.handleContextMenuAction($event)); });
            i0.ɵɵelementEnd();
            i0.ɵɵconditionalCreate(37, SpreadsheetComponent_Conditional_37_Template, 14, 14, "div", 34);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            let tmp_17_0;
            let tmp_21_0;
            let tmp_44_0;
            const spreadsheetContainer_r29 = i0.ɵɵreference(6);
            i0.ɵɵadvance();
            i0.ɵɵstyleProp("font-family", "var(--lt-font-family-main, sans-serif)")("height", ctx.isFullHeight() ? "100%" : null);
            i0.ɵɵadvance(4);
            i0.ɵɵclassMap(ctx.spreadsheetContainerClasses());
            i0.ɵɵstyleProp("background", "var(--lt-bg-primary, white)")("height", ctx.containerHeight());
            i0.ɵɵadvance(2);
            i0.ɵɵstyleProp("font-family", "var(--lt-font-family-mono, monospace)");
            i0.ɵɵadvance(4);
            i0.ɵɵconditional(ctx.columnConfig()().length > 0 ? 11 : -1);
            i0.ɵɵadvance(4);
            i0.ɵɵconditional(ctx.showLoading() ? 15 : 16);
            i0.ɵɵadvance(2);
            i0.ɵɵrepeater(ctx.columnConfig()());
            i0.ɵɵadvance(3);
            i0.ɵɵrepeater(ctx.displayedRows());
            i0.ɵɵadvance(2);
            i0.ɵɵconditional((tmp_17_0 = ctx.editingCell()) ? 22 : -1, tmp_17_0);
            i0.ɵɵadvance();
            i0.ɵɵrepeater(ctx.selectionRangePositions());
            i0.ɵɵadvance(2);
            i0.ɵɵconditional(ctx.fillRange() && ctx.selectionRanges().length > 0 ? 25 : -1);
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.isDraggingColumn() ? 26 : -1);
            i0.ɵɵadvance(3);
            i0.ɵɵconditional((tmp_21_0 = ctx.activeFilterPopup()) ? 29 : -1, tmp_21_0);
            i0.ɵɵadvance();
            i0.ɵɵproperty("isVisible", ctx.isFindReplaceVisible())("container", spreadsheetContainer_r29)("resultsCount", ctx.findResults().length)("currentIndex", ctx.currentFindIndex())("theme", ctx.theme());
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("isVisible", ctx.isColumnSettingsVisible())("columnIndex", ctx.columnSettingsColIndex())("allRows", ctx.rows())("columnConfig", ctx.columnConfig());
            i0.ɵɵadvance();
            i0.ɵɵproperty("isVisible", ctx.isStatsModalVisible())("rows", ctx.displayedRows())("columnConfig", ctx.columnConfig()())("useCountColumn", ctx.statsUseCountColumn)("graphs", ctx.statsGraphsConfig())("theme", ctx.theme());
            i0.ɵɵadvance();
            i0.ɵɵconditional(ctx.isTooltipVisible() ? 34 : -1);
            i0.ɵɵadvance();
            i0.ɵɵproperty("isVisible", ctx.isContextMenuVisible())("position", ctx.contextMenuPosition())("type", ctx.contextMenuType())("data", ctx.contextMenuData())("appendTo", "body")("theme", ctx.theme());
            i0.ɵɵadvance(2);
            i0.ɵɵconditional((tmp_44_0 = ctx.isHeaderTooltipVisible() && ctx.headerTooltipContent()) ? 37 : -1, tmp_44_0);
        } }, dependencies: [CommonModule,
            FormsModule, i1.DefaultValueAccessor, i1.NgControlStatus, i1.NgModel, ContextMenuComponent,
            ColumnEditorComponent,
            FilterPopupComponent,
            FindReplaceComponent,
            TableStatsComponent], encapsulation: 2, changeDetection: 0 }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(SpreadsheetComponent, [{
        type: Component,
        args: [{ selector: 'long-spreadsheet', imports: [
                    CommonModule,
                    FormsModule,
                    ContextMenuComponent,
                    ColumnEditorComponent,
                    FilterPopupComponent,
                    FindReplaceComponent,
                    TableStatsComponent,
                ], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                    '(mousedown)': 'onHostMouseDown($event)',
                    '(copy)': 'onCopy($event)',
                    '(paste)': 'onPaste($event)',
                    '(keydown)': 'onKeyDown($event)',
                    '(document:mousedown)': 'onDocumentMouseDown($event)',
                    '(document:mousemove)': 'onDocumentMouseMove($event)',
                    '(document:mouseup)': 'onDocumentMouseUp($event)',
                    '[style]': 'themeCssVariables()',
                    '[style.height]': 'isFullHeight() ? "100%" : null',
                }, template: "<div class=\"longtable-scope\" style=\"width: 100%; height: 100%;\">\n  <div #rootContainer class=\"relative long-spreadsheet-root\"\n    [style.font-family]=\"'var(--lt-font-family-main, sans-serif)'\" [style.height]=\"isFullHeight() ? '100%' : null\">\n    <input type=\"file\" #csvImporter style=\"display: none\" (change)=\"onCSVFileSelected($event)\" accept=\".csv\">\n    <div #spreadsheetContainer [class]=\"spreadsheetContainerClasses()\"\n      [style.background]=\"'var(--lt-bg-primary, white)'\" [style.height]=\"containerHeight()\"\n      class=\"long-spreadsheet-container\" tabindex=\"0\">\n      <table #spreadsheetTable\n        class=\"table-fixed border-separate border-spacing-0 leading-[12px] relative long-spreadsheet-table\"\n        [style.font-family]=\"'var(--lt-font-family-mono, monospace)'\"\n        style=\"width: -webkit-fill-available; font-size: var(--lt-font-table-cell, 12px);\">\n        <colgroup>\n          <col style=\"width: 3rem;\">\n          @if (columnConfig()().length > 0) {\n          @for (col of columnConfig()(); track $index; let c = $index) {\n          <col [style.width]=\"getColumnWidth(c)\">\n          }\n          }\n        </colgroup>\n        <thead\n          class=\"sticky top-0 z-40 shadow-sm bg-[var(--lt-bg-header,theme(colors.slate.100))] long-spreadsheet-header-row\">\n          <tr>\n            <th (click)=\"selectAllCells()\" (contextmenu)=\"onHeaderCornerContextMenu($event)\"\n              class=\"sticky left-0 w-12 min-w-[3rem] text-center align-middle border-r border-b z-50 cursor-pointer text-[var(--lt-icon-default,theme(colors.slate.400))] bg-[var(--lt-bg-header,theme(colors.slate.100))] border-b-[var(--lt-border-default,theme(colors.slate.200))] border-r-[var(--lt-border-default,theme(colors.slate.200))] hover:bg-[var(--lt-bg-header-hover,theme(colors.slate.200))] long-spreadsheet-header-corner\"\n              style=\"display: table-cell; padding: 7px 10px;\">\n              @if (showLoading()) {\n              <i class=\"pi pi-spinner-dotted pi-spin\"></i>\n              } @else {\n              <i class=\"pi pi-table\"></i>\n              }\n            </th>\n            @for (col of columnConfig()(); track $index; let c = $index) {\n            <th [attr.data-col-index]=\"c\" (contextmenu)=\"onColumnContextMenu($event, c)\"\n              (dblclick)=\"openColumnSettings(c)\" (mouseenter)=\"onHeaderMouseEnter($event, c)\"\n              (mouseleave)=\"onHeaderMouseLeave()\" [class.opacity-50]=\"isColumnDragged().has(c)\"\n              class=\"group relative border-r border-b font-semibold cursor-grab bg-[var(--lt-bg-header,theme(colors.slate.100))] border-b-[var(--lt-border-default,theme(colors.slate.200))] border-r-[var(--lt-border-default,theme(colors.slate.200))] text-[var(--lt-text-header,theme(colors.gray.600))] hover:bg-[var(--lt-bg-header-hover,theme(colors.slate.200))] long-spreadsheet-header-cell\"\n              style=\"padding: 7px 10px;\">\n              <div class=\"flex items-center justify-between gap-2\">\n                <span class=\"truncate\">{{ col.name }}</span>\n                <div class=\"flex items-center text-[var(--lt-icon-default,theme(colors.slate.400))]\">\n                  <div\n                    class=\"p-1 rounded-full cursor-pointer hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.400))] hover:text-[var(--lt-icon-hover-text,theme(colors.slate.800))]\"\n                    (click)=\"toggleSort(c); $event.stopPropagation()\">\n                    @if (sortConfig()?.col === c) {\n                    <i\n                      class=\"pi text-[var(--lt-text-primary,theme(colors.slate.600))] {{ sortConfig()?.direction === 'asc' ? 'pi-sort-amount-up-alt' : 'pi-sort-amount-down' }}\"></i>\n                    } @else {\n                    <i class=\"pi pi-sort-alt opacity-0 group-hover:opacity-100 transition-opacity\"></i>\n                    }\n                  </div>\n                  <div\n                    class=\"filter-toggle-btn p-1 ml-1 rounded-full cursor-pointer hover:bg-[var(--lt-icon-hover-bg,theme(colors.slate.400))] hover:text-[var(--lt-icon-hover-text,theme(colors.slate.800))]\"\n                    (click)=\"toggleFilterPopup(c, $event)\">\n                    @if (filterConfig().has(c)) {\n                    <i class=\"pi pi-filter-fill text-[var(--lt-icon-active,theme(colors.blue.600))]\"></i>\n                    } @else {\n                    <i class=\"pi pi-filter opacity-0 group-hover:opacity-100 transition-opacity\"></i>\n                    }\n                  </div>\n                </div>\n              </div>\n              <div (mousedown)=\"onColResizeMouseDown($event, c)\"\n                class=\"col-resize-handle absolute top-0 right-0 h-full w-2 cursor-col-resize z-10\"></div>\n            </th>\n            }\n          </tr>\n        </thead>\n        <tbody>\n          @for (item of displayedRows(); track item.originalModelIndex; let r = $index) {\n          <tr class=\"long-spreadsheet-row\">\n            <th [attr.data-row-index]=\"r\" (contextmenu)=\"onRowContextMenu($event, r)\"\n              class=\"sticky left-0 w-12 min-w-[3rem] border-r border-b font-semibold z-30 align-top cursor-pointer bg-[var(--lt-bg-header,theme(colors.slate.100))] border-b-[var(--lt-border-default,theme(colors.slate.200))] border-r-[var(--lt-border-default,theme(colors.slate.200))] text-[var(--lt-text-header,theme(colors.gray.600))] hover:bg-[var(--lt-bg-header-hover,theme(colors.slate.200))] long-spreadsheet-row-header-cell\"\n              style=\"padding: 7px 10px;\">\n              {{ r + 1 }}\n            </th>\n            @for (cell of item.cells; track $index; let c = $index) {\n            <td [attr.data-row]=\"item.originalModelIndex\" [attr.data-col]=\"c\"\n              (dblclick)=\"onCellDoubleClick(item.originalModelIndex, c)\"\n              (contextmenu)=\"onCellContextMenu($event, item.originalModelIndex, c)\"\n              (mouseenter)=\"onCellMouseEnter($event, item.originalModelIndex, c)\" (mouseleave)=\"onCellMouseLeave()\"\n              style=\"padding: 7px 10px;\"\n              class=\"border-r border-b relative whitespace-pre-wrap align-top long-spreadsheet-cell {{ isEditing(item.originalModelIndex,c) ? 'invisible' : '' }} {{ getCell(item.originalModelIndex, c)?.readOnly ? 'text-[var(--lt-text-read-only,theme(colors.gray.500))] bg-[var(--lt-bg-primary,transparent)]' : 'text-[var(--lt-text-primary,theme(colors.gray.900))]' }} {{ isCellInvalid(item.originalModelIndex, c) ? '!bg-[var(--lt-bg-invalid,theme(colors.red.100))]' : (isSelected(item.originalModelIndex,c) ? 'bg-[var(--lt-bg-selection,theme(colors.blue.100))]' : '') }} {{ isSelected(item.originalModelIndex,c) ? 'border-transparent' : 'border-[var(--lt-border-grid,theme(colors.slate.200))]' }}\">\n              @if (isCellInvalid(item.originalModelIndex, c)) {\n              <div\n                class=\"absolute top-0 right-0 w-0 h-0 border-solid z-20 border-b-[4px] border-l-[4px] border-t-[4px] border-r-[4px] border-b-transparent border-l-transparent border-t-[#ff0000] border-r-[#ff0000]\"\n                (mouseenter)=\"onCellMouseEnter($event, item.originalModelIndex, c)\"></div>\n              }\n              @if (columnConfig()()[c]?.editor === 'checkbox') {\n              <div class=\"flex items-center justify-center w-full h-full\" (dblclick)=\"$event.stopPropagation()\">\n                <input type=\"checkbox\"\n                  class=\"w-4 h-4 rounded cursor-pointer bg-[var(--lt-checkbox-bg,white)] border border-[var(--lt-checkbox-border,theme(colors.slate.300))] focus:ring-2 focus:ring-offset-2 focus:ring-[var(--lt-icon-active,theme(colors.blue.600))] focus:ring-offset-[var(--lt-bg-primary,white)] accent-[var(--lt-icon-active,theme(colors.blue.600))]\"\n                  [checked]=\"isCheckboxChecked(item.originalModelIndex, c)\"\n                  [disabled]=\"getCell(item.originalModelIndex, c)?.readOnly\"\n                  (change)=\"onCheckboxChange($event, item.originalModelIndex, c)\"\n                  (mousedown)=\"$event.stopPropagation()\">\n              </div>\n              } @else {\n              <div class=\"flex items-center w-full min-w-0 break-words\">\n                @if (columnConfig()()[c]?.editor === 'dropdown') {\n                @if (getDropdownOptionColor(item.originalModelIndex, c); as color) {\n                <span class=\"h-2 w-2 rounded-full mr-2 flex-shrink-0\" [style.backgroundColor]=\"color\"></span>\n                }\n                }\n                <span [innerHTML]=\"getHighlightedCellContent(item.originalModelIndex, c)\"></span>\n              </div>\n              }\n              @if (isFillHandleVisible(item.originalModelIndex, c)) {\n              <div\n                class=\"fill-handle absolute -right-1.5 -bottom-1.5 w-3 h-3 cursor-crosshair z-[70] bg-[var(--lt-fill-handle,theme(colors.blue.600))] border border-[var(--lt-fill-handle-border,white)]\"\n                (dblclick)=\"onFillHandleDoubleClick($event)\"></div>\n              }\n            </td>\n            }\n          </tr>\n          }\n        </tbody>\n      </table>\n\n      <!-- Floating Cell Editor -->\n      @if (editingCell(); as coords) {\n      @if (editorPosition(); as pos) {\n      @if (getCell(coords.row, coords.col); as cell) {\n      @if (columnConfig()()[coords.col]?.editor === 'dropdown') {\n      <div #dropdownEditor (mousedown)=\"$event.stopPropagation()\"\n        class=\"absolute z-[70] flex flex-col rounded-md shadow-lg border-2 border-[var(--lt-border-editing,theme(colors.blue.600))] long-spreadsheet-floating-editor\"\n        [style.top.px]=\"pos.top\" [style.left.px]=\"pos.left\" [style.width.px]=\"pos.width\"\n        [style.background]=\"'var(--lt-popup-bg)'\">\n        <div class=\"p-2 border-b border-[var(--lt-border-default,theme(colors.slate.200))]\">\n          <input type=\"text\" #dropdownSearchInput [ngModel]=\"dropdownSearchText()\"\n            (ngModelChange)=\"dropdownSearchText.set($event)\" (keydown)=\"onDropdownKeyDown($event)\"\n            placeholder=\"Filter options...\"\n            class=\"w-full px-2 py-1 bg-[var(--lt-input-bg,white)] border border-[var(--lt-border-default,theme(colors.slate.300))] rounded-md shadow-sm focus:outline-none focus:border-[var(--lt-border-editing,theme(colors.blue.500))] focus:ring-1 focus:ring-[var(--lt-border-editing,theme(colors.blue.500))] text-[var(--lt-text-primary,inherit)]\"\n            [style.fontSize]=\"'var(--lt-font-input, 14px)'\">\n        </div>\n        <div class=\"flex-grow overflow-y-auto max-h-48 p-1 modal-scroll-content\">\n          @for (option of filteredDropdownOptions(); track option; let i = $index) {\n          <button (click)=\"selectDropdownOption(option)\" [id]=\"'dropdown-option-' + i\"\n            [style.fontSize]=\"'var(--lt-font-table-cell, 12px)'\"\n            [style.font-family]=\"'var(--lt-font-family-mono, monospace)'\"\n            [class]=\"'w-full text-left px-2 py-1.5 leading-[12px] flex items-center justify-between rounded-md ' + (getOptionValue(option) == cell.value ? 'bg-[var(--lt-bg-selection,theme(colors.blue.100))] text-[var(--lt-text-selection,theme(colors.blue.800))] font-semibold' : (i === dropdownActiveOptionIndex() ? 'bg-[var(--lt-bg-header-hover,theme(colors.slate.200))] text-[var(--lt-text-primary,theme(colors.gray.800))]' : 'text-[var(--lt-text-primary,theme(colors.gray.700))] hover:bg-[var(--lt-icon-hover-bg,theme(colors.gray.100))]'))\">\n            <div class=\"flex items-center truncate\">\n              @if (getOptionColor(option); as color) { <span class=\"h-2 w-2 rounded-full mr-2 flex-shrink-0\"\n                [style.backgroundColor]=\"color\"></span> }\n              <span class=\"truncate\">{{ getOptionValue(option) }}</span>\n            </div>\n            @if (getOptionValue(option) == cell.value) { <i class=\"pi pi-check text-xs ml-2 flex-shrink-0\"></i> }\n          </button>\n          }\n        </div>\n        <div class=\"p-1\">\n          <button (click)=\"editDropdownOptions()\"\n            class=\"w-full text-left px-2 py-1.5 text-sm text-[var(--lt-icon-active,theme(colors.blue.600))] hover:bg-[var(--lt-icon-hover-bg,theme(colors.gray.100))] flex items-center gap-2 rounded-md\"\n            [style.fontSize]=\"'var(--lt-font-modal-content, 14px)'\">\n            <i class=\"pi pi-pencil text-xs\"></i><span>Edit Options</span>\n          </button>\n        </div>\n      </div>\n      } @else {\n      <div\n        class=\"absolute z-[70] box-border border-2 bg-[var(--lt-input-bg,white)] border-[var(--lt-border-editing,theme(colors.blue.600))] long-spreadsheet-floating-editor\"\n        [style.top.px]=\"pos.top\" [style.left.px]=\"pos.left\" [style.width.px]=\"pos.width\" [style.height.px]=\"pos.height\"\n        [style.padding]=\"'7px 10px'\">\n        <textarea #editingInput [(ngModel)]=\"editValue\" (blur)=\"onEditBlur()\" (keydown)=\"onEditKeyDown($event)\"\n          (input)=\"onEditorInput()\"\n          class=\"w-full h-full block bg-transparent select-text resize-none outline-none box-border !p-0 !border-0 leading-[12px] text-[var(--lt-text-primary,inherit)]\"\n          [style.font-family]=\"'var(--lt-font-family-mono, monospace)'\"\n          [style.fontSize]=\"'var(--lt-font-table-cell, 12px)'\"></textarea>\n      </div>\n      }\n      }\n      }\n      }\n\n      <!-- Selection and Fill Overlays -->\n      @for (pos of selectionRangePositions(); track $index) {\n      <div\n        class=\"absolute pointer-events-none z-20 shadow-[inset_0_0_0_2px] shadow-[var(--lt-selection-shadow,theme(colors.blue.600))]\"\n        [style]=\"pos\"></div>\n      }\n      @if (fillRange() && selectionRanges().length > 0) {\n      <div\n        class=\"absolute pointer-events-none z-10 border border-dashed border-gray-600 bg-gray-400/10 dark:border-slate-400 dark:bg-slate-500/20\"\n        [style]=\"fillRangePosition()\"></div>\n      }\n      @if (isDraggingColumn()) {\n      <div class=\"absolute w-0.5 z-[60] pointer-events-none bg-[var(--lt-drop-indicator,theme(colors.blue.500))]\"\n        [style]=\"dropIndicatorPosition()\"></div>\n      }\n\n      <div #filterPopupEl class=\"long-spreadsheet-filter-popup-container\">\n        @if (activeFilterPopup(); as popup) {\n        <long-filter-popup [isVisible]=\"!!popup\" [position]=\"filterPopupPosition()\"\n          [uniqueValues]=\"currentFilterUniqueValues()\" [initialSelection]=\"filterPopupInitialSelection()\"\n          (apply)=\"handleApplyFilter({ col: popup.col, selection: $event })\" (clear)=\"handleClearFilter(popup.col)\"\n          (close)=\"activeFilterPopup.set(null)\"></long-filter-popup>\n        }\n      </div>\n\n      <long-find-replace #findReplacePanelEl [isVisible]=\"isFindReplaceVisible()\" [container]=\"spreadsheetContainer\"\n        class=\"longtable-scope\" [resultsCount]=\"findResults().length\" [currentIndex]=\"currentFindIndex()\"\n        [theme]=\"theme()\" (findQueryChange)=\"onFindQueryChange($event)\"\n        (findOptionsChange)=\"onFindOptionsChange($event)\" (navigateNext)=\"navigateToNextMatch()\"\n        (navigatePrev)=\"navigateToPrevMatch()\" (replaceOne)=\"replaceCurrentMatch($event)\"\n        (replaceAll)=\"replaceAllMatches($event)\" (close)=\"closeFindReplace()\"></long-find-replace>\n\n      <long-column-editor [isVisible]=\"isColumnSettingsVisible()\" [columnIndex]=\"columnSettingsColIndex()\"\n        [allRows]=\"rows()\" [columnConfig]=\"columnConfig()\" (close)=\"isColumnSettingsVisible.set(false)\"\n        (save)=\"handleSaveColumnSettings($event)\"></long-column-editor>\n\n      <long-table-stats [isVisible]=\"isStatsModalVisible()\" [rows]=\"displayedRows()\" [columnConfig]=\"columnConfig()()\"\n        (close)=\"isStatsModalVisible.set(false)\" [useCountColumn]=\"statsUseCountColumn\" [graphs]=\"statsGraphsConfig()\"\n        [theme]=\"theme()\">\n      </long-table-stats>\n\n      <!-- Validation Tooltip -->\n      @if (isTooltipVisible()) {\n      @let pos = tooltipPosition();\n      <div #validationTooltip\n        class=\"absolute w-max max-w-xs bg-red-600 text-white text-sm rounded-md shadow-lg p-2 z-[110] pointer-events-none leading-tight\"\n        [style.font-family]=\"'var(--lt-font-family-mono, monospace)'\" [style.left.px]=\"pos.x\" [style.top.px]=\"pos.y\">\n        {{ tooltipText() }}\n      </div>\n      }\n    </div>\n\n    <!-- Popups and Modals -->\n    <long-context-menu #contextMenuEl [isVisible]=\"isContextMenuVisible()\" [position]=\"contextMenuPosition()\"\n      class=\"long-spreadsheet-context-menu longtable-scope\" [type]=\"contextMenuType()\" [data]=\"contextMenuData()\"\n      (menuAction)=\"handleContextMenuAction($event)\" [appendTo]=\"'body'\" [theme]=\"theme()\"></long-context-menu>\n\n    <!-- Header Tooltip -->\n    @if (isHeaderTooltipVisible() && headerTooltipContent(); as content) {\n    @let pos = headerTooltipPosition();\n    <div #headerTooltip\n      class=\"absolute w-max max-w-xs text-sm rounded-md shadow-lg p-2.5 z-[110] pointer-events-none leading-tight\"\n      [style.background-color]=\"'var(--lt-tooltip-bg, #1e293b)'\" [style.color]=\"'var(--lt-tooltip-text, #ffffff)'\"\n      [style.font-family]=\"'var(--lt-font-family-mono, monospace)'\" [style.left.px]=\"pos.x\" [style.top.px]=\"pos.y\">\n      <div class=\"font-bold mb-1\">{{ content.name }}</div>\n      @if (content.description) {\n      <div class=\"mb-1 text-slate-300 italic\">{{ content.description }}</div>\n      }\n      <div class=\"border-t border-slate-600 my-1\"></div>\n      <div class=\"text-slate-400\">Field: <span class=\"font-semibold text-slate-200\">{{ content.kebabName }}</span></div>\n      <div class=\"text-slate-400\">Type: <span class=\"font-semibold text-slate-200\">{{ content.type }}</span></div>\n    </div>\n    }\n  </div>\n</div>" }]
    }], () => [], { data: [{ type: i0.Input, args: [{ isSignal: true, alias: "data", required: true }] }], columnConfig: [{ type: i0.Input, args: [{ isSignal: true, alias: "columnConfig", required: true }] }], theme: [{ type: i0.Input, args: [{ isSignal: true, alias: "theme", required: true }] }], showLoading: [{ type: i0.Input, args: [{ isSignal: true, alias: "showLoading", required: false }] }], onDataChange: [{ type: i0.Output, args: ["onDataChange"] }], onColumnChange: [{ type: i0.Output, args: ["onColumnChange"] }], rootContainer: [{ type: i0.ViewChild, args: ['rootContainer', { isSignal: true }] }], spreadsheetContainer: [{ type: i0.ViewChild, args: ['spreadsheetContainer', { isSignal: true }] }], spreadsheetTable: [{ type: i0.ViewChild, args: ['spreadsheetTable', { isSignal: true }] }], editingInput: [{ type: i0.ViewChild, args: ['editingInput', { isSignal: true }] }], dropdownEditor: [{ type: i0.ViewChild, args: ['dropdownEditor', { isSignal: true }] }], dropdownSearchInput: [{ type: i0.ViewChild, args: ['dropdownSearchInput', { isSignal: true }] }], contextMenuEl: [{ type: i0.ViewChild, args: ['contextMenuEl', { isSignal: true }] }], filterPopupEl: [{ type: i0.ViewChild, args: ['filterPopupEl', { isSignal: true }] }], findReplacePanelEl: [{ type: i0.ViewChild, args: ['findReplacePanelEl', { isSignal: true }] }], csvImporter: [{ type: i0.ViewChild, args: ['csvImporter', { isSignal: true }] }], validationTooltip: [{ type: i0.ViewChild, args: ['validationTooltip', { isSignal: true }] }], headerTooltip: [{ type: i0.ViewChild, args: ['headerTooltip', { isSignal: true }] }], height: [{ type: i0.Input, args: [{ isSignal: true, alias: "height", required: false }] }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(SpreadsheetComponent, { className: "SpreadsheetComponent", filePath: "lib/components/spreadsheet/spreadsheet.component.ts", lineNumber: 39 }); })();

const fontFamily = {
    main: `system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji'`,
    mono: `'SF Mono', SFMono-Regular, ui-monospace, 'DejaVu Sans Mono', 'Liberation Mono', Menlo, Monaco, Consolas, monospace`,
};
const fontSizes = {
    tableCell: '14px',
    header: '14px',
    modalLargeTitle: '20px',
    modalTitle: '18px',
    modalContent: '14px',
    contextMenu: '14px',
    input: '14px',
    chartAxisTitle: '12px',
    chartAxisLabel: '10px',
    chartLegend: '12px',
};
const longLight = {
    name: 'long-light',
    colorScheme: 'light',
    colors: {
        // Backgrounds
        bgPrimary: '#ffffff',
        bgHeader: '#f1f5f9',
        bgHeaderHover: '#e2e8f0',
        bgSelection: '#dbeafe', // blue-100
        inputBg: '#f7f8f9',
        bgInvalid: '#fee2e2', // red-100
        // Text
        textPrimary: '#0f172a',
        textHeader: '#475569',
        textReadOnly: '#64748b',
        textSelection: '#1e40af', // blue-800
        // Borders
        borderDefault: '#e2e8f0',
        borderGrid: '#e2e8f0',
        borderEditing: '#2563eb', // blue-600
        // UI Elements
        fillHandle: '#2563eb',
        fillHandleBorder: '#ffffff',
        dropIndicator: '#3b82f6',
        selectionShadow: '#2563eb',
        // Icons & Popups
        iconDefault: '#94a3b8',
        iconHoverBg: '#cbd5e1',
        iconHoverText: '#1e293b',
        iconActive: '#3b82f6', // blue-500
        popupBg: '#ffffff',
        popupBorder: '#e2e8f0',
        // Tooltips
        tooltipBg: '#1e293b', // slate-800
        tooltipText: '#ffffff',
        // Buttons
        buttonPrimaryBg: '#2563eb', // blue-600
        buttonPrimaryBgHover: '#1d4ed8', // blue-700
        buttonPrimaryText: '#ffffff',
        // Checkboxes
        checkboxBg: '#ffffff',
        checkboxBorder: '#cbd5e1', // slate-300
        // Graphs
        graphPrimary: '#3b82f6', // blue-500
        graphSecondary: '#64748b', // slate-500
    },
    scrollbar: {
        track: '#f1f5f9',
        thumb: '#cbd5e1',
        thumbHover: '#94a3b8',
        border: '#f1f5f9',
        corner: '#f1f5f9',
    },
    fontFamily,
    fontSizes,
};
const longDark = {
    name: 'long-dark',
    colorScheme: 'dark',
    colors: {
        // Backgrounds
        bgPrimary: '#262c35',
        bgHeader: '#353d48',
        bgHeaderHover: '#434d5b',
        bgSelection: 'rgba(30, 64, 175, 0.5)', // blue-900 with opacity
        inputBg: '#181c21',
        bgInvalid: 'rgba(153, 27, 27, 0.4)', // red-900 with opacity
        // Text
        textPrimary: '#bbc1cb',
        textHeader: '#bbc1cb',
        textReadOnly: '#64748b',
        textSelection: '#dbeafe', // blue-100
        // Borders
        borderDefault: '#424d5d',
        borderGrid: '#424d5d',
        borderEditing: '#60a5fa', // blue-400
        // UI Elements
        fillHandle: '#60a5fa',
        fillHandleBorder: '#262c35',
        dropIndicator: '#60a5fa',
        selectionShadow: '#60a5fa',
        // Icons & Popups
        iconDefault: '#64748b',
        iconHoverBg: '#4b5563',
        iconHoverText: '#e5e7eb',
        iconActive: '#60a5fa',
        popupBg: '#262c35',
        popupBorder: '#424d5d',
        // Tooltips
        tooltipBg: '#434d5b',
        tooltipText: '#e5e7eb',
        // Buttons
        buttonPrimaryBg: '#3b82f6', // blue-500
        buttonPrimaryBgHover: '#2563eb', // blue-600
        buttonPrimaryText: '#ffffff',
        // Checkboxes
        checkboxBg: '#353d48',
        checkboxBorder: '#424d5d',
        // Graphs
        graphPrimary: '#3b82f6', // blue-500
        graphSecondary: '#94a3b8', // slate-400
    },
    scrollbar: {
        track: '#353d48',
        thumb: '#4f5b6b',
        thumbHover: '#647080',
        border: '#353d48',
        corner: '#353d48',
    },
    fontFamily,
    fontSizes,
};
const cosmicDark = {
    ...longDark,
    name: 'cosmic-dark',
    colors: {
        ...longDark.colors,
        // Backgrounds with a single subtle purple "nebula" glow
        bgPrimary: '#272533',
        bgHeader: '#2c2a38',
        bgHeaderHover: '#383645',
        popupBg: 'radial-gradient(circle at 15% 75%, rgb(199 63 187 / 15%) 0%, rgba(34, 211, 238, 0) 25%), radial-gradient(circle at 80% 20%, rgba(167, 139, 250, 0.1) 0%, rgba(167, 139, 250, 0) 20%), linear-gradient(160deg, #2a2836 0%, #2e2c3b 100%)',
        // Selection colors using purple accent
        bgSelection: 'rgba(139, 92, 246, 0.4)', // violet-500/40
        textSelection: '#ede9fe', // violet-100
        // Interactive elements using purple accent
        borderEditing: '#a78bfa', // violet-400
        selectionShadow: '#a78bfa', // violet-400
        iconActive: '#a78bfa', // violet-400
        fillHandle: '#a78bfa', // violet-400
        dropIndicator: '#a78bfa', // violet-400
        // Buttons remain a deeper purple for contrast
        buttonPrimaryBg: '#7c3aed', // violet-600
        buttonPrimaryBgHover: '#6d28d9', // violet-700
        // Themed text colors
        textPrimary: '#c7c4d0',
        textHeader: '#c7c4d0',
        textReadOnly: '#5b5869',
        // Themed borders
        borderDefault: '#413e4f',
        borderGrid: '#413e4f',
        popupBorder: '#413e4f',
        // Themed icons
        iconDefault: '#7a768d',
        iconHoverBg: '#383645',
        iconHoverText: '#ede9fe',
        // Tooltips
        tooltipBg: '#383645',
        tooltipText: '#c7c4d0',
        // Themed checkboxes
        checkboxBorder: '#413e4f',
        checkboxBg: '#2c2a38',
        // Graphs
        graphPrimary: '#a78bfa', // violet-400
        graphSecondary: '#7a768d',
    },
    fontFamily,
    scrollbar: {
        track: '#2c2a38',
        thumb: '#4f4b63',
        thumbHover: '#66617a',
        border: '#2c2a38',
        corner: '#2c2a38',
    },
};
const goldDust = {
    ...longDark,
    name: 'gold-dust',
    colors: {
        ...longDark.colors,
        // Backgrounds - Deep Obsidian with a very subtle golden "aurora" effect
        bgPrimary: 'radial-gradient(circle at 50% -20%, rgba(212, 175, 55, 0.12) 0%, rgb(108 98 66 / 0%) 50%), radial-gradient(circle at 10% 20%, rgba(184, 134, 11, 0.04) 0%, rgba(13, 13, 13, 0) 40%), linear-gradient(180deg, #363326 0%, #33312c 100%)',
        bgHeader: '#38362aff',
        bgHeaderHover: '#454236ff',
        inputBg: '#22211d',
        popupBg: 'linear-gradient(160deg, #363326 0%, #33312c 100%)',
        // Selection colors - Sophisticated champagne wash
        bgSelection: 'rgba(197, 160, 89, 0.18)',
        textSelection: '#ffffff',
        // Interactive elements - High-quality metallic accents
        borderEditing: '#b79e47ff', // Bright Gold for focus
        selectionShadow: 'rgba(197, 160, 89, 0.3)',
        iconActive: '#c5a059', // Champagne Gold
        fillHandle: '#b79e47ff',
        dropIndicator: '#b79e47ff',
        // Buttons - Elegant Dark Gold
        buttonPrimaryBg: 'linear-gradient(180deg, #b8860b 0%, #8b6508 100%)',
        buttonPrimaryBgHover: 'linear-gradient(180deg, #996515 0%, #724c10 100%)',
        buttonPrimaryText: '#ffffff',
        // Themed text colors - Off-white with golden headers
        textPrimary: '#dbd4c1ff',
        textHeader: '#c5a059', // Champagne Gold
        textReadOnly: '#4a4a4a',
        // Themed borders - Noble dark bronze/charcoal
        borderDefault: '#2a2a2a',
        borderGrid: '#2a2a2a',
        popupBorder: '#2a2a2a',
        // Icons
        iconDefault: '#c5a059',
        iconHoverBg: '#2a2a2a',
        iconHoverText: '#c5a059',
        // Checkboxes
        checkboxBorder: '#3d3d35',
        checkboxBg: '#0d0d0d',
        // Graphs
        graphPrimary: '#d4af37', // Gold
        graphSecondary: '#c5a059', // Champagne
    },
    scrollbar: {
        track: '#38362aff',
        thumb: '#2a2a2a',
        thumbHover: '#1f1f1fff',
        border: '#38362aff',
        corner: '#38362aff',
    },
};

/**
 * Generated bundle index. Do not edit.
 */

export { SpreadsheetComponent, cosmicDark, goldDust, longDark, longLight };
//# sourceMappingURL=oatear-longtable.mjs.map
