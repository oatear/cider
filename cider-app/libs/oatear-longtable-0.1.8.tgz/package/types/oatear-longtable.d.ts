import * as _angular_core from '@angular/core';
import { WritableSignal, OnDestroy } from '@angular/core';

interface DropdownOption {
    value: string;
    color: string;
}
type ColumnType = 'text' | 'dropdown' | 'checkbox' | 'numeric';
type AnalysisType = 'categorical' | 'numeric' | 'token';
interface Cell {
    value: string | number | boolean;
    readOnly?: boolean;
}
interface Coordinates {
    row: number;
    col: number;
}
interface ColumnConfig {
    name: string;
    field: string;
    readOnly?: boolean;
    width?: number | 'auto';
    description?: string;
    editor?: ColumnType;
    options?: (string | DropdownOption)[];
    lockSettings?: boolean;
}
interface ContextMenuData {
    insertRowsAboveText: string;
    insertRowsBelowText: string;
    deleteRowText: string;
    deleteColText: string;
    isInsertColumnActionReadOnly: boolean;
    isDeleteColumnActionReadOnly: boolean;
    canDeleteRows: boolean;
    canDeleteCols: boolean;
}
interface ColumnSettingsFormData {
    name: string;
    description: string;
    type: ColumnType;
    options: {
        value: string;
        color: string;
    }[];
    widthValue: number | null;
}
interface AnalysisOption {
    label: string;
    value: number;
    type: AnalysisType;
}
interface SavedDistributionAnalysisState {
    analysisField: number | null;
    stackByField: number | null;
    view: 'chart' | 'table';
}
interface SavedCorrelationAnalysisState {
    fieldX: number | null;
    fieldY: number | null;
    categoryField: number | null;
}
interface DistributionGraphConfig {
    type: 'distribution';
    state: WritableSignal<SavedDistributionAnalysisState>;
}
interface CorrelationGraphConfig {
    type: 'correlation';
    state: WritableSignal<SavedCorrelationAnalysisState>;
}
type GraphConfig = DistributionGraphConfig | CorrelationGraphConfig;
interface SpreadsheetTheme {
    name: string;
    colorScheme?: 'light' | 'dark';
    colors: {
        bgPrimary: string;
        bgHeader: string;
        bgHeaderHover: string;
        bgSelection: string;
        inputBg: string;
        bgInvalid: string;
        textPrimary: string;
        textHeader: string;
        textReadOnly: string;
        textSelection?: string;
        borderDefault: string;
        borderGrid: string;
        borderEditing: string;
        fillHandle: string;
        fillHandleBorder: string;
        dropIndicator: string;
        selectionShadow: string;
        iconDefault: string;
        iconHoverBg: string;
        iconHoverText: string;
        iconActive: string;
        popupBg: string;
        popupBorder: string;
        tooltipBg: string;
        tooltipText: string;
        buttonPrimaryBg: string;
        buttonPrimaryBgHover: string;
        buttonPrimaryText: string;
        checkboxBg: string;
        checkboxBorder: string;
        graphPrimary: string;
        graphSecondary: string;
    };
    scrollbar?: {
        track: string;
        thumb: string;
        thumbHover: string;
        border: string;
        corner: string;
    };
    fontFamily?: {
        main: string;
        mono: string;
    };
    fontSizes?: {
        tableCell: string;
        header: string;
        modalLargeTitle: string;
        modalTitle: string;
        modalContent: string;
        contextMenu: string;
        input: string;
        chartAxisTitle: string;
        chartAxisLabel: string;
        chartLegend: string;
    };
}

declare class SpreadsheetComponent implements OnDestroy {
    data: _angular_core.InputSignal<WritableSignal<Cell[][]>>;
    columnConfig: _angular_core.InputSignal<WritableSignal<ColumnConfig[]>>;
    theme: _angular_core.InputSignal<SpreadsheetTheme>;
    showLoading: _angular_core.InputSignal<boolean>;
    onDataChange: _angular_core.OutputEmitterRef<Cell[][]>;
    onColumnChange: _angular_core.OutputEmitterRef<ColumnConfig[]>;
    protected readonly uniqueId: string;
    activeCell: WritableSignal<Coordinates | null>;
    selectionRanges: WritableSignal<{
        start: Coordinates;
        end: Coordinates;
    }[]>;
    editingCell: WritableSignal<Coordinates | null>;
    isMouseDown: WritableSignal<boolean>;
    isDraggingFill: WritableSignal<boolean>;
    isSelectingRows: WritableSignal<boolean>;
    isSelectingCols: WritableSignal<boolean>;
    fillRange: WritableSignal<{
        start: Coordinates;
        end: Coordinates;
    } | null>;
    editValue: WritableSignal<string | number | boolean>;
    editorPosition: WritableSignal<{
        top: number;
        left: number;
        width: number;
        height: number;
    } | null>;
    private isNewValueEntry;
    isResizingCol: WritableSignal<number | null>;
    resizingColStart: WritableSignal<{
        x: number;
        width: number;
    } | null>;
    isDraggingColumn: WritableSignal<boolean>;
    draggedColumnInfo: WritableSignal<{
        startIndex: number;
        count: number;
        startX: number;
    } | null>;
    dropColumnIndex: WritableSignal<number | null>;
    sortConfig: WritableSignal<{
        col: number;
        direction: "asc" | "desc";
    } | null>;
    filterConfig: WritableSignal<Map<number, Set<string>>>;
    dropdownSearchText: WritableSignal<string>;
    dropdownActiveOptionIndex: WritableSignal<number>;
    validationErrors: WritableSignal<Map<string, string>>;
    isTooltipVisible: WritableSignal<boolean>;
    tooltipText: WritableSignal<string>;
    tooltipPosition: WritableSignal<{
        x: number;
        y: number;
    }>;
    private tooltipTimeout;
    isHeaderTooltipVisible: WritableSignal<boolean>;
    headerTooltipContent: WritableSignal<{
        name: string;
        description: string | undefined;
        type: string;
        kebabName: string;
    } | null>;
    headerTooltipPosition: WritableSignal<{
        x: number;
        y: number;
    }>;
    private headerTooltipTimeout;
    private lastHeaderHoverTarget;
    private undoStack;
    private redoStack;
    isContextMenuVisible: WritableSignal<boolean>;
    isColumnSettingsVisible: WritableSignal<boolean>;
    isFindReplaceVisible: WritableSignal<boolean>;
    isStatsModalVisible: WritableSignal<boolean>;
    findQuery: WritableSignal<string>;
    findOptions: WritableSignal<{
        matchCase: boolean;
        matchEntireCell: boolean;
    }>;
    currentFindIndex: WritableSignal<number>;
    activeFilterPopup: WritableSignal<{
        col: number;
        target: HTMLElement;
    } | null>;
    contextMenuPosition: WritableSignal<{
        x: number;
        y: number;
    }>;
    menuLaunchCoords: WritableSignal<{
        x: number;
        y: number;
    } | null>;
    contextMenuType: WritableSignal<"row" | "cell" | "col" | "headerCorner" | null>;
    contextMenuCoords: WritableSignal<Coordinates | null>;
    columnSettingsColIndex: WritableSignal<number | null>;
    statsUseCountColumn: WritableSignal<boolean>;
    statsGraphsConfig: WritableSignal<GraphConfig[]>;
    private rootContainer;
    private spreadsheetContainer;
    private spreadsheetTable;
    private editingInput;
    private dropdownEditor;
    private dropdownSearchInput;
    private contextMenuEl;
    private filterPopupEl;
    private findReplacePanelEl;
    private csvImporter;
    private validationTooltip;
    private headerTooltip;
    private layoutTick;
    private resizeObserver?;
    private isDataInitialized;
    private isColumnConfigInitialized;
    rows: _angular_core.Signal<Cell[][]>;
    colsCount: _angular_core.Signal<number>;
    height: _angular_core.InputSignal<string | number>;
    spreadsheetContainerClasses: _angular_core.Signal<string>;
    containerHeight: _angular_core.Signal<string>;
    isFullHeight: _angular_core.Signal<boolean>;
    themeCssVariables: _angular_core.Signal<{
        [key: string]: string;
    }>;
    private scrollbarStyles;
    filteredDropdownOptions: _angular_core.Signal<(string | DropdownOption)[]>;
    displayedRows: _angular_core.Signal<{
        cells: Cell[];
        originalModelIndex: number;
    }[]>;
    findResults: _angular_core.Signal<Coordinates[]>;
    selectionRangePositions: _angular_core.Signal<({
        display: string;
        left?: undefined;
        top?: undefined;
        width?: undefined;
        height?: undefined;
    } | {
        display: string;
        left: string;
        top: string;
        width: string;
        height: string;
    })[]>;
    fillRangePosition: _angular_core.Signal<{
        display: string;
        left?: undefined;
        top?: undefined;
        width?: undefined;
        height?: undefined;
    } | {
        display: string;
        left: string;
        top: string;
        width: string;
        height: string;
    }>;
    activeSelectionRange: _angular_core.Signal<{
        start: Coordinates;
        end: Coordinates;
    } | null>;
    selectedRowCount: _angular_core.Signal<number>;
    selectedColCount: _angular_core.Signal<number>;
    contextMenuData: _angular_core.Signal<ContextMenuData>;
    filterPopupPosition: _angular_core.Signal<{
        display: string;
        left: string;
        top: string;
    }>;
    currentFilterUniqueValues: _angular_core.Signal<string[]>;
    filterPopupInitialSelection: _angular_core.Signal<Set<string>>;
    isColumnDragged: _angular_core.Signal<Set<number>>;
    dropIndicatorPosition: _angular_core.Signal<{
        display: string;
        left?: undefined;
        top?: undefined;
        height?: undefined;
    } | {
        display: string;
        left: string;
        top: string;
        height: string;
    }>;
    private renderer;
    private document;
    private styleElement;
    constructor();
    ngOnDestroy(): void;
    selectAllCells(): void;
    getCell(modelRow: number, modelCol: number): Cell | undefined;
    getDropdownOptionColor(modelRow: number, modelCol: number): string | undefined;
    getOptionValue: (option: string | DropdownOption) => string;
    getOptionColor: (option: string | DropdownOption) => string | undefined;
    getHighlightedCellContent(modelRow: number, modelCol: number): string;
    private escapeRegex;
    onFindQueryChange(query: string): void;
    onFindOptionsChange(options: {
        matchCase: boolean;
        matchEntireCell: boolean;
    }): void;
    navigateToNextMatch(): void;
    navigateToPrevMatch(): void;
    private navigateToCurrentMatch;
    replaceCurrentMatch(replacement: string): void;
    replaceAllMatches(replacement: string): void;
    closeFindReplace(): void;
    getColumnWidth: (colIndex: number) => string;
    isSelected(modelRow: number, modelCol: number): boolean;
    isActive(modelRow: number, modelCol: number): boolean;
    isEditing: (r: number, c: number) => boolean;
    isCellInvalid: (r: number, c: number) => boolean;
    isFillHandleVisible(modelRow: number, modelCol: number): boolean;
    isInFillRange(modelRow: number, modelCol: number): boolean;
    onCheckboxChange(event: Event, modelRow: number, modelCol: number): void;
    isCheckboxChecked(modelRow: number, modelCol: number): boolean;
    handleContextMenuAction(action: string): void;
    onHostMouseDown(event: MouseEvent): void;
    onDocumentMouseMove(event: MouseEvent): void;
    onDocumentMouseUp(event: MouseEvent): void;
    onCellDoubleClick: (r: number, c: number) => void;
    onFillHandleDoubleClick(event: MouseEvent): void;
    onCellMouseEnter(event: MouseEvent, modelRow: number, modelCol: number): void;
    onCellMouseLeave: () => void;
    onHeaderMouseEnter(event: MouseEvent, colIndex: number): void;
    onHeaderMouseLeave: () => void;
    onKeyDown(event: KeyboardEvent): void;
    onCopy(event: ClipboardEvent): Promise<void>;
    onPaste(event: ClipboardEvent): Promise<void>;
    onColResizeMouseDown(event: MouseEvent, colIndex: number): void;
    startEditing(coords: Coordinates, initialValue?: string): void;
    onEditBlur: () => void;
    onEditKeyDown(event: KeyboardEvent): void;
    onEditorInput(): void;
    saveEdit(): void;
    cancelEdit(): void;
    selectDropdownOption(option: DropdownOption | string): void;
    editDropdownOptions(): void;
    onDropdownKeyDown(event: KeyboardEvent): void;
    toggleSort(col: number): void;
    toggleFilterPopup(col: number, event: MouseEvent): void;
    handleApplyFilter({ col, selection }: {
        col: number;
        selection: Set<string>;
    }): void;
    handleClearFilter(col: number): void;
    openColumnSettings(colIndex: number): void;
    handleSaveColumnSettings({ colIndex, formState }: {
        colIndex: number;
        config: ColumnConfig;
        formState: ColumnSettingsFormData;
    }): void;
    private adjustContextMenuPosition;
    onDocumentMouseDown(event: MouseEvent): void;
    onHeaderCornerContextMenu(event: MouseEvent): void;
    onCellContextMenu(event: MouseEvent, modelRow: number, modelCol: number): void;
    onRowContextMenu(event: MouseEvent, visualRowIndex: number): void;
    onColumnContextMenu(event: MouseEvent, colIndex: number): void;
    private openContextMenu;
    closeContextMenu: () => void;
    insertRowAbove(): void;
    insertRowBelow(): void;
    deleteRows(): void;
    insertColumnLeft(): void;
    insertColumnRight(): void;
    deleteColumn(): void;
    copyTableData(): void;
    intelligentReplaceTableData(): Promise<void>;
    pasteFromContextMenu(): void;
    onImportCSVClick: () => any;
    onCSVFileSelected(event: Event): void;
    exportToCSV(): void;
    private recordHistory;
    undo(): void;
    redo(): void;
    private scrollActiveDropdownOptionIntoView;
    private reorderColumns;
    private escapeHtml;
    private _createNewRow;
    private getPasteStartCoords;
    private getNewColumnName;
    private visualToModelCoords;
    private modelToVisualCoords;
    private toggleCheckbox;
    private validateData;
    private _convertDataToTSV;
    private _convertDataToCSV;
    private _copySelectionToClipboard;
    private _convertPastedValue;
    private _pasteFromClipboard;
    private _parseTSV;
    private _parseCSV;
    private _parseDelimitedData;
    private getCoordsFromTarget;
    private normalizeRange;
    private moveActiveCell;
    private scrollCellIntoView;
    private clearSelectedCells;
    private applyFill;
    private _performIntelligentReplace;
    private _inferColumnType;
    private _toKebabCase;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SpreadsheetComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SpreadsheetComponent, "long-spreadsheet", never, { "data": { "alias": "data"; "required": true; "isSignal": true; }; "columnConfig": { "alias": "columnConfig"; "required": true; "isSignal": true; }; "theme": { "alias": "theme"; "required": true; "isSignal": true; }; "showLoading": { "alias": "showLoading"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; }, { "onDataChange": "onDataChange"; "onColumnChange": "onColumnChange"; }, never, never, true, never>;
}

declare const longLight: SpreadsheetTheme;
declare const longDark: SpreadsheetTheme;
declare const cosmicDark: SpreadsheetTheme;
declare const goldDust: SpreadsheetTheme;

export { SpreadsheetComponent, cosmicDark, goldDust, longDark, longLight };
export type { AnalysisOption, AnalysisType, Cell, ColumnConfig, ColumnSettingsFormData, ColumnType, ContextMenuData, Coordinates, CorrelationGraphConfig, DistributionGraphConfig, DropdownOption, GraphConfig, SavedCorrelationAnalysisState, SavedDistributionAnalysisState, SpreadsheetTheme };
//# sourceMappingURL=oatear-longtable.d.ts.map
